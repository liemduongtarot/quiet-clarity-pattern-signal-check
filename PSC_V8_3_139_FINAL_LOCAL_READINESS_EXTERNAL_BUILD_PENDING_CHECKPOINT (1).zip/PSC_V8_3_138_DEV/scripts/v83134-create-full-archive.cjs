const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const manifest=path.join(tests,'V8_3_134_SHA256_MANIFEST.txt');
const archive=path.join(root,'recovery','PSC_V8_3_134_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip');
const report=path.join(tests,'V8_3_134_ARCHIVE_AUDIT_REPORT.md');
const mode=process.argv[2];
const required=[
 'public/psc-v83133-canonical-role-binding.js','package.json','tests/PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json',
 'scripts/v83134-validation-harness.cjs','scripts/v83134-pre-generation-audit.cjs','scripts/v83134-generate-and-select.cjs',
 'tests/v83134-validation-harness.test.cjs','tests/v83134-validation-harness-mutation.test.cjs',
 'tests/V8_3_134_STEP_111_FAILURE_AUTHORITY.md','tests/V8_3_134_CONSTRUCTION_FAMILY_TAXONOMY.json',
 'tests/V8_3_134_V133_HISTORICAL_POOL_REAUDIT.json','tests/V8_3_134_RUNTIME_IDENTITY.json',
 'tests/V8_3_134_VALIDATION_HARNESS_TEST_REPORT.json','tests/V8_3_134_VALIDATION_HARNESS_MUTATION_REPORT.json',
 'tests/V8_3_134_PRE_GENERATION_OWNER_AUDIT.json','tests/V8_3_134_CANDIDATE_BANK_189.json',
 'tests/V8_3_134_CANDIDATE_BANK_AUDIT.json','tests/V8_3_134_FINAL_60_UNSEALED.json',
 'tests/V8_3_134_SEMANTIC_FINGERPRINTS.json','tests/V8_3_134_DUPLICATE_CONTAMINATION_AUDIT.json',
 'tests/V8_3_134_CONSTRUCTION_FAMILY_DISTRIBUTION.json','tests/SEALED_POOL_DIVERSITY_OWNER_AUDIT.md',
 'tests/SEALED_POOL_SELECTION_REPORT.md','tests/V8_3_134_PRE_SEAL_STEP_111_SIMULATION.json',
 'tests/V8_3_134_RUNTIME_DEVELOPMENT_REPLAY_REPORT.md','tests/V8_3_134_REVIEW_CANDIDATE_STATUS.md',
 'tests/V8_3_134_FINAL_ACCEPTANCE_REPORT.md','tests/V8_3_134_FINAL_ACCEPTANCE_MANIFEST.txt',
 'tests/V8_3_134_VERSION_GRAPH.md','tests/V8_3_133_BROWSER_E2E_INTERNAL_PREVIEW_REPORT.md',
 'recovery/V8_3_121_ORIGINAL_SOURCE_LOSS_RECORD.md','recovery/V8_3_121_RECONSTRUCTION_SPEC.md',
 'recovery/V8_3_121_R1_RECONSTRUCTION_EQUIVALENCE_REPORT.md','recovery/V8_3_121_R1_HISTORICAL_FAILURE_REGRESSION.md'
];
for(const name of required)if(!fs.existsSync(path.join(root,name)))throw Error(`required file missing: ${name}`);
const tracked=execFileSync('git',['ls-files','-z'],{cwd:root}).toString().split('\0').filter(Boolean);
const v134=[...fs.readdirSync(path.join(root,'scripts')).filter(x=>x.startsWith('v83134')).map(x=>'scripts/'+x),...fs.readdirSync(tests).filter(x=>x.includes('V8_3_134')||x.startsWith('v83134')||x==='SEALED_POOL_DIVERSITY_OWNER_AUDIT.md'||x==='SEALED_POOL_SELECTION_REPORT.md').map(x=>'tests/'+x)];
const include=[...new Set([...tracked,...v134])].filter(x=>!x.endsWith('.zip')&&!x.endsWith('V8_3_134_SHA256_MANIFEST.txt')&&!x.endsWith('V8_3_134_ARCHIVE_AUDIT_REPORT.md'));
if(mode==='manifest'){
 if(fs.existsSync(manifest))throw Error('manifest exists; no overwrite');
 fs.writeFileSync(manifest,include.sort().map(name=>`${crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')}  ${name}`).join('\n')+'\n',{flag:'wx'});
 console.log(`manifest entries=${include.length}`);return;
}
if(mode!=='archive')throw Error('use manifest or archive');
if(fs.existsSync(archive))throw Error('archive exists; no overwrite');
execFileSync('zip',['-q','-9',archive,...include,'tests/V8_3_134_SHA256_MANIFEST.txt'],{cwd:root});
execFileSync('unzip',['-tqq',archive],{cwd:root,stdio:'inherit'});
const listing=new Set(execFileSync('unzip',['-Z1',archive],{encoding:'utf8'}).trim().split('\n'));
for(const name of required)if(!listing.has(name))throw Error(`required-file audit failed: ${name}`);
const temp=fs.mkdtempSync('/tmp/v83134-archive-audit-');execFileSync('unzip',['-q',archive,'-d',temp]);
for(const line of fs.readFileSync(path.join(temp,'tests/V8_3_134_SHA256_MANIFEST.txt'),'utf8').trim().split('\n')){const match=line.match(/^([a-f0-9]{64})  (.+)$/);if(!match)throw Error(`bad manifest line: ${line}`);const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(temp,match[2]))).digest('hex');if(actual!==match[1])throw Error(`internal hash mismatch: ${match[2]}`);}
const hash=crypto.createHash('sha256').update(fs.readFileSync(archive)).digest('hex');
fs.writeFileSync(report,`# V8.3.134 archive audit report\n\nStatus: **PASS**\n\n- ZIP integrity: PASS\n- Internal SHA256: PASS\n- Required-file audit: PASS\n- Archive: PSC_V8_3_134_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip\n- SHA256: \`${hash}\`\n- External local download: NOT YET CONFIRMED\n`,{flag:'wx'});
console.log(JSON.stringify({archive,sha256:hash,zip_integrity:'PASS',internal_sha256:'PASS',required_file_audit:'PASS'},null,2));
