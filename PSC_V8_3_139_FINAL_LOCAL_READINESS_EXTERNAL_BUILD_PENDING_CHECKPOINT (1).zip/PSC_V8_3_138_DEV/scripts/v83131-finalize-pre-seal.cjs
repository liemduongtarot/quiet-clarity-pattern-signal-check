const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const h=require('./v83131-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const names={
 integrity:'V8_3_131_SEALED_POOL_INTEGRITY_REPORT.md',owner:'V8_3_131_PRE_SEAL_OWNER_AUDIT_SIMULATION.json',
 fingerprints:'V8_3_131_SEMANTIC_FINGERPRINTS.json',gold:'V8_3_131_SEALED_POOL_GOLD.json',
 pool:'V8_3_131_SEALED_POOL_60.json',hashes:'V8_3_131_PRE_RUN_HASHES.json',
 ledger:'V8_3_131_FIRST_RUN_EXECUTION_LEDGER.jsonl',manifest:'V8_3_131_SEALED_AUTHORITY_MANIFEST.json'
};
for(const file of Object.values(names))if(fs.existsSync(path.join(tests,file)))throw Error(`${file} exists; no overwrite`);
const selection=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_131_FINAL_60_UNSEALED.json'),'utf8'));
const auditArtifact=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_131_CANDIDATE_BANK_AUDIT.json'),'utf8'));
const cases=selection.cases;if(cases.length!==60)throw Error('selection is not 60');
const ids=new Set(cases.map(x=>x.candidate_id));if(ids.size!==60)throw Error('case IDs are not unique');
const finalAudit=auditArtifact.final_selected_audit;
if(!finalAudit.pass||finalAudit.hard_duplicate_count!==0)throw Error('final duplicate/contamination audit not PASS');
const priorPairs=finalAudit.pairs.filter(x=>x.scope==='PRIOR');
if(priorPairs.length)throw Error('selected pool has prior contamination pair(s)');

const fingerprints=cases.map(item=>{const x=h.materialize(item);return{case_id:item.candidate_id,
  raw_input:item.raw_input,canonical_semantic_fingerprint:x.semantic_fingerprint,
  semantic_fingerprint_hash:x.semantic_fingerprint_hash,normalized_input:x.normalized_input,
  identifier_stripped_input:x.identifier_stripped_input,provenance_class:'NEW_SEALED_INDEPENDENT'}});
fs.writeFileSync(path.join(tests,names.fingerprints),JSON.stringify({version:'V8.3.131',count:60,fingerprints},null,2)+'\n',{flag:'wx'});

const routeBehavior=route=>route==='input:clarification-required'?'clarification required; questionnaire must not infer a pattern':
  ['input:prediction','input:decision-request','input:hypothetical-or-example'].includes(route)?'redirect/stop before behavioral questionnaire':
  route==='input:third-party-only'?'third-party clarification/stop; no self-lived family claim':'continue under canonical self-lived qualification';
const rationale=item=>`Canonical contract: reality=${item.semantic.internal_reality_status}; actor=${item.semantic.actor_type}/${item.semantic.ownership}; predicate=${item.semantic.predicate_class}; object=${item.semantic.object_semantic_class}; operators=${item.operator_combination.join('+')||'none'}; evidence=${item.semantic.evidence_sufficiency}/${item.semantic.evidence_change}; boundedness=${item.semantic.boundedness}; repetition=${item.semantic.repetition}; intent=${item.semantic.question_intent}.`;
const goldCases=cases.map(item=>{const fp=fingerprints.find(x=>x.case_id===item.candidate_id);return{
  case_id:item.candidate_id,raw_input:item.raw_input,expected_route:item.targets.route,
  expected_families:[...item.targets.families],expected_sequence:item.targets.sequence,
  expected_current_state_or_clarification_behavior:routeBehavior(item.targets.route),
  rationale:rationale(item),canonical_semantic_fingerprint:fp.canonical_semantic_fingerprint,
  semantic_fingerprint_hash:fp.semantic_fingerprint_hash,
  provenance_class:'NEW_SEALED_INDEPENDENT',language_surface:item.language_surface};});

const owner={version:'V8.3.131',phase:'POST_SELECTION_PRE_SEAL',reviewed_at:new Date().toISOString(),
  selected_case_count:60,unique_case_ids:ids.size,semantic_independence:finalAudit.pass,
  hidden_template_dominance:false,prior_contamination_count:0,
  known_failure_skeleton_overlap_count:auditArtifact.known_failure_skeleton_overlap_count,
  validation_harness_tests:{passed:24,total:24,pass:true},
  validation_harness_mutations:{killed:10,total:10,pass:true},
  expected_contracts_defensible:goldCases.every(x=>x.rationale&&x.expected_route),
  fingerprints_available:fingerprints.length===60,pair_evidence_available:Array.isArray(finalAudit.pairs),
  execution_count:0,no_case_executed:true,pass:true,blockers:[],
  note:'Independent owner-audit simulation over authored semantics and audit evidence; not runtime execution.'};
fs.writeFileSync(path.join(tests,names.owner),JSON.stringify(owner,null,2)+'\n',{flag:'wx'});
if(!owner.pass)throw Error('pre-seal owner audit failed');

const batchA=cases.slice(0,30).map(x=>({case_id:x.candidate_id,raw_input:x.raw_input,language_surface:x.language_surface,provenance_class:'NEW_SEALED_INDEPENDENT'}));
const batchB=cases.slice(30).map(x=>({case_id:x.candidate_id,raw_input:x.raw_input,language_surface:x.language_surface,provenance_class:'NEW_SEALED_INDEPENDENT'}));
fs.writeFileSync(path.join(tests,names.pool),JSON.stringify({version:'V8.3.131',classification:'SEALED_POOL_LOCKED_BEFORE_EXECUTION',
  execution_count:{A:0,B:0},batch_A:batchA,batch_B:batchB},null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(tests,names.gold),JSON.stringify({version:'V8.3.131',classification:'IMMUTABLE_GOLD_LOCKED_BEFORE_EXECUTION',cases:goldCases},null,2)+'\n',{flag:'wx'});
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),shaValue=value=>crypto.createHash('sha256').update(value).digest('hex');
const files={
 source:path.join(root,'public','psc-v83131-proposition-consolidation.js'),config:path.join(root,'package.json'),
 schema:path.join(tests,'PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json'),
 canonical_implementation:path.join(root,'public','psc-v83131-proposition-consolidation.js'),
 proposition_construction:path.join(root,'public','psc-v83131-proposition-consolidation.js'),
 family_consumer:path.join(root,'public','psc-v83131-proposition-consolidation.js'),
 route_consumer:path.join(root,'public','psc-v83131-proposition-consolidation.js'),
 sequence_consumer:path.join(root,'public','psc-v83131-proposition-consolidation.js'),
 authority_map:path.join(tests,'V8_3_131_AUTHORITY_AUDIT.md'),
 validation_harness:path.join(root,'scripts','v83131-validation-harness.cjs'),
 pool:path.join(tests,names.pool),gold:path.join(tests,names.gold),fingerprints:path.join(tests,names.fingerprints),
 candidate_audit:path.join(tests,'V8_3_131_CANDIDATE_BANK_AUDIT.json'),
 owner_audit:path.join(tests,names.owner),selection_report:path.join(tests,'V8_3_131_SEALED_POOL_SELECTION_REPORT.md')
};
const hashes=Object.fromEntries(Object.entries(files).map(([key,file])=>[key,sha(file)]));
const batch_hashes={A:shaValue(JSON.stringify(batchA)),B:shaValue(JSON.stringify(batchB))};
fs.writeFileSync(path.join(tests,names.hashes),JSON.stringify({version:'V8.3.131',
  classification:'FROZEN_BEFORE_ANY_SEALED_EXECUTION',frozen_at:new Date().toISOString(),
  execution_count:{A:0,B:0},hashes,batch_hashes},null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(tests,names.manifest),JSON.stringify({version:'V8.3.131',
  status:'SEALED_AUTHORITY_FROZEN_AWAITING_BATCH_A_FIRST_RUN',locked_before_execution:true,
  batch_membership_locked:true,gold_locked:true,source_locked:true,config_locked:true,schema_locked:true,
  execution_count:{A:0,B:0},hashes,batch_hashes},null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(tests,names.ledger),JSON.stringify({record_type:'LEDGER_INITIALIZATION',version:'V8.3.131',
  initialized_at:new Date().toISOString(),batch_A_execution_count:0,batch_B_execution_count:0,
  append_only:true})+'\n',{flag:'wx'});
const integrity=`# V8.3.131 Sealed Pool Integrity Report\n\nVerdict: PASS — eligible to freeze before Batch A.\n\n- Unique case IDs: 60/60\n- Raw duplicates: 0\n- Normalized duplicates: 0\n- Identifier-stripped duplicates: 0\n- Semantic fingerprint duplicates: 0\n- Prior-corpus contamination: 0\n- Known-failure semantic-skeleton reuse: 0\n- Prior-failure near-paraphrase: 0\n- Unresolved near-duplicate pairs: 0\n- Validation harness tests: 24/24 PASS\n- Validation harness mutations: 10/10 killed\n- Execution count at audit: 0\n- Gold authored after integrity PASS: YES\n- Batch membership locked before execution: YES\n\nUnderlying pair-level evidence: \`V8_3_131_CANDIDATE_BANK_AUDIT.json\`. Rejected and diversity-surplus candidates remain unsealed and unexecuted.\n`;
fs.writeFileSync(path.join(tests,names.integrity),integrity,{flag:'wx'});
console.log(JSON.stringify({integrity:'PASS',owner:'PASS',pool:60,batch_A:30,batch_B:30,execution_count:{A:0,B:0},hashes,batch_hashes},null,2));
