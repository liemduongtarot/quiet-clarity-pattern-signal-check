const base=require('./v83128-validation-harness.cjs');

const FINGERPRINT_FIELDS=Object.freeze([
  'public_route','internal_reality_status','actor_type','ownership',
  'predicate_class','object_semantic_class','expected_family_set','polarity',
  'negation_status','cessation_status','evidence_sufficiency','evidence_change',
  'boundedness','repetition','constraint_status','question_intent',
  'temporal_structure','sequence_shape','clause_count','clause_relations',
  'language_surface'
]);

function fingerprintOf(item){
  const missing=FINGERPRINT_FIELDS.filter(field=>!(field in(item.semantic||{})));
  if(missing.length)throw Error(`missing fingerprint fields: ${missing.join(', ')}`);
  const fields={};
  for(const field of FINGERPRINT_FIELDS){
    const value=item.semantic[field];
    fields[field]=Array.isArray(value)?[...value].sort():value;
  }
  const canonical=base.canonical(fields);
  return{fields,canonical,hash:base.sha256(canonical)};
}

function structuralKey(item){
  const s=item.semantic;
  return base.canonical({
    reality:s.internal_reality_status,actor:s.actor_type,ownership:s.ownership,
    predicate:s.predicate_class,object:s.object_semantic_class,polarity:s.polarity,
    negation:s.negation_status,cessation:s.cessation_status,
    evidence_sufficiency:s.evidence_sufficiency,evidence_change:s.evidence_change,
    boundedness:s.boundedness,repetition:s.repetition,constraint:s.constraint_status,
    intent:s.question_intent,temporal:s.temporal_structure,
    sequence:s.sequence_shape,clause_count:s.clause_count,relations:s.clause_relations
  });
}

function materialize(item){
  if(!item?.candidate_id||!item.raw_input||!item.semantic||!item.targets)throw Error('candidate requires candidate_id, raw_input, semantic and targets');
  const fp=fingerprintOf(item);
  return{...item,normalized_input:base.normalizeText(item.raw_input),
    identifier_stripped_input:base.stripIdentifiers(item.raw_input),
    semantic_fingerprint:fp.fields,semantic_fingerprint_hash:fp.hash,
    structural_operator_key:structuralKey(item)};
}

function priorMaterialize(item){
  const raw=item.raw_input||item.input;
  if(item.semantic){
    const mapped={...item,candidate_id:item.candidate_id||item.case_id,raw_input:raw,
      targets:item.targets||{route:item.expected?.route,families:item.expected?.families,sequence:item.expected?.sequence}};
    try{return materialize(mapped)}catch{}
  }
  const normalized=base.normalizeText(raw);
  return{...item,candidate_id:item.candidate_id||item.case_id,raw_input:raw,
    normalized_input:normalized,identifier_stripped_input:base.stripIdentifiers(raw),
    semantic_fingerprint:null,semantic_fingerprint_hash:`PRIOR-UNKNOWN-${base.sha256(normalized)}`,
    structural_operator_key:null};
}

function pair(left,right,kind,metric,scope){
  return{left_candidate_id:left.candidate_id,right_candidate_id:right.candidate_id,
    scope,kind,metric,left_raw:left.raw_input,right_raw:right.raw_input,
    left_normalized:left.normalized_input,right_normalized:right.normalized_input,
    left_identifier_stripped:left.identifier_stripped_input,
    right_identifier_stripped:right.identifier_stripped_input,
    left_fingerprint:left.semantic_fingerprint,right_fingerprint:right.semantic_fingerprint,
    left_template_origin:left.template_origin||null,right_template_origin:right.template_origin||null,
    decision:'UNREVIEWED',rationale:''};
}

function audit(candidates,prior=[],options={}){
  const threshold=options.nearThreshold??0.8;
  if(threshold>0.8)throw Error('near-duplicate threshold may not exceed 0.8');
  const current=candidates.map(materialize),history=prior.map(priorMaterialize),pairs=[];
  function compare(left,right,scope){
    const prefix=scope==='PRIOR'?'PRIOR_':'';
    if(left.raw_input===right.raw_input)pairs.push(pair(left,right,prefix+'RAW_DUPLICATE',1,scope));
    if(left.normalized_input===right.normalized_input)pairs.push(pair(left,right,prefix+'NORMALIZED_DUPLICATE',1,scope));
    if(left.identifier_stripped_input===right.identifier_stripped_input)pairs.push(pair(left,right,prefix+'IDENTIFIER_STRIPPED_DUPLICATE',1,scope));
    if(left.semantic_fingerprint_hash===right.semantic_fingerprint_hash)pairs.push(pair(left,right,prefix+'FINGERPRINT_DUPLICATE',1,scope));
    const lexical=base.jaccard(left.identifier_stripped_input,right.identifier_stripped_input);
    if(lexical>=threshold&&lexical<1)pairs.push(pair(left,right,prefix+'LEXICAL_NEAR_DUPLICATE',Number(lexical.toFixed(6)),scope));
    if(left.structural_operator_key&&left.structural_operator_key===right.structural_operator_key&&left.semantic_fingerprint_hash!==right.semantic_fingerprint_hash)
      pairs.push(pair(left,right,prefix+'STRUCTURAL_OPERATOR_NEAR_DUPLICATE',1,scope));
    if(left.template_origin&&left.template_origin===right.template_origin)
      pairs.push(pair(left,right,prefix+'TEMPLATE_ORIGIN_COLLISION',1,scope));
  }
  for(let i=0;i<current.length;i++){
    for(let j=i+1;j<current.length;j++)compare(current[i],current[j],'CURRENT');
    for(const old of history)compare(current[i],old,'PRIOR');
  }
  const hard=pairs.filter(x=>/(?:RAW|NORMALIZED|IDENTIFIER_STRIPPED|FINGERPRINT)_DUPLICATE$/.test(x.kind));
  return{schema_version:'V8.3.131-1',generated_at:new Date().toISOString(),
    candidate_count:current.length,prior_count:history.length,near_threshold:threshold,
    materialized_candidates:current,pairs,hard_duplicate_count:hard.length,
    near_pair_count:pairs.length-hard.length,pass:hard.length===0&&pairs.length===0};
}

function distribution(candidates){
  const rows=candidates.map(materialize),result={};
  for(const field of [...FINGERPRINT_FIELDS,'template_origin']){
    result[field]={};
    for(const row of rows){
      const raw=field==='template_origin'?(row.template_origin||'NONE'):row.semantic_fingerprint[field];
      const key=Array.isArray(raw)?(raw.length?[...raw].sort().join('+'):'NO_FAMILY'):String(raw);
      result[field][key]=(result[field][key]||0)+1;
    }
  }
  return{candidate_count:rows.length,distribution:result};
}

module.exports={...base,FINGERPRINT_FIELDS,fingerprintOf,materialize,audit,distribution};

