const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),manifest=path.join(root,'tests/V8_3_131_SHA256_MANIFEST.txt');
const archive=path.join(root,'recovery/PSC_V8_3_131_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip'),mode=process.argv[2];
const required=[
  'public/psc-v83131-proposition-consolidation.js','tests/PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json',
  'tests/V8_3_131_FORENSIC_LEVEL_SPLIT_AND_DESIGN_REPORT.md','tests/V8_3_131_AUTHORITY_AUDIT.md',
  'tests/V8_3_131_DEVELOPMENT_GATE_REPORT.md','tests/V8_3_131_BROWSER_E2E_INTERNAL_PREVIEW_REPORT.md',
  'tests/v83131-level1-representation.test.cjs','tests/v83131-level2-consumer-freeze.test.cjs',
  'tests/v83131-v130-contaminated-regressions.test.cjs','tests/v83131-metamorphic.test.cjs',
  'tests/v83131-representation-mutations.test.cjs','tests/v83131-focused-development-480.test.cjs',
  'tests/v83131-presealed-convergence-probe-240.test.cjs','tests/v83131-validation-harness.test.cjs',
  'tests/v83131-validation-harness-mutation.test.cjs','scripts/v83131-validation-harness.cjs',
  'scripts/v83131-author-candidate-bank.cjs','scripts/v83131-audit-and-select-pool.cjs',
  'scripts/v83131-finalize-pre-seal.cjs','scripts/v83131-run-sealed-batch.cjs',
  'scripts/v83131-audit-batch-evidence.cjs','scripts/v83131-create-full-archive.cjs',
  'tests/V8_3_131_CANDIDATE_BANK_100.json','tests/V8_3_131_CANDIDATE_BANK_AUDIT.json',
  'tests/V8_3_131_FINAL_60_UNSEALED.json','tests/V8_3_131_SEALED_POOL_SELECTION_REPORT.md',
  'tests/V8_3_131_SEALED_POOL_INTEGRITY_REPORT.md','tests/V8_3_131_PRE_SEAL_OWNER_AUDIT_SIMULATION.json',
  'tests/V8_3_131_SEALED_POOL_60.json','tests/V8_3_131_SEALED_POOL_GOLD.json',
  'tests/V8_3_131_SEMANTIC_FINGERPRINTS.json','tests/V8_3_131_PRE_RUN_HASHES.json',
  'tests/V8_3_131_SEALED_AUTHORITY_MANIFEST.json','tests/V8_3_131_FIRST_RUN_EXECUTION_LEDGER.jsonl',
  'tests/V8_3_131_BATCH_A_FIRST_RUN_CASE_LEVEL.json','tests/V8_3_131_BATCH_A_FIRST_RUN_SUMMARY.json',
  'tests/V8_3_131_BATCH_A_EVIDENCE_INTEGRITY_AUDIT.json','tests/V8_3_131_BATCH_B_NOT_RUN_RECORD.json',
  'tests/V8_3_131_REVIEW_CANDIDATE_STATUS.md','tests/V8_3_131_FINAL_ACCEPTANCE_REPORT.md',
  'tests/V8_3_131_FINAL_ACCEPTANCE_MANIFEST.txt','tests/V8_3_131_VERSION_GRAPH.md',
  'recovery/V8_3_121_ORIGINAL_SOURCE_LOSS_RECORD.md','recovery/V8_3_121_RECONSTRUCTION_SPEC.md',
  'recovery/V8_3_121_R1_RECONSTRUCTION_EQUIVALENCE_REPORT.md','recovery/V8_3_121_R1_HISTORICAL_FAILURE_REGRESSION.md',
  'recovery/V8_3_121_R1_RECOVERY_BASELINE_HASHES.md','package.json'
];
for(const name of required)if(!fs.existsSync(path.join(root,name)))throw Error(`required file missing: ${name}`);
const tracked=execFileSync('git',['ls-files','-z'],{cwd:root}).toString().split('\0').filter(Boolean).filter(name=>!name.endsWith('.zip')&&!name.endsWith('V8_3_131_SHA256_MANIFEST.txt'));
if(mode==='manifest'){
  if(fs.existsSync(manifest))throw Error('manifest exists; no overwrite');
  const lines=tracked.map(name=>`${crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')}  ${name}`);
  fs.writeFileSync(manifest,lines.join('\n')+'\n',{flag:'wx'});console.log(`manifest entries=${lines.length}`);return;
}
if(mode!=='archive')throw Error('use manifest or archive');
if(fs.existsSync(archive))throw Error('archive exists; no overwrite');
const include=[...tracked,'tests/V8_3_131_SHA256_MANIFEST.txt'];
execFileSync('zip',['-q','-9',archive,...include],{cwd:root});execFileSync('unzip',['-tqq',archive],{cwd:root,stdio:'inherit'});
const listing=execFileSync('unzip',['-Z1',archive],{cwd:root,encoding:'utf8'}).trim().split('\n');for(const name of required)if(!listing.includes(name))throw Error(`required-file audit failed: ${name}`);
const temp=fs.mkdtempSync('/tmp/v83131-archive-audit-');execFileSync('unzip',['-q',archive,'-d',temp]);
for(const line of fs.readFileSync(path.join(temp,'tests/V8_3_131_SHA256_MANIFEST.txt'),'utf8').trim().split('\n')){const [hash,...rest]=line.split(/\s+/),name=rest.join(' ');const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(temp,name))).digest('hex');if(actual!==hash)throw Error(`internal hash mismatch: ${name}`);}
const archiveHash=crypto.createHash('sha256').update(fs.readFileSync(archive)).digest('hex');
fs.writeFileSync(path.join(root,'tests/V8_3_131_ARCHIVE_AUDIT_REPORT.md'),`# V8.3.131 Archive Audit Report\n\nStatus: **PASS**\n\n- ZIP integrity: PASS\n- Internal SHA256 manifest: PASS\n- Required-file audit: PASS\n- Archive: PSC_V8_3_131_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip\n- SHA256: \`${archiveHash}\`\n- External local download: NOT YET CONFIRMED\n`,{flag:'wx'});
console.log(JSON.stringify({archive,sha256:archiveHash,zip_integrity:'PASS',internal_manifest:'PASS',required_files:'PASS'},null,2));
