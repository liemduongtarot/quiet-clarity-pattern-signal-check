const fs=require('node:fs'),path=require('node:path');
const h=require('./v83128-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const pool=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_128_POOL_CANDIDATE_60.json'),'utf8')).cases;
const prior=[];let ordinal=0;
function add(input,source){if(typeof input!=='string'||input.length<12)return;prior.push({case_id:`PRIOR-${++ordinal}`,input,source});}
function walk(value,source,key=''){if(Array.isArray(value))for(const v of value)walk(v,source,key);else if(value&&typeof value==='object')for(const [k,v]of Object.entries(value))walk(v,source,k);else if(typeof value==='string'&&/prompt|input|text|question|concept|case/i.test(key))add(value,source);}
for(const name of fs.readdirSync(tests).sort()){
  if(name.startsWith('V8_3_128_')||name.startsWith('VALIDATION_HARNESS_'))continue;
  const file=path.join(tests,name);if(!fs.statSync(file).isFile())continue;
  const text=fs.readFileSync(file,'utf8');
  if(name.endsWith('.json')){try{walk(JSON.parse(text),name);}catch{}}
  if(/\.(?:cjs|mjs|js)$/.test(name)){
    for(const match of text.matchAll(/(?:prompt|input)\s*:\s*([`'"])([\s\S]*?)\1/g))if(!match[2].includes('${'))add(match[2],name);
  }
}
const seen=new Set();const uniquePrior=prior.filter(x=>{const key=h.normalizeText(x.input);if(!key||seen.has(key))return false;seen.add(key);return true;});
const audit=h.auditPool(pool,uniquePrior,{nearThreshold:0.8});
const output={purpose:'pre-lock candidate audit; not first-run evidence',prior_sources_scanned:fs.readdirSync(tests).filter(n=>!n.startsWith('V8_3_128_')).length,prior_surface_count:uniquePrior.length,audit};
fs.writeFileSync(path.join(tests,'V8_3_128_POOL_INITIAL_AUDIT.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:audit.case_count,prior:audit.prior_case_count,hard:audit.hard_duplicate_count,near:audit.near_pair_count,kinds:Object.fromEntries([...new Set(audit.flagged_pairs.map(x=>x.kind))].map(k=>[k,audit.flagged_pairs.filter(x=>x.kind===k).length]))},null,2));
