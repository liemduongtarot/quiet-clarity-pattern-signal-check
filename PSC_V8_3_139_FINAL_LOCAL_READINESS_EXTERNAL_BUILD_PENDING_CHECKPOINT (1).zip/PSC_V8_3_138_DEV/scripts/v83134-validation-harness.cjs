const crypto = require('node:crypto');

const SEMANTIC_RELATIONS = new Set([
  'CAUSE','PURPOSE','BEFORE','AFTER','WITHOUT','WHILE','CONTRAST','CONDITION',
  'ATTRIBUTION','EXAMPLE_OF','FRAME_SCOPE','SINGLE'
]);

const FINGERPRINT_FIELDS = Object.freeze([
  'public_route','internal_reality_status','actor_type','ownership','predicate_class',
  'object_semantic_class','expected_family_set','polarity','negation_status',
  'cessation_status','evidence_sufficiency','evidence_change','boundedness',
  'repetition','constraint_status','question_intent','temporal_structure',
  'sequence_shape','clause_count','clause_relations'
]);

const REQUIRED_PROVENANCE = Object.freeze([
  'candidate_id','root_construction_family','generation_strategy',
  'semantic_dimensions_targeted','surface_language','provenance'
]);

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).sort().join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const normalizeText = value => String(value).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const stripIdentifiers = value => normalizeText(value)
  .replace(/\b(?:mr|mrs|ms|dr)\s+[a-z]+\b/g,'PERSON')
  .replace(/\b(?:alice|ben|carla|david|emma|farah|giang|hoa|lan|minh|nam|son|thao|trang)\b/g,'PERSON')
  .replace(/\b\d+\b/g,'NUMBER');

function normalizeRelations(relations) {
  if (!Array.isArray(relations) || !relations.length) throw Error('clause_relations must be a non-empty array');
  const normalized = relations.map(x => String(x).trim().toUpperCase());
  const invalid = normalized.filter(x => !SEMANTIC_RELATIONS.has(x));
  if (invalid.length) throw Error(`NON_SEMANTIC_CLAUSE_RELATION: ${invalid.join(',')}`);
  return [...new Set(normalized)].sort();
}

function normalizeTemplateRoot(value) {
  return String(value || '').toLowerCase().trim()
    .replace(/(?:[-_: ](?:variant|instance|case|seed))[-_: ]*\d+$/,'')
    .replace(/[-_: ]\d+$/,'');
}

function fingerprintOf(item) {
  const semantic = item.semantic || {};
  const missing = FINGERPRINT_FIELDS.filter(field => !(field in semantic));
  if (missing.length) throw Error(`missing fingerprint fields: ${missing.join(', ')}`);
  const fields = {};
  for (const field of FINGERPRINT_FIELDS) {
    let value = semantic[field];
    if (field === 'clause_relations') value = normalizeRelations(value);
    else if (Array.isArray(value)) value = [...new Set(value)].sort();
    fields[field] = value;
  }
  const encoded = canonical(fields);
  return { fields, canonical: encoded, hash: sha256(encoded) };
}

function constructionSkeleton(item) {
  const s = fingerprintOf(item).fields;
  return canonical({
    actor:s.actor_type, ownership:s.ownership, reality:s.internal_reality_status,
    polarity:s.polarity, negation:s.negation_status, cessation:s.cessation_status,
    predicate:s.predicate_class, object:s.object_semantic_class,
    evidence:[s.evidence_sufficiency,s.evidence_change], boundedness:s.boundedness,
    repetition:s.repetition, constraint:s.constraint_status, intent:s.question_intent,
    temporal:s.temporal_structure, sequence:s.sequence_shape, clauses:s.clause_count,
    relations:s.clause_relations, route:s.public_route, families:s.expected_family_set
  });
}

function materialize(item) {
  for (const field of REQUIRED_PROVENANCE) if (!(field in item)) throw Error(`missing generation provenance: ${field}`);
  const fingerprint = fingerprintOf(item);
  return {
    ...item,
    normalized_input: normalizeText(item.raw_input),
    identifier_stripped_input: stripIdentifiers(item.raw_input),
    normalized_template_root: normalizeTemplateRoot(item.root_construction_family || item.template_origin),
    semantic_fingerprint: fingerprint.fields,
    semantic_fingerprint_hash: fingerprint.hash,
    hidden_template_skeleton_hash: sha256(constructionSkeleton(item))
  };
}

function auditPool(candidates, prior = []) {
  const current = candidates.map(materialize);
  const historical = prior.map(x => {
    let semantic_fingerprint_hash=null;
    if(x.semantic){try{semantic_fingerprint_hash=fingerprintOf(x).hash}catch{semantic_fingerprint_hash=null;}}
    return {candidate_id:x.candidate_id||x.case_id,raw_input:x.raw_input || x.input,
      normalized_input:normalizeText(x.raw_input || x.input),
      identifier_stripped_input:stripIdentifiers(x.raw_input || x.input),semantic_fingerprint_hash};
  });
  const pairs=[];
  const compare=(a,b,scope)=>{
    const kinds=[];
    if(a.raw_input===b.raw_input)kinds.push('RAW_DUPLICATE');
    if(a.normalized_input===b.normalized_input)kinds.push('NORMALIZED_DUPLICATE');
    if(a.identifier_stripped_input===b.identifier_stripped_input)kinds.push('IDENTIFIER_STRIPPED_DUPLICATE');
    if(a.semantic_fingerprint_hash&&a.semantic_fingerprint_hash===b.semantic_fingerprint_hash)kinds.push('SEMANTIC_FINGERPRINT_DUPLICATE');
    for(const kind of kinds)pairs.push({scope,kind,left:a.candidate_id||a.case_id,right:b.candidate_id||b.case_id});
  };
  for(let i=0;i<current.length;i++){
    for(let j=i+1;j<current.length;j++)compare(current[i],current[j],'CURRENT');
    for(const old of historical)compare(current[i],old,'PRIOR');
  }
  const groups={};
  for(const row of current){
    const key=row.hidden_template_skeleton_hash;
    (groups[key] ||= {skeleton_hash:key,count:0,case_ids:[],root_families:new Set()});
    groups[key].count++;groups[key].case_ids.push(row.candidate_id);groups[key].root_families.add(row.normalized_template_root);
  }
  const hidden_template_groups=Object.values(groups).map(g=>({...g,root_families:[...g.root_families].sort()})).sort((a,b)=>b.count-a.count);
  return {pass:pairs.length===0,pairs,hidden_template_groups,materialized_candidates:current};
}

function counts(rows, getter) {
  const out={}; for(const row of rows){const key=String(getter(row));out[key]=(out[key]||0)+1;} return out;
}

function diversityAudit(candidates) {
  const rows=candidates.map(materialize), d={};
  const axes={
    public_route:r=>r.semantic.public_route,
    expected_family_set:r=>(r.semantic.expected_family_set||[]).sort().join('+')||'NO_FAMILY',
    reality_status:r=>r.semantic.internal_reality_status, actor_ownership:r=>`${r.semantic.actor_type}/${r.semantic.ownership}`,
    polarity:r=>r.semantic.polarity, negation:r=>r.semantic.negation_status,
    cessation:r=>r.semantic.cessation_status, constraint:r=>r.semantic.constraint_status,
    question_intent:r=>r.semantic.question_intent, evidence_sufficiency:r=>r.semantic.evidence_sufficiency,
    evidence_change:r=>r.semantic.evidence_change, boundedness:r=>r.semantic.boundedness,
    repetition:r=>r.semantic.repetition, sequence_depth:r=>r.semantic.sequence_shape,
    clause_relation:r=>r.semantic.clause_relations.slice().sort().join('+'), language_surface:r=>r.surface_language,
    construction_family:r=>r.normalized_template_root
  };
  for(const [axis,getter] of Object.entries(axes))d[axis]=counts(rows,getter);
  const roots=Object.values(d.construction_family).sort((a,b)=>b-a), top3=roots.slice(0,3).reduce((a,b)=>a+b,0);
  const requirements={
    case_count:rows.length===60, root_families:roots.length>=18, largest_root:(roots[0]||0)<=5,
    top_three_share:top3/Math.max(rows.length,1)<=0.25, route_breadth:Object.keys(d.public_route).length>=5,
    family_breadth:Object.keys(d.expected_family_set).length>=5, polarity_breadth:Object.keys(d.polarity).length>=2,
    reality_breadth:Object.keys(d.reality_status).length>=3, sequence_breadth:Object.keys(d.sequence_depth).length>=3,
    negation_breadth:Object.keys(d.negation).length>=2, cessation_breadth:Object.keys(d.cessation).length>=2,
    language_breadth:Object.keys(d.language_surface).length>=2
  };
  return {pass:Object.values(requirements).every(Boolean),requirements,largest_root_count:roots[0]||0,top_three_count:top3,top_three_share:Number((top3/Math.max(rows.length,1)).toFixed(4)),distribution:d};
}

function validateBatchEvidence({batch,evidence,summary,ledger,expectedIds,authority}) {
  const defects=[]; const rows=evidence?.results||[];
  if(rows.length!==expectedIds.length)defects.push('CASE_LEVEL_EVIDENCE_INCOMPLETE');
  const ids=rows.map(x=>x.case_id),unique=new Set(ids);
  if(unique.size!==ids.length||expectedIds.some(id=>!unique.has(id)))defects.push('CASE_LEVEL_EVIDENCE_INCOMPLETE');
  const ledgerRows=ledger.filter(x=>x.record_type==='CASE_EXECUTION'&&x.batch===batch);
  if(ledgerRows.length!==expectedIds.length||ledgerRows.some(x=>x.execution_count_before!==0||x.execution_count_after!==1||x.execution_ordinal!==1))defects.push('FIRST_RUN_INTEGRITY_VIOLATION');
  if(new Set(ledgerRows.map(x=>x.run_id)).size!==1||new Set(rows.map(x=>x.run_id)).size!==1||ledgerRows[0]?.run_id!==rows[0]?.run_id)defects.push('FIRST_RUN_INTEGRITY_VIOLATION');
  for(const row of rows){
    for(const key of ['source','config','schema'])if(row.hashes?.[key]!==authority[key])defects.push('A_B_AUTHORITY_IDENTITY_FAILURE');
    const computed=canonical(row.actual)===canonical(row.expected);
    if(row.pass!==computed)defects.push('CASE_RESULT_INCONSISTENT');
  }
  const passed=rows.filter(x=>x.pass).length;
  if(summary.total!==rows.length||summary.passed!==passed||summary.failed!==rows.length-passed)defects.push('AGGREGATE_CASE_MISMATCH');
  if(summary.status==='PASS'&&(rows.length!==expectedIds.length||passed!==expectedIds.length))defects.push('MANIFEST_CANNOT_OVERRIDE_UNDERLYING_EVIDENCE');
  return {pass:defects.length===0,defects:[...new Set(defects)]};
}

function validateABIdentity(a,b){
  const defects=[];for(const key of ['source','config','schema'])if(a[key]!==b[key])defects.push('A_B_AUTHORITY_IDENTITY_FAILURE');
  return{pass:defects.length===0,defects};
}

module.exports={SEMANTIC_RELATIONS,FINGERPRINT_FIELDS,canonical,sha256,normalizeText,stripIdentifiers,
  normalizeRelations,normalizeTemplateRoot,fingerprintOf,constructionSkeleton,materialize,auditPool,
  diversityAudit,validateBatchEvidence,validateABIdentity};
