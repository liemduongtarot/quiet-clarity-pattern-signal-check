const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests'),batch=process.argv[2];
if(!['A','B'].includes(batch))throw Error('usage: node scripts/v83130-audit-batch-evidence.cjs A|B');
const out=path.join(tests,`V8_3_130_BATCH_${batch}_EVIDENCE_INTEGRITY_AUDIT.json`);
if(fs.existsSync(out))throw Error('evidence audit exists; no overwrite');
const evidence=JSON.parse(fs.readFileSync(path.join(tests,`V8_3_130_BATCH_${batch}_FIRST_RUN_CASE_LEVEL.json`),'utf8'));
const summary=JSON.parse(fs.readFileSync(path.join(tests,`V8_3_130_BATCH_${batch}_FIRST_RUN_SUMMARY.json`),'utf8'));
const ledger=fs.readFileSync(path.join(tests,'V8_3_130_FIRST_RUN_EXECUTION_LEDGER.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const defects=[];if(evidence.results.length!==30)defects.push('case count is not 30');
const ids=new Set();for(const row of evidence.results){
  for(const key of ['case_id','raw_input','expected','actual','pass','canonical_state_trace_reference','hashes','run_id','timestamp','execution_ordinal'])if(!(key in row))defects.push(`${row.case_id||'unknown'} missing ${key}`);
  if(ids.has(row.case_id))defects.push(`duplicate case ${row.case_id}`);ids.add(row.case_id);
  if(row.execution_ordinal!==1)defects.push(`${row.case_id} ordinal not 1`);
  const records=ledger.filter(x=>x.record_type==='CASE_EXECUTION'&&x.batch===batch&&x.case_id===row.case_id);
  if(records.length!==1)defects.push(`${row.case_id} ledger count ${records.length}`);
}
if(summary.total!==30||summary.passed+summary.failed!==30)defects.push('summary arithmetic invalid');
const result={version:'V8.3.130',batch,classification:'INDEPENDENT_FIRST_RUN_EVIDENCE_AUDIT',
  audited_at:new Date().toISOString(),case_count:evidence.results.length,unique_case_ids:ids.size,
  evidence_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(tests,`V8_3_130_BATCH_${batch}_FIRST_RUN_CASE_LEVEL.json`))).digest('hex'),
  summary_sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(tests,`V8_3_130_BATCH_${batch}_FIRST_RUN_SUMMARY.json`))).digest('hex'),
  defects,pass:defects.length===0};
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));if(!result.pass)process.exitCode=1;
