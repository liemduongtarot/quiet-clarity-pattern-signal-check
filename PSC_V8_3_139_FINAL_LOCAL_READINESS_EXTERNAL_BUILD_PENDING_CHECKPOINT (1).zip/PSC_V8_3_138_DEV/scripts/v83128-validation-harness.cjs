const crypto = require('node:crypto');

const FINGERPRINT_FIELDS = Object.freeze([
  'public_route', 'internal_reality_status', 'actor_type', 'ownership',
  'predicate_class', 'expected_family_set', 'polarity', 'negation_status',
  'cessation_status', 'evidence_sufficiency', 'evidence_change', 'boundedness',
  'repetition', 'constraint_status', 'temporal_structure', 'sequence_shape',
  'question_type', 'attribution_status', 'clause_count', 'clause_relation',
  'language_surface'
]);

const IDENTIFIER_PATTERNS = [
  /\b(?:case|item|scenario|example|prompt|batch|test)[-_ ]?[a-z]*\d+\b/giu,
  /\b(?:v\d{2,3}|a\d{1,3}|b\d{1,3}|id\d+)\b/giu,
  /\b(?:anh|chị|ông|bà|bạn)\s+[A-ZÀ-Ỹ][\p{L}'’-]+\b/gu,
  /\b(?:mr|mrs|ms|dr)\.?\s+[A-Z][a-z'’-]+\b/gu,
  /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2}\b/g
];

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).sort().join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

function normalizeText(input) {
  return String(input).normalize('NFKC').toLocaleLowerCase('und')
    .replace(/[“”„‟«»]/g, '"').replace(/[‘’‚‛]/g, "'")
    .replace(/[^\p{L}\p{N}'\s-]+/gu, ' ').replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function stripIdentifiers(input) {
  let text = String(input).normalize('NFKC');
  for (const pattern of IDENTIFIER_PATTERNS) text = text.replace(pattern, ' <identifier> ');
  return normalizeText(text).replace(/\b\d+\b/g, '<number>').replace(/\s+/g, ' ').trim();
}

function tokenSet(text) {
  return new Set(normalizeText(text).split(' ').filter(Boolean));
}

function jaccard(a, b) {
  const left = tokenSet(a); const right = tokenSet(b);
  const union = new Set([...left, ...right]);
  if (!union.size) return 1;
  let intersection = 0;
  for (const token of left) if (right.has(token)) intersection += 1;
  return intersection / union.size;
}

function fingerprintOf(testCase) {
  const missing = FINGERPRINT_FIELDS.filter(field => !(field in (testCase.semantic || {})));
  if (missing.length) throw new Error(`missing fingerprint fields: ${missing.join(', ')}`);
  const fingerprint = {};
  for (const field of FINGERPRINT_FIELDS) {
    const value = testCase.semantic[field];
    fingerprint[field] = Array.isArray(value) ? [...value].sort() : value;
  }
  return { fields: fingerprint, canonical: canonical(fingerprint), hash: sha256(canonical(fingerprint)) };
}

function structuralKey(testCase) {
  const s = testCase.semantic;
  return canonical({
    predicate_class: s.predicate_class, polarity: s.polarity,
    negation_status: s.negation_status, cessation_status: s.cessation_status,
    evidence_change: s.evidence_change, boundedness: s.boundedness,
    constraint_status: s.constraint_status, temporal_structure: s.temporal_structure,
    sequence_shape: s.sequence_shape, clause_count: s.clause_count,
    clause_relation: s.clause_relation
  });
}

function materialize(testCase) {
  if (!testCase || typeof testCase !== 'object') throw new Error('case must be an object');
  if (!testCase.case_id || !testCase.input || !testCase.expected || !testCase.semantic) {
    throw new Error('case requires case_id, input, expected and semantic');
  }
  const fingerprint = fingerprintOf(testCase);
  return {
    ...testCase,
    normalized_input: normalizeText(testCase.input),
    identifier_stripped_input: stripIdentifiers(testCase.input),
    semantic_fingerprint: fingerprint.fields,
    semantic_fingerprint_hash: fingerprint.hash,
    structural_operator_key: structuralKey(testCase)
  };
}

function materializePrior(testCase) {
  if (testCase.semantic) return materialize(testCase);
  const normalized = normalizeText(testCase.input);
  const stripped = stripIdentifiers(testCase.input);
  return { ...testCase, normalized_input: normalized, identifier_stripped_input: stripped,
    semantic_fingerprint: null, semantic_fingerprint_hash: `PRIOR-UNKNOWN-${sha256(`${testCase.case_id}:${normalized}`)}`,
    structural_operator_key: `PRIOR-UNKNOWN-${sha256(testCase.case_id)}` };
}

function pairRecord(left, right, kind, metric, decision = 'UNREVIEWED', rationale = '') {
  return {
    left_case_id: left.case_id, right_case_id: right.case_id, kind, metric,
    left_raw: left.input, right_raw: right.input,
    left_normalized: left.normalized_input, right_normalized: right.normalized_input,
    left_identifier_stripped: left.identifier_stripped_input,
    right_identifier_stripped: right.identifier_stripped_input,
    left_fingerprint: left.semantic_fingerprint,
    right_fingerprint: right.semantic_fingerprint,
    left_template_origin: left.template_origin || null,
    right_template_origin: right.template_origin || null,
    decision, rationale
  };
}

function auditPool(cases, priorCases = [], options = {}) {
  const nearThreshold = options.nearThreshold ?? 0.8;
  if (nearThreshold > 0.8) throw new Error('near-duplicate threshold may not exceed 0.8');
  const current = cases.map(materialize);
  const prior = priorCases.map(materializePrior);
  const flags = [];
  const exactKinds = new Set(['RAW_DUPLICATE', 'NORMALIZED_DUPLICATE', 'IDENTIFIER_STRIPPED_DUPLICATE', 'FINGERPRINT_DUPLICATE']);
  const compare = (left, right, priorComparison = false) => {
    const prefix = priorComparison ? 'PRIOR_' : '';
    if (left.input === right.input) flags.push(pairRecord(left, right, `${prefix}RAW_DUPLICATE`, 1));
    if (left.normalized_input === right.normalized_input) flags.push(pairRecord(left, right, `${prefix}NORMALIZED_DUPLICATE`, 1));
    if (left.identifier_stripped_input === right.identifier_stripped_input) flags.push(pairRecord(left, right, `${prefix}IDENTIFIER_STRIPPED_DUPLICATE`, 1));
    if (left.semantic_fingerprint_hash === right.semantic_fingerprint_hash) flags.push(pairRecord(left, right, `${prefix}FINGERPRINT_DUPLICATE`, 1));
    const similarity = jaccard(left.identifier_stripped_input, right.identifier_stripped_input);
    if (similarity >= nearThreshold && similarity < 1) flags.push(pairRecord(left, right, `${prefix}LEXICAL_NEAR_DUPLICATE`, Number(similarity.toFixed(6))));
    if (left.structural_operator_key === right.structural_operator_key && left.semantic_fingerprint_hash !== right.semantic_fingerprint_hash) {
      flags.push(pairRecord(left, right, `${prefix}STRUCTURAL_OPERATOR_NEAR_DUPLICATE`, 1));
    }
    if (left.template_origin && left.template_origin === right.template_origin) {
      flags.push(pairRecord(left, right, `${prefix}TEMPLATE_ORIGIN_COLLISION`, 1));
    }
  };
  for (let i = 0; i < current.length; i += 1) {
    for (let j = i + 1; j < current.length; j += 1) compare(current[i], current[j]);
    for (const oldCase of prior) compare(current[i], oldCase, true);
  }
  const hardDuplicates = flags.filter(flag => exactKinds.has(flag.kind) || flag.kind.startsWith('PRIOR_') && exactKinds.has(flag.kind.slice(6)));
  const nearPairs = flags.filter(flag => flag.kind.includes('NEAR_DUPLICATE') || flag.kind.includes('TEMPLATE_ORIGIN'));
  return {
    schema_version: 'V8.3.128-1', generated_at: new Date().toISOString(),
    case_count: current.length, prior_case_count: prior.length, near_threshold: nearThreshold,
    materialized_cases: current, flagged_pairs: flags,
    hard_duplicate_count: hardDuplicates.length, near_pair_count: nearPairs.length,
    pass: hardDuplicates.length === 0 && nearPairs.every(pair => pair.decision === 'ACCEPT_DISTINCT' && pair.rationale)
  };
}

function validatePairReview(audit) {
  const defects = [];
  for (const pair of audit.flagged_pairs || []) {
    if (pair.kind.includes('NEAR_DUPLICATE') || pair.kind.includes('TEMPLATE_ORIGIN')) {
      if (pair.decision !== 'ACCEPT_DISTINCT' || !String(pair.rationale || '').trim()) defects.push(pair);
    }
  }
  return { pass: defects.length === 0, defects };
}

function diversityReport(cases) {
  const materialized = cases.map(materialize);
  const dimensions = [...FINGERPRINT_FIELDS, 'template_origin'];
  const distribution = {};
  for (const dimension of dimensions) {
    distribution[dimension] = {};
    for (const item of materialized) {
      const raw = dimension === 'template_origin' ? (item.template_origin || 'NONE') : item.semantic_fingerprint[dimension];
      const values = dimension === 'expected_family_set'
        ? [Array.isArray(raw) && raw.length ? [...raw].sort().join('+') : 'NO_FAMILY']
        : (Array.isArray(raw) ? raw : [raw]);
      for (const value of values) distribution[dimension][String(value)] = (distribution[dimension][String(value)] || 0) + 1;
    }
  }
  return { case_count: materialized.length, distribution };
}

function preRunOwnerAudit(input) {
  const blockers = [];
  const requiredPasses = ['harness_tests', 'harness_mutations', 'duplicate_audit', 'contamination_audit', 'pair_review', 'diversity_audit'];
  for (const key of requiredPasses) if (input[key]?.pass !== true) blockers.push(`${key} is not PASS`);
  if (!input.pool || input.pool.length !== 60) blockers.push('sealed pool must contain exactly 60 cases');
  if (!input.gold || input.gold.length !== 60) blockers.push('gold must contain exactly 60 cases');
  if (input.execution_count !== 0) blockers.push('execution ledger must be zero before first run');
  if (!input.locked_before_execution) blockers.push('pool/gold were not locked before execution');
  if (!input.hashes || Object.values(input.hashes).some(value => !/^[a-f0-9]{64}$/.test(value))) blockers.push('pre-run hashes incomplete');
  return { pass: blockers.length === 0, blockers, reviewed_at: new Date().toISOString() };
}

function preGenerationOwnerAudit(input) {
  const blockers = [];
  for (const key of ['fingerprint_schema', 'fixture_duplicate_audit', 'fixture_contamination_audit', 'harness_tests', 'harness_mutations']) {
    if (input[key]?.pass !== true) blockers.push(`${key} is not PASS`);
  }
  if (input.sealed_pool_exists === true) blockers.push('sealed pool existed before generation authorization');
  if (input.runtime_drift === true) blockers.push('runtime drift detected');
  return { phase: 'PRE_GENERATION', pass: blockers.length === 0, blockers, reviewed_at: new Date().toISOString() };
}

module.exports = {
  FINGERPRINT_FIELDS, sha256, canonical, normalizeText, stripIdentifiers,
  jaccard, fingerprintOf, materialize, auditPool, validatePairReview,
  diversityReport, preGenerationOwnerAudit, preRunOwnerAudit
};
