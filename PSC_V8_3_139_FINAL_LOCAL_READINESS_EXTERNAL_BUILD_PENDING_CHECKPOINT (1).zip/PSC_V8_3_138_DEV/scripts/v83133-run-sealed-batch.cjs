const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests'),batch=process.argv[2];
if(!['A','B'].includes(batch))throw Error('usage: node scripts/v83133-run-sealed-batch.cjs A|B');
const caseFile=path.join(tests,`V8_3_133_BATCH_${batch}_FIRST_RUN_CASE_LEVEL.json`);
const summaryFile=path.join(tests,`V8_3_133_BATCH_${batch}_FIRST_RUN_SUMMARY.json`);
if(fs.existsSync(caseFile)||fs.existsSync(summaryFile))throw Error(`Batch ${batch} evidence exists; rerun prohibited`);
const ledgerFile=path.join(tests,'V8_3_133_FIRST_RUN_EXECUTION_LEDGER.jsonl');
const ledger=fs.readFileSync(ledgerFile,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
if(ledger.some(x=>x.record_type==='CASE_EXECUTION'&&x.batch===batch))throw Error(`Batch ${batch} already executed`);
if(batch==='B'){
  const a=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_BATCH_A_FIRST_RUN_SUMMARY.json'),'utf8'));
  const audit=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_BATCH_A_EVIDENCE_INTEGRITY_AUDIT.json'),'utf8'));
  if(a.status!=='PASS'||a.passed!==30||audit.pass!==true)throw Error('Batch B prohibited: Batch A first-run/evidence gate not PASS');
}
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const frozen=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_PRE_RUN_HASHES.json'),'utf8'));
const verify={
  source:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js')),
  config:sha(path.join(root,'package.json')),
  schema:sha(path.join(tests,'PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json')),
  pool:sha(path.join(tests,'V8_3_133_SEALED_POOL_60.json')),
  gold:sha(path.join(tests,'V8_3_133_SEALED_POOL_GOLD.json')),
  fingerprints:sha(path.join(tests,'V8_3_133_SEMANTIC_FINGERPRINTS.json')),
  authority_map:sha(path.join(tests,'V8_3_133_AUTHORITY_AUDIT.md'))
};
for(const[key,value]of Object.entries(verify))if(value!==frozen.hashes[key])throw Error(`frozen ${key} hash drift`);
process.env.PSC_V83133='1';const{loadCore}=require('../tests/v83117-helper.cjs');const core=loadCore();
const pool=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_SEALED_POOL_60.json'),'utf8'))[`batch_${batch}`];
const gold=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_SEALED_POOL_GOLD.json'),'utf8')).cases;
const byId=new Map(gold.map(x=>[x.case_id,x])),runId=`V83133-${batch}-${crypto.randomUUID()}`,started=new Date().toISOString();
const results=pool.map((item,index)=>{
  const contract=byId.get(item.case_id);if(!contract)throw Error(`missing gold ${item.case_id}`);
  const frame=core.analyze(item.raw_input,'work');
  const actual={route:frame.input_route.id,families:[...frame.families],sequence:!!frame.sequence};
  const expected={route:contract.expected_route,families:contract.expected_families,sequence:contract.expected_sequence};
  const state=frame.canonical_semantic_state;
  return{case_id:item.case_id,batch,run_id:runId,execution_ordinal:1,execution_index:index+1,
    timestamp:new Date().toISOString(),raw_input:item.raw_input,
    input_sha256:crypto.createHash('sha256').update(item.raw_input).digest('hex'),
    expected,actual,pass:JSON.stringify(expected)===JSON.stringify(actual),
    canonical_state_trace_reference:{document_id:state?.document_id||null,
      proposition_ids:(state?.propositions||[]).map(x=>x.proposition_id),
      trace:state?.trace||[]},hashes:{...frozen.hashes}};
});
const passed=results.filter(x=>x.pass).length,finished=new Date().toISOString(),status=passed===30?'PASS':'FAIL';
const evidence={version:'V8.3.133',classification:'FIRST_RUN_CASE_LEVEL_IMMUTABLE_EVIDENCE',batch,
  run_id:runId,execution_ordinal:1,started_at:started,finished_at:finished,results};
const summary={version:'V8.3.133',classification:'FIRST_RUN_ONLY',batch,run_id:runId,
  execution_ordinal:1,status,passed,total:30,failed:30-passed,
  failed_case_ids:results.filter(x=>!x.pass).map(x=>x.case_id),rerun:false,
  expected_changed_after_execution:false,source_changed_after_execution:false};
fs.writeFileSync(caseFile,JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(summaryFile,JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const fd=fs.openSync(ledgerFile,'a');for(const result of results)fs.writeSync(fd,JSON.stringify({
  record_type:'CASE_EXECUTION',version:'V8.3.133',batch,case_id:result.case_id,run_id:runId,
  execution_count_before:0,execution_count_after:1,execution_ordinal:1,
  executed_at:result.timestamp,pass:result.pass})+'\n');fs.closeSync(fd);
console.log(JSON.stringify(summary,null,2));if(status!=='PASS')process.exitCode=1;
