const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),manifest=path.join(root,'tests/V8_3_128_SHA256_MANIFEST.txt');
const archive=path.join(root,'recovery/PSC_V8_3_128_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip');
const mode=process.argv[2];
const required=['tests/SEALED_POOL_60.json','tests/SEALED_POOL_GOLD.json','tests/SEALED_POOL_SEMANTIC_FINGERPRINTS.json','tests/SEALED_POOL_DUPLICATE_PAIR_AUDIT.json','tests/SEALED_POOL_CONTAMINATION_AUDIT.json','tests/BATCH_A_FIRST_RUN_CASE_LEVEL.json','tests/BATCH_A_FIRST_RUN_SUMMARY.json','tests/BATCH_B_NOT_RUN_RECORD.json','tests/FIRST_RUN_EXECUTION_LEDGER.json','tests/SOURCE_IDENTITY_A_B_REPORT.md','tests/VALIDATION_HARNESS_TEST_REPORT.md','tests/VALIDATION_HARNESS_MUTATION_REPORT.md','tests/FINAL_ACCEPTANCE_REPORT.md','tests/FINAL_ACCEPTANCE_MANIFEST.txt','recovery/V8_3_121_ORIGINAL_SOURCE_LOSS_RECORD.md','recovery/V8_3_121_RECONSTRUCTION_SPEC.md','recovery/V8_3_121_R1_RECONSTRUCTION_EQUIVALENCE_REPORT.md','tests/V8_3_128_VERSION_GRAPH.md','public/psc-v83127-review-intent-authority.js','package.json'];
for(const name of required)if(!fs.existsSync(path.join(root,name)))throw Error(`required file missing: ${name}`);
const tracked=execFileSync('git',['ls-files','-z'],{cwd:root}).toString().split('\0').filter(Boolean).filter(n=>!n.endsWith('.zip')&&!n.endsWith('V8_3_128_SHA256_MANIFEST.txt'));
if(mode==='manifest'){
  if(fs.existsSync(manifest))throw Error('manifest already exists');
  const lines=tracked.map(name=>`${crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')}  ${name}`);
  fs.writeFileSync(manifest,lines.join('\n')+'\n',{flag:'wx'});console.log(`manifest entries=${lines.length}`);return;
}
if(mode!=='archive')throw Error('use manifest or archive');if(fs.existsSync(archive))throw Error('archive already exists');
const include=[...tracked,'tests/V8_3_128_SHA256_MANIFEST.txt'];execFileSync('zip',['-q','-9',archive,...include],{cwd:root});
execFileSync('unzip',['-tqq',archive],{cwd:root,stdio:'inherit'});const listing=execFileSync('unzip',['-Z1',archive],{cwd:root,encoding:'utf8'}).trim().split('\n');
for(const name of required)if(!listing.includes(name))throw Error(`archive required-file audit failed: ${name}`);
const temp=fs.mkdtempSync('/tmp/v83128-archive-audit-');execFileSync('unzip',['-q',archive,'-d',temp]);
for(const line of fs.readFileSync(path.join(temp,'tests/V8_3_128_SHA256_MANIFEST.txt'),'utf8').trim().split('\n')){const [hash,...rest]=line.split(/\s+/),name=rest.join(' ');const actual=crypto.createHash('sha256').update(fs.readFileSync(path.join(temp,name))).digest('hex');if(actual!==hash)throw Error(`internal hash mismatch: ${name}`);}
const archiveHash=crypto.createHash('sha256').update(fs.readFileSync(archive)).digest('hex');
fs.writeFileSync(path.join(root,'tests/V8_3_128_ARCHIVE_AUDIT_REPORT.md'),`# V8.3.128 Archive Audit Report\n\nStatus: **PASS**\n\n- ZIP integrity: PASS\n- Internal SHA256 manifest: PASS\n- Required-file audit: PASS\n- Archive: PSC_V8_3_128_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip\n- SHA256: \`${archiveHash}\`\n- External local download: NOT YET CONFIRMED\n`,{flag:'wx'});
console.log(JSON.stringify({archive,sha256:archiveHash,zip_integrity:'PASS',internal_manifest:'PASS',required_files:'PASS'},null,2));
