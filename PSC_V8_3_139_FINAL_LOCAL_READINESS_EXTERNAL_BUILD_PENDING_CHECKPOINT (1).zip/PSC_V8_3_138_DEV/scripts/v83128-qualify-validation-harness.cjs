const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const h = require('./v83128-validation-harness.cjs');

const root = path.resolve(__dirname, '..');
const out = path.join(root, 'tests');
const semantic = (overrides = {}) => ({
  public_route: 'review', internal_reality_status: 'current', actor_type: 'self', ownership: 'self',
  predicate_class: 'evidence_review', expected_family_set: ['slow'], polarity: 'positive', negation_status: 'none',
  cessation_status: 'none', evidence_sufficiency: 'insufficient', evidence_change: 'stable', boundedness: 'bounded',
  repetition: 'single', constraint_status: 'none', temporal_structure: 'single_phase', sequence_shape: 'atomic',
  question_type: 'what_to_do', attribution_status: 'none', clause_count: 1, clause_relation: 'single',
  language_surface: 'en', ...overrides
});
const item = (case_id, input, overrides = {}, extra = {}) => ({
  case_id, input, expected: { public_route: overrides.public_route || 'review', expected_family_set: overrides.expected_family_set || ['slow'] },
  semantic: semantic(overrides), ...extra
});

const duplicateFixtures = [
  item('D-RAW-1', 'Review this record.'), item('D-RAW-2', 'Review this record.', { polarity: 'negative' }),
  item('D-ID-1', 'Mr Stone will inspect the record.', { actor_type: 'third_party', ownership: 'third_party' }),
  item('D-ID-2', 'Mr Reed will inspect the record.', { actor_type: 'third_party', ownership: 'third_party', question_type: 'why' }),
  item('D-FP-1', 'I lack enough evidence to decide.'), item('D-FP-2', 'The available material does not yet support a conclusion.')
];
const priorFixtures = [item('PRIOR-1', 'A manager reported the allegation.', { actor_type: 'third_party', ownership: 'third_party', attribution_status: 'attributed' })];
const contaminationFixtures = [item('NEW-1', 'A manager reported the allegation.', { actor_type: 'third_party', ownership: 'third_party', attribution_status: 'attributed' })];

const duplicateAudit = h.auditPool(duplicateFixtures);
const contaminationAudit = h.auditPool(contaminationFixtures, priorFixtures);
const duplicateDetectionPass = ['RAW_DUPLICATE', 'NORMALIZED_DUPLICATE', 'IDENTIFIER_STRIPPED_DUPLICATE', 'FINGERPRINT_DUPLICATE']
  .every(kind => duplicateAudit.flagged_pairs.some(pair => pair.kind === kind));
const contaminationDetectionPass = contaminationAudit.flagged_pairs.some(pair => pair.kind === 'PRIOR_RAW_DUPLICATE');

const testOutput = execFileSync(process.execPath, ['--test', 'tests/v83128-validation-harness.test.cjs'], { cwd: root, encoding: 'utf8' });
const mutationOutput = execFileSync(process.execPath, ['--test', 'tests/v83128-validation-harness-mutation.test.cjs'], { cwd: root, encoding: 'utf8' });
const testsPass = /# pass 13|ℹ pass 13/.test(testOutput) && !/# fail [1-9]|ℹ fail [1-9]/.test(testOutput);
const mutationsPass = /# pass 10|ℹ pass 10/.test(mutationOutput) && !/# fail [1-9]|ℹ fail [1-9]/.test(mutationOutput);
const owner = h.preGenerationOwnerAudit({
  fingerprint_schema: { pass: h.FINGERPRINT_FIELDS.length === 21 },
  fixture_duplicate_audit: { pass: duplicateDetectionPass },
  fixture_contamination_audit: { pass: contaminationDetectionPass },
  harness_tests: { pass: testsPass }, harness_mutations: { pass: mutationsPass },
  sealed_pool_exists: fs.existsSync(path.join(out, 'SEALED_POOL_60.json')), runtime_drift: false
});

const writeNew = (name, value) => fs.writeFileSync(path.join(out, name), `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
writeNew('V8_3_128_FINGERPRINT_SCHEMA.json', { version: 'V8.3.128-1', pass: true, field_count: h.FINGERPRINT_FIELDS.length, fields: h.FINGERPRINT_FIELDS });
writeNew('V8_3_128_HARNESS_DUPLICATE_FIXTURE_AUDIT.json', { purpose: 'controlled detection proof; not sealed evidence', pass: duplicateDetectionPass, audit: duplicateAudit });
writeNew('V8_3_128_HARNESS_CONTAMINATION_FIXTURE_AUDIT.json', { purpose: 'controlled prior-corpus detection proof; not sealed evidence', pass: contaminationDetectionPass, audit: contaminationAudit });
writeNew('V8_3_128_PRE_GENERATION_OWNER_AUDIT_SIMULATION.json', owner);
fs.writeFileSync(path.join(out, 'VALIDATION_HARNESS_TEST_REPORT.md'), `# V8.3.128 Validation Harness Test Report\n\nStatus: **${testsPass ? 'PASS' : 'FAIL'}**\n\nThe 13 harness tests exercise required-field enforcement, raw/normalized/identifier-stripped/fingerprint duplicate detection, threshold governance, pair-review evidence, template collision detection, prior-corpus detection, canonical stability, and owner-audit refusal.\n\n\`\`\`text\n${testOutput.trim()}\n\`\`\`\n`, { flag: 'wx' });
fs.writeFileSync(path.join(out, 'VALIDATION_HARNESS_MUTATION_REPORT.md'), `# V8.3.128 Validation Harness Mutation Report\n\nStatus: **${mutationsPass ? 'PASS' : 'FAIL'}**\n\nKilled: ${mutationsPass ? '10/10' : 'INCOMPLETE'} bypass mutations.\n\n\`\`\`text\n${mutationOutput.trim()}\n\`\`\`\n`, { flag: 'wx' });
if (!owner.pass) process.exitCode = 1;
console.log(JSON.stringify(owner, null, 2));
