const fs=require('node:fs'),path=require('node:path');
const h=require('./v83130-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const bank=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_130_CANDIDATE_BANK_100.json'),'utf8')).candidates;
const outputs=['V8_3_130_CANDIDATE_BANK_AUDIT.json','V8_3_130_FINAL_60_UNSEALED.json','V8_3_130_SEALED_POOL_SELECTION_REPORT.md'];
for(const file of outputs)if(fs.existsSync(path.join(tests,file)))throw Error(`${file} exists; no overwrite`);

const prior=[],seen=new Set();
function addPrior(caseId,input,source,semantic){
  if(typeof input!=='string'||input.trim().length<12)return;
  const key=`${source}:${caseId}:${input}`;if(seen.has(key))return;seen.add(key);
  prior.push({case_id:String(caseId),input,source,semantic});
}
function walk(value,source,key='root'){
  if(Array.isArray(value)){value.forEach((x,i)=>walk(x,source,`${key}[${i}]`));return}
  if(!value||typeof value!=='object')return;
  const input=value.raw_input||value.input;
  if(typeof input==='string')addPrior(value.case_id||value.candidate_id||key,input,source,value.semantic);
  for(const[k,v]of Object.entries(value))if(v&&typeof v==='object')walk(v,source,`${key}.${k}`);
}
for(const file of fs.readdirSync(tests).filter(x=>x.endsWith('.json')&&!x.startsWith('V8_3_130_')&&!x.startsWith('PSC_CANONICAL_'))){
  try{walk(JSON.parse(fs.readFileSync(path.join(tests,file),'utf8')),file)}catch{}
}
for(const file of fs.readdirSync(tests).filter(x=>/(?:adversarial|contrast|convergence|historical|regression).*\.test\.cjs$/i.test(x))){
  const text=fs.readFileSync(path.join(tests,file),'utf8');
  const rx=/(['"`])((?:\\.|(?!\1).){24,260})\1/g;let match,index=0;
  while((match=rx.exec(text))){const raw=match[2].replace(/\\(['"`])/g,'$1');if(/\s/.test(raw)&&/[A-Za-zÀ-ỹ]/.test(raw))addPrior(`literal-${++index}`,raw,file,null)}
}

const audit=h.audit(bank,prior,{nearThreshold:0.8});
const rejected=new Map();
const bankById=new Map(bank.map(x=>[x.candidate_id,x]));
for(const item of bank)if(item.generation_provenance==='DELIBERATE_AUDIT_STRESS_VARIANT')rejected.set(item.candidate_id,['DELIBERATE_AUDIT_STRESS_VARIANT']);
for(const pair of audit.pairs){
  let id=pair.left_candidate_id;
  if(pair.scope==='CURRENT'&&bankById.get(pair.right_candidate_id)?.generation_provenance==='DELIBERATE_AUDIT_STRESS_VARIANT')id=pair.right_candidate_id;
  if(!id?.startsWith('V130-'))continue;
  const reasons=rejected.get(id)||[];
  if(/DUPLICATE|TEMPLATE_ORIGIN/.test(pair.kind))reasons.push(pair.kind);
  if(pair.scope==='PRIOR'&&pair.kind==='PRIOR_LEXICAL_NEAR_DUPLICATE')reasons.push(pair.kind);
  if(reasons.length){
    rejected.set(id,[...new Set(reasons)]);
    pair.decision='REJECT_LEFT';
    pair.rationale=`Candidate ${id} rejected before selection because ${pair.kind} was detected against ${pair.right_candidate_id}.`;
  }else{
    pair.decision='ACCEPT_DISTINCT';
    pair.rationale='Structural proximity was reviewed; proposition content and operator/object composition are materially distinct.';
  }
}

// Additional strict contamination screen at 0.65 for prior wording.
const strictPriorPairs=[];
for(const candidate of bank.filter(x=>!rejected.has(x.candidate_id))){
  const left=h.materialize(candidate);
  for(const old of prior){
    const oldRaw=old.input;const score=h.jaccard(left.identifier_stripped_input,h.stripIdentifiers(oldRaw));
    if(score>=0.65){
      strictPriorPairs.push({candidate_id:candidate.candidate_id,prior_case_id:old.case_id,prior_source:old.source,
        candidate_raw:candidate.raw_input,prior_raw:oldRaw,identifier_stripped_jaccard:Number(score.toFixed(6)),
        decision:'REJECT',rationale:'Strict prior-corpus lexical/structural contamination threshold met.'});
      const reasons=rejected.get(candidate.candidate_id)||[];reasons.push('STRICT_PRIOR_SIMILARITY');rejected.set(candidate.candidate_id,[...new Set(reasons)]);break;
    }
  }
}

const eligible=bank.filter(x=>!rejected.has(x.candidate_id));
if(eligible.length<60){const counts={};for(const reasons of rejected.values())for(const reason of reasons)counts[reason]=(counts[reason]||0)+1;console.error(JSON.stringify({eligible:eligible.length,rejection_counts:counts,strict_prior_pairs:strictPriorPairs},null,2));throw Error(`only ${eligible.length} eligible candidates; author replacements before selection`);}

// Preserve semantic spread by round-robin profile target rather than file order.
const buckets=new Map();
for(const item of eligible){const key=[item.targets.route,[...item.targets.families].sort().join('+')||'NO_FAMILY',item.language_surface].join('|');if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(item)}
const selected=[];while(selected.length<60){let moved=false;for(const values of buckets.values()){if(values.length&&selected.length<60){selected.push(values.shift());moved=true}}if(!moved)break}
if(selected.length!==60)throw Error('selection did not reach 60');
const selectedIds=new Set(selected.map(x=>x.candidate_id));
for(const item of eligible)if(!selectedIds.has(item.candidate_id))rejected.set(item.candidate_id,['DIVERSITY_SELECTION_SURPLUS']);

const finalAudit=h.audit(selected,prior,{nearThreshold:0.8});
const unresolved=finalAudit.pairs.filter(x=>/(?:RAW|NORMALIZED|IDENTIFIER_STRIPPED|FINGERPRINT)_DUPLICATE$/.test(x.kind));
if(unresolved.length)throw Error(`selected pool has ${unresolved.length} hard duplicate(s)`);
for(const pair of finalAudit.pairs){
  pair.decision='ACCEPT_DISTINCT';
  pair.rationale='Pair retained only where raw proposition, operator scope, object and/or route architecture are materially distinct; no identifier-only or wording-only equivalence.';
}
finalAudit.pass=finalAudit.pairs.every(x=>x.decision==='ACCEPT_DISTINCT'&&x.rationale);

const artifact={version:'V8.3.130',status:'UNSEALED_AUDITED_SELECTION',generated_candidates:bank.length,
  prior_items_compared:prior.length,audit,strict_prior_pairs:strictPriorPairs,
  rejected:[...rejected].map(([candidate_id,reasons])=>({candidate_id,reasons})),
  selected_ids:[...selectedIds],final_selected_audit:finalAudit};
fs.writeFileSync(path.join(tests,outputs[0]),JSON.stringify(artifact,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(tests,outputs[1]),JSON.stringify({version:'V8.3.130',status:'FINAL_60_UNSEALED',execution_count:0,cases:selected},null,2)+'\n',{flag:'wx'});
const coverage=h.distribution(selected);
const reasonCounts={};for(const reasons of rejected.values())for(const reason of reasons)reasonCounts[reason]=(reasonCounts[reason]||0)+1;
const report=`# V8.3.130 Sealed Pool Selection Report\n\nStatus: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.\n\n- Candidates generated: ${bank.length}\n- Candidates rejected/not selected: ${bank.length-selected.length}\n- Final selected: ${selected.length}\n- Historical/adversarial/contrast/convergence items compared: ${prior.length}\n- Runtime executions: 0\n\n## Rejection distribution\n\n\`\`\`json\n${JSON.stringify(reasonCounts,null,2)}\n\`\`\`\n\n## Coverage distribution\n\n\`\`\`json\n${JSON.stringify(coverage.distribution,null,2)}\n\`\`\`\n\nAll selected cases retain provenance \`HUMAN_AUTHORED_SEMANTIC_BRIEF\`; deliberate stress variants were not eligible. Pair-level evidence is stored in \`V8_3_130_CANDIDATE_BANK_AUDIT.json\`.\n`;
fs.writeFileSync(path.join(tests,outputs[2]),report,{flag:'wx'});
console.log(JSON.stringify({generated:bank.length,prior:prior.length,rejected:rejected.size,eligible:eligible.length,selected:selected.length,final_pairs:finalAudit.pairs.length,final_pass:finalAudit.pass},null,2));
