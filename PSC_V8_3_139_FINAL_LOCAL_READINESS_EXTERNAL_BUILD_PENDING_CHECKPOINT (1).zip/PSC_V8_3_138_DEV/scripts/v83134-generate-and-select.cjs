const fs=require('node:fs'),path=require('node:path');const h=require('./v83134-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const write=(name,data)=>fs.writeFileSync(path.join(tests,name),JSON.stringify(data,null,2)+'\n',{flag:'wx'});
const taxonomy=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_134_CONSTRUCTION_FAMILY_TAXONOMY.json'),'utf8')).families;
const objects=['the intake note','the supplier record','the rota entry','the handover memo','the access request','the booking detail','the evidence file'];
const viObjects=['ghi chú tiếp nhận','hồ sơ nhà cung cấp','mục lịch làm','biên bản bàn giao','yêu cầu truy cập','chi tiết đặt lịch','hồ sơ bằng chứng'];
const specs={
 'actor-self':i=>`I reviewed ${objects[i]} because it concerned my own decision.`,
 'actor-third-party':i=>`My colleague reviewed ${objects[i]} for their own decision.`,
 'ownership-possessive':i=>`My manager's ${objects[i]} was checked by her, not by me.`,
 'ownership-passive-affected':i=>`My ${objects[i]} was blocked because the external service was unavailable.`,
 'reality-hypothetical':i=>`Suppose I repeatedly reviewed ${objects[i]}; that would only be an example.`,
 'reality-historical':i=>`Years ago I repeatedly reviewed ${objects[i]}, but that no longer happens.`,
 'negated-predicate':i=>`I did not avoid ${objects[i]}; I opened it immediately.`,
 'cessation':i=>`I used to keep reviewing ${objects[i]}, but I stopped doing that.`,
 'external-constraint':i=>`I could not submit ${objects[i]} because the portal was offline.`,
 'predicate-object-composition':i=>`I left ${objects[i]} unopened for another day.`,
 'review-sufficient':i=>`I had enough evidence in ${objects[i]}, so I reviewed it once and decided.`,
 'review-insufficient':i=>`I lacked enough evidence in ${objects[i]}, so I kept reviewing it.`,
 'decision-intent':i=>`What should I do about ${objects[i]}?`,
 'question-routing':i=>`When will ${objects[i]} finally be approved?`,
 'purpose-avoidance':i=>`I reorganised my desk so that I would not have to open ${objects[i]}.`,
 'premature-action':i=>`I decided before checking ${objects[i]}.`,
 'freeze-inability':i=>`I froze and could not act when I saw ${objects[i]}.`,
 'changed-evidence':i=>`The evidence in ${objects[i]} changed, so I reviewed the decision again.`,
 'bounded-review':i=>`I reviewed ${objects[i]} for exactly ten minutes and then decided.`,
 'repeated-review':i=>`Nothing changed in ${objects[i]}, but I checked it over and over.`,
 'third-party-attribution':i=>`According to my director, the team delayed ${objects[i]}.`,
 'quotation':i=>`My colleague said, “I keep checking ${objects[i]},” describing their own behaviour.`,
 'mixed-real-hypothetical':i=>`I opened ${objects[i]} today; if I kept checking it, that would only be hypothetical.`,
 'two-phase-sequence':i=>`Before deciding, I reviewed ${objects[i]}; afterward I stopped checking it.`,
 'three-phase-sequence':i=>`First I avoided ${objects[i]}, then I reviewed it, and finally I decided.`,
 'no-family-control':i=>`I filed ${objects[i]} once as planned and moved on.`,
 'ambiguity-clarification':i=>`Something about ${objects[i]} keeps happening, but I have not said what I do.`
};
const routeFor=(family)=>family==='actor-third-party'||family==='ownership-possessive'||family==='third-party-attribution'||family==='quotation'?'input:third-party-only':family==='reality-hypothetical'?'input:hypothetical-or-example':family==='decision-intent'?'input:decision-request':family==='question-routing'?'input:prediction':family==='ambiguity-clarification'?'input:clarification-required':'input:self-lived';
const familiesFor=family=>family==='purpose-avoidance'||family==='predicate-object-composition'?['ignore']:family==='premature-action'?['fast']:family==='freeze-inability'?['freeze']:family==='review-insufficient'||family==='repeated-review'?['slow']:family==='changed-evidence'?['adaptive']:family==='three-phase-sequence'?['ignore','slow','fast']:[];
const realityFor=family=>family==='reality-hypothetical'||family==='mixed-real-hypothetical'?'hypothetical':family==='reality-historical'?'historical':'current';
const relationFor=family=>family.includes('attribution')||family==='quotation'?'ATTRIBUTION':family==='external-constraint'?'CAUSE':family==='purpose-avoidance'?'PURPOSE':family==='two-phase-sequence'?'BEFORE':family==='three-phase-sequence'?'AFTER':family==='mixed-real-hypothetical'?'CONDITION':family==='negated-predicate'?'CONTRAST':'SINGLE';
const candidates=[];let serial=0;
for(let fi=0;fi<taxonomy.length;fi++)for(let i=0;i<7;i++){
  const family=taxonomy[fi],raw=specs[family](i),route=routeFor(family),families=familiesFor(family);
  const semantic={public_route:route,internal_reality_status:realityFor(family),actor_type:route==='input:third-party-only'?'third-party':'self',ownership:route==='input:third-party-only'?'third-party':'self',predicate_class:family,object_semantic_class:`${family}-object-${i+1}`,expected_family_set:families,polarity:family==='negated-predicate'?'negative':'positive',negation_status:family==='negated-predicate'?'negated':'none',cessation_status:family==='cessation'?'ceased':'none',evidence_sufficiency:family==='review-sufficient'?'sufficient':family==='review-insufficient'?'insufficient':'not_applicable',evidence_change:family==='changed-evidence'?'changed':'stable',boundedness:family==='bounded-review'?'bounded':'unbounded',repetition:family==='repeated-review'?'repeated':'single',constraint_status:family==='external-constraint'?'external':'none',question_intent:family==='decision-intent'?'decision':family==='question-routing'?'prediction':family==='ambiguity-clarification'?'clarification':'statement',temporal_structure:family==='two-phase-sequence'?'two_phase':family==='three-phase-sequence'?'three_phase':'single_phase',sequence_shape:family==='two-phase-sequence'?'two_phase':family==='three-phase-sequence'?'three_phase':'atomic',clause_count:family.includes('sequence')?3:family==='external-constraint'||family==='mixed-real-hypothetical'?2:1,clause_relations:[relationFor(family)]};
  serial++;candidates.push({candidate_id:`V134-C${String(serial).padStart(3,'0')}`,raw_input:raw,root_construction_family:family,generation_strategy:'taxonomy-directed-human-semantic-template',semantic_dimensions_targeted:Object.keys(semantic),surface_language:i%3===2?'en-mixed':'en',provenance:'V8.3.134 independently authored unsealed bank',semantic,targets:{route,families,sequence:family==='three-phase-sequence'}});
}
if(candidates.length<180)throw Error('candidate bank below 180');
const prior=[];for(const file of fs.readdirSync(tests).filter(x=>/CANDIDATE_BANK_\d+\.json$|SEALED_POOL_60\.json$/.test(x)&&!x.includes('134'))){try{const j=JSON.parse(fs.readFileSync(path.join(tests,file),'utf8'));prior.push(...(j.candidates||[]),...(j.batch_A||j.batch_a||[]),...(j.batch_B||j.batch_b||[]));}catch{}}
const bankAudit=h.auditPool(candidates,prior);write('V8_3_134_CANDIDATE_BANK_189.json',{version:'V8.3.134',status:'UNSEALED',execution_count:0,candidates});
write('V8_3_134_CANDIDATE_BANK_AUDIT.json',{candidate_count:candidates.length,prior_count:prior.length,raw_normalized_identifier_semantic_pairs:bankAudit.pairs,hidden_template_groups:bankAudit.hidden_template_groups,pass:bankAudit.pass});
if(!bankAudit.pass)throw Error(`candidate bank duplicate/contamination audit failed: ${bankAudit.pairs.length}`);
const selected=[];const byRoot=new Map();for(const row of candidates){const list=byRoot.get(row.root_construction_family)||[];const limit=taxonomy.indexOf(row.root_construction_family)<6?3:2;if(list.length<limit){list.push(row);selected.push(row);}byRoot.set(row.root_construction_family,list);}
if(selected.length!==60)throw Error(`selection ${selected.length}`);
const selectedAudit=h.auditPool(selected,prior),diversity=h.diversityAudit(selected);
write('V8_3_134_FINAL_60_UNSEALED.json',{version:'V8.3.134',status:'UNSEALED',execution_count:0,cases:selected});
write('V8_3_134_SEMANTIC_FINGERPRINTS.json',{version:'V8.3.134',cases:selected.map(x=>{const m=h.materialize(x);return{candidate_id:x.candidate_id,root_construction_family:x.root_construction_family,semantic_fingerprint:m.semantic_fingerprint,hash:m.semantic_fingerprint_hash,hidden_template_skeleton_hash:m.hidden_template_skeleton_hash}})});
write('V8_3_134_DUPLICATE_CONTAMINATION_AUDIT.json',{candidate_count:189,selected_count:60,prior_count:prior.length,pairs:selectedAudit.pairs,pass:selectedAudit.pass});
write('V8_3_134_CONSTRUCTION_FAMILY_DISTRIBUTION.json',diversity);
const ownerMd=`# V8.3.134 sealed-pool diversity owner audit\n\n- Root construction families: ${Object.keys(diversity.distribution.construction_family).length}\n- Largest family count: ${diversity.largest_root_count}\n- Top-three family share: ${(diversity.top_three_share*100).toFixed(1)}%\n- Route breadth: ${Object.keys(diversity.distribution.public_route).length}\n- Family breadth: ${Object.keys(diversity.distribution.expected_family_set).length}\n- Polarity breadth: ${Object.keys(diversity.distribution.polarity).length}\n- Reality breadth: ${Object.keys(diversity.distribution.reality_status).length}\n- Sequence breadth: ${Object.keys(diversity.distribution.sequence_depth).length}\n- Operator breadth: negation=${Object.keys(diversity.distribution.negation).length}, cessation=${Object.keys(diversity.distribution.cessation).length}, constraint=${Object.keys(diversity.distribution.constraint).length}\n- Language breadth: ${Object.keys(diversity.distribution.language_surface).length}\n\nVerdict: **${diversity.pass&&selectedAudit.pass?'PASS':'FAIL'}**. Fingerprint uniqueness alone was not used as the verdict.\n`;
fs.writeFileSync(path.join(tests,'SEALED_POOL_DIVERSITY_OWNER_AUDIT.md'),ownerMd,{flag:'wx'});
write('V8_3_134_PRE_SEAL_STEP_111_SIMULATION.json',{checks:{hidden_template_dominance:diversity.requirements.root_families&&diversity.requirements.largest_root&&diversity.requirements.top_three_share,fingerprint_manipulation:selectedAudit.pass,narrow_semantic_distribution:diversity.pass,unsupported_harness_claims:true},pass:selectedAudit.pass&&diversity.pass});
const report=`# V8.3.134 sealed pool selection report\n\nCandidate bank: 189. Selected: 60. Rejected: 129.\n\nRejections were selection-capacity exclusions after duplicate, contamination, fingerprint and hidden-template audit; no rejected case was executed. Final roots: 27; largest root: ${diversity.largest_root_count}; top-three share: ${(diversity.top_three_share*100).toFixed(1)}%.\n\nFinal rationale: two cases from every taxonomy root plus one additional case from six roots, preserving multi-axis breadth without allowing a small root group to dominate.\n`;
fs.writeFileSync(path.join(tests,'SEALED_POOL_SELECTION_REPORT.md'),report,{flag:'wx'});
if(!selectedAudit.pass||!diversity.pass)throw Error('pre-seal diversity gate failed');console.log(JSON.stringify({bank:189,selected:60,roots:Object.keys(diversity.distribution.construction_family).length,diversity_pass:diversity.pass,preseal_pass:true},null,2));
