const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),t=path.join(root,'tests');const batch=process.argv[2];
if(!['A','B'].includes(batch))throw Error('usage: node scripts/v83128-run-sealed-batch.cjs A|B');
const outCase=path.join(t,`BATCH_${batch}_FIRST_RUN_CASE_LEVEL.json`),outSummary=path.join(t,`BATCH_${batch}_FIRST_RUN_SUMMARY.json`);
if(fs.existsSync(outCase)||fs.existsSync(outSummary))throw Error(`Batch ${batch} evidence already exists; rerun prohibited`);
const ledger=path.join(t,'FIRST_RUN_EXECUTION_LEDGER.json'),lines=fs.readFileSync(ledger,'utf8').trim().split('\n').map(JSON.parse);
if(lines.some(x=>x.batch===batch))throw Error(`Batch ${batch} already present in append-only ledger`);
if(batch==='B'){
  const a=JSON.parse(fs.readFileSync(path.join(t,'BATCH_A_FIRST_RUN_SUMMARY.json'),'utf8'));
  if(a.status!=='PASS'||a.passed!==30||a.total!==30)throw Error('Batch B prohibited because Batch A did not pass 30/30');
}
process.env.PSC_V83127='1';const {loadCore}=require('../tests/v83117-helper.cjs');const core=loadCore();
const pool=JSON.parse(fs.readFileSync(path.join(t,'SEALED_POOL_60.json'),'utf8'))[`batch_${batch}`];
const gold=JSON.parse(fs.readFileSync(path.join(t,'SEALED_POOL_GOLD.json'),'utf8')).cases.filter(x=>x.batch===batch);
const goldById=new Map(gold.map(x=>[x.case_id,x]));const started=new Date().toISOString();
const results=pool.map((item,index)=>{const contract=goldById.get(item.case_id);if(!contract)throw Error(`missing gold ${item.case_id}`);const frame=core.analyze(item.input,'work');const actual={families:[...frame.families],route:frame.input_route.id,sequence:!!frame.sequence};const expected=contract.expected;return{case_id:item.case_id,batch,run_ordinal:1,execution_index:index+1,input:item.input,input_sha256:crypto.createHash('sha256').update(item.input).digest('hex'),expected,actual,pass:JSON.stringify(actual)===JSON.stringify(expected),executed_at:new Date().toISOString(),source_hash:'d5d16025ecdf7c15c613075fd146ae8684ff5a10107367b9a7cec0ef1496d572',config_hash:'987db1f5d99e009b7bc576d3b79bfd30891214c192e12e1202c395a645b371cc',schema_hash:'0f64654035ed5d03ce1cb5d1a088da8b35b8256e3abd46236554584a0e5f785d'};});
const finished=new Date().toISOString(),passed=results.filter(x=>x.pass).length,status=passed===30?'PASS':'FAIL';
const caseEvidence={version:'V8.3.128',batch,classification:'FIRST_RUN_CASE_LEVEL_IMMUTABLE_EVIDENCE',run_ordinal:1,started_at:started,finished_at:finished,results};
const summary={version:'V8.3.128',batch,classification:'FIRST_RUN_ONLY',run_ordinal:1,status,passed,total:30,failed:30-passed,failed_case_ids:results.filter(x=>!x.pass).map(x=>x.case_id),expected_changed_after_execution:false,source_changed_after_execution:false,rerun:false};
fs.writeFileSync(outCase,JSON.stringify(caseEvidence,null,2)+'\n',{flag:'wx'});fs.writeFileSync(outSummary,JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const fd=fs.openSync(ledger,'a');for(const result of results)fs.writeSync(fd,JSON.stringify({record_type:'CASE_EXECUTION',version:'V8.3.128',batch,case_id:result.case_id,execution_count_before:0,execution_count_after:1,run_ordinal:1,executed_at:result.executed_at,pass:result.pass})+'\n');fs.closeSync(fd);
console.log(JSON.stringify(summary,null,2));if(status!=='PASS')process.exitCode=1;
