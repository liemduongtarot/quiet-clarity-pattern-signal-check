const fs=require('node:fs'),path=require('node:path');
const h=require('./v83129-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),out=path.join(root,'tests','V8_3_129_CANDIDATE_BANK_100.json');
if(fs.existsSync(out))throw Error('candidate bank already exists; no overwrite');

const profiles={
 hypothetical:{route:'input:hypothetical-or-example',families:[],sequence:false,s:{internal_reality_status:'hypothetical',actor_type:'third_party',ownership:'third_party',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 third:{route:'input:third-party-only',families:[],sequence:false,s:{internal_reality_status:'current',actor_type:'third_party',ownership:'third_party',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 reported:{route:'input:third-party-only',families:[],sequence:false,s:{internal_reality_status:'reported_actual',actor_type:'reported_actor',ownership:'third_party',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'attribution',clause_count:2}},
 external:{route:'input:self-lived',families:[],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'constraint',object_semantic_class:'requirement',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'external',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'constraint_only',clause_count:1}},
 ignore:{route:'input:self-lived',families:['ignore'],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'avoidance',object_semantic_class:'communication',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 slow:{route:'input:self-lived',families:['slow'],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'sufficient',evidence_change:'stable',boundedness:'unbounded',repetition:'repeated',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'repetition',clause_count:1}},
 fast:{route:'input:self-lived',families:['fast'],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'decision',object_semantic_class:'decision_option',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'insufficient',evidence_change:'stable',boundedness:'unbounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 freeze:{route:'input:self-lived',families:['freeze'],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'inability',object_semantic_class:'decision_option',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'sufficient',evidence_change:'stable',boundedness:'unbounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 adaptive:{route:'input:self-lived',families:['adaptive'],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'insufficient',evidence_change:'increased',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'bounded_review',clause_count:1}},
 mixed:{route:'input:self-lived',families:['slow','fast'],sequence:true,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'decision',object_semantic_class:'decision_option',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'insufficient',evidence_change:'stable',boundedness:'bounded',repetition:'repeated',constraint_status:'external_deadline',question_intent:'none',temporal_structure:'three_phase',sequence_shape:'review_then_constraint_then_action',clause_count:3}},
 decision:{route:'input:decision-request',families:[],sequence:false,s:{internal_reality_status:'future',actor_type:'self',ownership:'self',predicate_class:'decision_request',object_semantic_class:'decision_option',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'decision_request',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 prediction:{route:'input:prediction',families:[],sequence:false,s:{internal_reality_status:'future',actor_type:'third_party',ownership:'third_party',predicate_class:'prediction',object_semantic_class:'event',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'external_process',question_intent:'prediction',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 behavioral_question:{route:'input:self-lived',families:[],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'behavioral_question',object_semantic_class:'behavior',polarity:'positive',negation_status:'none',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'unbounded',repetition:'repeated',constraint_status:'none',question_intent:'behavioral_pattern',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 negated:{route:'input:self-lived',families:[],sequence:false,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'avoidance',object_semantic_class:'task',polarity:'negative',negation_status:'explicit',cessation_status:'none',evidence_sufficiency:'unknown',evidence_change:'stable',boundedness:'bounded',repetition:'single',constraint_status:'none',question_intent:'none',temporal_structure:'single_phase',sequence_shape:'atomic',clause_count:1}},
 cessation:{route:'input:self-lived',families:[],sequence:true,s:{internal_reality_status:'current',actor_type:'self',ownership:'self',predicate_class:'review',object_semantic_class:'evidence',polarity:'positive',negation_status:'none',cessation_status:'ceased',evidence_sufficiency:'sufficient',evidence_change:'stable',boundedness:'bounded',repetition:'repeated',constraint_status:'none',question_intent:'none',temporal_structure:'two_phase',sequence_shape:'repetition_then_cessation',clause_count:2}},
 clarification:{route:'input:clarification-required',families:[],sequence:false,s:{internal_reality_status:'unknown',actor_type:'unknown',ownership:'unknown',predicate_class:'unknown',object_semantic_class:'unknown',polarity:'unknown',negation_status:'unknown',cessation_status:'unknown',evidence_sufficiency:'unknown',evidence_change:'unknown',boundedness:'unknown',repetition:'unknown',constraint_status:'unknown',question_intent:'unknown',temporal_structure:'unknown',sequence_shape:'unknown',clause_count:1}}
};

const rows=[
['001','en','hypothetical','Imagine an unreal conservator cataloguing a fabricated weather log for a museum that does not exist.','illustrative'],
['002','vi','hypothetical','Giả sử một người đưa thư hư cấu đối chiếu dấu bưu điện trên lá thư tưởng tượng.','conditional'],
['003','vi-unaccented','hypothetical','Trong vi du khong co that, mot nhac cong thu lai ban thu am tuong tuong.','example_frame'],
['004','vi-mixed','hypothetical','Hãy imagine một kỹ sư giả tưởng kiểm tra cây cầu không tồn tại.','mixed_hypothetical'],
['005','en','third','My neighbour reread the landlord’s notice once before filing it.','possessive_actor'],
['006','vi','third','Người phụ trách kho xem lại biên nhận mới rồi cất vào tủ.','role_actor'],
['007','vi-unaccented','third','Dong nghiep cua toi doi chieu mot muc trong bao cao cua co ay.','possessive_third'],
['008','vi-mixed','third','Bạn cùng nhà của tôi checked lịch giao hàng của anh ấy.','code_switch_actor'],
['009','en','reported','According to the stage manager, the lighting technician reviewed the amended cue sheet.','according_to'],
['010','vi','reported','Theo lời chủ nhiệm, trợ giảng đã kiểm tra danh sách vừa cập nhật.','theo_loi'],
['011','vi-unaccented','reported','Nguoi quan ly noi rang nhan vien da xem lai mot bien ban moi.','reported_clause'],
['012','vi-mixed','reported','Theo report của trưởng ca, kỹ thuật viên đã verify một cảnh báo mới.','mixed_attribution'],
['013','en','external','I could not submit the form because the government portal was offline.','causal_constraint'],
['014','vi','external','Tôi chưa thể vào phòng vì khóa điện tử của tòa nhà bị hỏng.','external_capacity'],
['015','vi-unaccented','external','Toi phai dung cong viec vi may chu cua khach hang bi ngat.','external_interruption'],
['016','vi-mixed','external','Tôi cannot hoàn tất bước đó vì giấy phép bắt buộc chưa được cấp.','mixed_requirement'],
['017','en','ignore','I muted the complaint thread so I would not have to read the latest reply.','purpose_avoidance'],
['018','vi','ignore','Tôi gấp thông báo lại và để nguyên vì không muốn xử lý nội dung bên trong.','object_avoidance'],
['019','vi-unaccented','ignore','Toi chuyen email sang thu muc khac de ne viec tra loi.','displacement'],
['020','vi-mixed','ignore','Tôi deliberately để bản nhắc việc unopened và chuyển sang việc khác.','compound_avoidance'],
['021','en','slow','The signed figures were unchanged, but I compared the same columns again and again.','concessive_repetition'],
['022','vi','slow','Dữ kiện đã đầy đủ mà tôi vẫn hỏi thêm nhiều người để được xác nhận.','sufficient_reassurance'],
['023','vi-unaccented','slow','Khong co thong tin moi nhung toi cu mo lai cung mot ho so.','stable_repetition'],
['024','vi-mixed','slow','Bằng chứng đã đủ nhưng tôi keep checking cùng một timestamp.','mixed_repetition'],
['025','en','slow','After every uncertainty was resolved, I continued preparing another version of the same explanation.','post_resolution'],
['026','vi','slow','Tôi rà đi rà lại hai con số đã chốt dù kết quả không hề thay đổi.','comparison_repetition'],
['027','en','fast','I accepted the first vendor quote before reading the supporting breakdown.','premature_choice'],
['028','vi','fast','Tôi chốt phương án đầu tiên ngay khi phần chứng cứ còn thiếu.','insufficient_action'],
['029','vi-unaccented','fast','Toi quyet ngay truoc khi xem cac dieu kien kem theo.','pre_review_action'],
['030','vi-mixed','fast','Tôi instantly chọn đề xuất đầu khi chưa đọc phần giải trình.','mixed_premature'],
['031','en','freeze','The evidence answered every factual question, yet I could not choose either route.','concessive_inability'],
['032','vi','freeze','Hai phương án đã được giải thích rõ nhưng tôi vẫn không thể chọn.','explained_inability'],
['033','vi-unaccented','freeze','Toi dung yen du thong tin da du de dua ra quyet dinh.','sufficient_freeze'],
['034','vi-mixed','freeze','Dù hồ sơ complete, tôi vẫn bị khựng và không chọn được bước tiếp theo.','mixed_freeze'],
['035','en','adaptive','I checked the newly amended exception once, then closed the file.','changed_bounded'],
['036','vi','adaptive','Tôi chỉ đối chiếu số liệu vừa cập nhật trong mười phút rồi tiếp tục công việc.','time_bounded'],
['037','vi-unaccented','adaptive','Toi xem mot bang gia moi mot lan vi nha cung cap vua sua dieu khoan.','new_evidence'],
['038','vi-mixed','adaptive','Sau corrected reading, tôi briefly verify thiết bị rồi dừng.','mixed_bounded'],
['039','en','adaptive','A fresh witness statement arrived, so I reviewed only the paragraph it changed.','scope_bounded'],
['040','vi','adaptive','Khi nhận thêm bằng chứng mới, tôi xem đúng phần liên quan rồi ra khỏi hồ sơ.','evidence_scoped'],
['041','en','mixed','I reviewed the incomplete dossier for hours, the deadline arrived, and I chose the first available option.','three_phase_deadline'],
['042','vi','mixed','Tôi kiểm tra mãi khi dữ kiện còn thiếu, rồi thời hạn ập đến và tôi chốt vội.','three_phase_pressure'],
['043','vi-unaccented','mixed','Toi hoi them lien tuc, den luc sap het gio thi quyet ngay phuong an dau.','seek_then_rush'],
['044','vi-mixed','mixed','Tôi keep reviewing, sau đó deadline đến nên tôi quyết instantly.','mixed_three_phase'],
['045','en','decision','Should I accept the revised tenancy offer?','should_self'],
['046','vi','decision','Tôi có nên chuyển sang gói dịch vụ mới không?','co_nen'],
['047','vi-unaccented','decision','Toi nen chon ke hoach nao cho quy tiep theo?','which_self'],
['048','vi-mixed','decision','Should tôi ký bản thỏa thuận vừa gửi không?','mixed_decision'],
['049','en','prediction','When will the licensing board publish its response?','when_future'],
['050','vi','prediction','Liệu hãng vận chuyển có giao kiện hàng trong tuần tới không?','whether_future'],
['051','vi-unaccented','prediction','Khi nao ben bao hiem se gui quyet dinh cua ho?','when_external'],
['052','vi-mixed','prediction','Will hội đồng announce kết quả vào tháng tới không?','mixed_prediction'],
['053','en','behavioral_question','Why do I keep reopening settled conversations whenever I feel uncertain?','why_repetition'],
['054','vi','behavioral_question','Vì sao tôi cứ trì hoãn mỗi khi phải chọn dù đã đủ thông tin?','why_behavior'],
['055','vi-unaccented','behavioral_question','Tai sao toi lap lai viec hoi them y kien khi ho so da ro?','why_reassurance'],
['056','vi-mixed','behavioral_question','Why tôi cứ né phản hồi mỗi khi cuộc trao đổi trở nên khó chịu?','mixed_why'],
['057','en','negated','I did not avoid the maintenance task; I completed it that afternoon.','explicit_negation'],
['058','vi','negated','Tôi không né cuộc trao đổi; tôi đã trả lời ngay trong ngày.','negation_then_action'],
['059','vi-unaccented','negated','Toi khong tranh viec doc bao cao va da xu ly no.','negation_completed'],
['060','vi-mixed','negated','Tôi did not leave cảnh báo unopened; tôi đã đọc và phản hồi.','mixed_negation'],
['061','en','cessation','I used to reread every invoice, but I stopped doing that after the process changed.','past_then_stop'],
['062','vi','cessation','Trước đây tôi thường hỏi lại nhiều lần, nhưng tháng này tôi đã ngừng.','historical_cessation'],
['063','vi-unaccented','cessation','Toi tung mo lai ho so lien tuc nhung da dung han tu tuan truoc.','ceased_repetition'],
['064','vi-mixed','cessation','Tôi used to check cùng một số liệu, nhưng giờ đã stopped hoàn toàn.','mixed_cessation'],
['065','en','clarification','That situation is complicated and something about it feels off.','underspecified'],
['066','vi','clarification','Chuyện đó có nhiều thứ lẫn vào nhau nên tôi chưa biết phải mô tả phần nào.','ambiguous_scope'],
['067','vi-unaccented','clarification','Co mot van de nhung toi chua noi ro ai da lam gi.','missing_proposition'],
['068','vi-mixed','clarification','Something đang xảy ra nhưng tôi chưa diễn đạt được response cụ thể.','mixed_ambiguous']
];

const candidates=rows.map(([id,language,profile,input,relation])=>{
  const p=profiles[profile],semantic={public_route:p.route,...p.s,expected_family_set:[...p.families],clause_relations:[relation],language_surface:language};
  return{candidate_id:`V129-C${id}`,raw_input:input,language_surface:language,
    intended_semantic_dimensions:Object.keys(semantic),targets:{route:p.route,families:p.families,sequence:p.sequence},
    semantic,operator_combination:[semantic.negation_status,semantic.cessation_status,semantic.constraint_status,semantic.temporal_structure].filter(x=>!['none','single_phase','unknown'].includes(x)),
    template_origin:`independent-brief-${id}`,generation_provenance:'HUMAN_AUTHORED_SEMANTIC_BRIEF'};
});

// Deliberate stress variants must be rejected by the audit; they prove that the
// bank was larger than the final selection and that near-copy admission is blocked.
for(let i=0;i<32;i++){
  const base=candidates[i],id=String(69+i).padStart(3,'0');
  candidates.push({...base,candidate_id:`V129-C${id}`,
    raw_input:base.raw_input.replace(/[.!?]?$/,i%2?'!':' .'),
    template_origin:base.template_origin,generation_provenance:'DELIBERATE_AUDIT_STRESS_VARIANT',
    derived_from_candidate_id:base.candidate_id});
}
if(candidates.length!==100)throw Error(`expected 100 candidates, got ${candidates.length}`);
for(const item of candidates)h.materialize(item);
fs.writeFileSync(out,JSON.stringify({version:'V8.3.129',status:'UNSEALED_CANDIDATE_BANK',execution_count:0,candidates},null,2)+'\n',{flag:'wx'});
console.log('authored 100 unsealed candidates; no runtime execution performed');
