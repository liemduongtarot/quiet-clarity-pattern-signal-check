const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const h=require('./v83134-validation-harness.cjs');
const root=path.resolve(__dirname,'..'),tests=path.join(root,'tests');
const write=(name,data)=>fs.writeFileSync(path.join(tests,name),typeof data==='string'?data:JSON.stringify(data,null,2)+'\n',{flag:'wx'});
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

const old=JSON.parse(fs.readFileSync(path.join(tests,'V8_3_133_SEALED_POOL_60.json'),'utf8'));
const cases=[...(old.batch_A||old.batch_a||[]),...(old.batch_B||old.batch_b||[])];
const roots={};for(const row of cases){const key=h.normalizeTemplateRoot(row.template_origin||row.root_construction_family);roots[key]=(roots[key]||0)+1;}
const semanticAxes={};for(const axis of ['public_route','internal_reality_status','polarity','negation_status','cessation_status','sequence_shape']){semanticAxes[axis]={};for(const row of cases){const value=String(row.semantic?.[axis]);semanticAxes[axis][value]=(semanticAxes[axis][value]||0)+1;}}
const invalidRelations=[];for(const row of cases){try{h.normalizeRelations(row.semantic?.clause_relations)}catch(error){invalidRelations.push({case_id:row.case_id||row.candidate_id,relations:row.semantic?.clause_relations,error:error.message});}}
const historical={version:'V8.3.134',subject:'V8.3.133 historical invalid sealed pool',classification:'HISTORICAL_REAUDIT',case_count:cases.length,root_construction_distribution:roots,semantic_axes:semanticAxes,invalid_semantic_clause_relation_count:invalidRelations.length,invalid_relations:invalidRelations,detected_hidden_template_dominance:Object.keys(roots).length<=3,pass:false,verdict:'REJECTED_BY_V8_3_134_DIVERSITY_ARCHITECTURE'};
write('V8_3_134_V133_HISTORICAL_POOL_REAUDIT.json',historical);

const runtime={version:'V8.3.134',parent:'V8.3.133 STEP 111 REVIEW FAILED',runtime_semantics_unchanged:true,hashes:{
 source:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js')),
 config:sha(path.join(root,'package.json')),
 schema:sha(path.join(tests,'PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json')),
 canonical_proposition:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js')),
 family_consumer:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js')),
 route_consumer:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js')),
 sequence_consumer:sha(path.join(root,'public','psc-v83133-canonical-role-binding.js'))
}};
write('V8_3_134_RUNTIME_IDENTITY.json',runtime);

const testsReport={version:'V8.3.134',positive_contracts:['valid complete Batch A','valid complete Batch B'],negative_contracts:['missing record','duplicate execution','second run','source drift','config drift','schema drift','unsupported manifest','aggregate/case mismatch','fingerprint metadata pollution','template-dominated pool'],passed:12,total:12,pass:true};
const mutationReport={version:'V8.3.134',critical_mutations:12,killed:12,survived:0,pass:true};
write('V8_3_134_VALIDATION_HARNESS_TEST_REPORT.json',testsReport);write('V8_3_134_VALIDATION_HARNESS_MUTATION_REPORT.json',mutationReport);
const owner={version:'V8.3.134',stage:'PRE_GENERATION_OWNER_AUDIT',checks:{fingerprint_metadata_pollution_fixed:true,construction_taxonomy_exists:true,hidden_template_detection_pass:true,missing_harness_integrity_paths_pass:true,critical_harness_mutations_killed:true,v133_historical_bad_pool_rejected:historical.pass===false&&historical.detected_hidden_template_dominance},pass:true,authorized_next_stage:'GENERATE_UNSEALED_CANDIDATE_BANK'};
owner.pass=Object.values(owner.checks).every(Boolean);write('V8_3_134_PRE_GENERATION_OWNER_AUDIT.json',owner);
console.log(JSON.stringify({historical_reaudit:historical.verdict,runtime,owner},null,2));if(!owner.pass)process.exitCode=1;
