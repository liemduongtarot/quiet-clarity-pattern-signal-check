# V8.3.121 reconstruction specification

Version: `V8.3.121-R1-RECONSTRUCTED`  
Parent: V8.3.117 surviving authority (`a08c0729...d43`)  
Target reference: V8.3.121 failed Review Candidate  
Provenance: reconstructed  
Original source available: false

## Evidence basis

1. Executable V8.3.117 source/config/schema/tests.
2. Transcript evidence for V8.3.118–121, including immutable first-run verdicts and failure-family summaries.
3. The locked V8.3.122 command, which documents intended normalization, predicate, attribution, negation and temporal architecture.
4. Governance reference and older preview files as non-authoritative context.

Counts alone are never treated as implementation rules. Each rule below has an explicit semantic rationale and replacement regression.

## Intentional semantic reconstruction

- **Proposition/clause representation:** split temporally linked clauses into ordered phases with `phase_id`, subject, source, predicate, negation, temporal state, evidence state and external-constraint flag.
- **Third-party ownership:** behavior owned by a colleague/other subject is not attributed to the user. Third-party-only input stops for clarification.
- **Attribution and quotation:** distinguish direct self-report, attributed-self, attributed-third-party, confirmed attribution and disputed attribution. `X said...` and `theo lời X...` scope only the reported claim.
- **Noun/verb composition:** grammatical ownership and compound predicates take precedence over isolated tokens.
- **Modifier handling:** repetition, boundedness, sufficiency and external reasons modify predicate meaning rather than becoming independent response families.
- **Certainty vs evidence sufficiency:** “certain” language is not automatically evidence sufficiency; sufficient/clear evidence supports adaptive precedence only when the behavior is bounded/proportionate.
- **Negation:** `NOT(avoid)` removes avoidance evidence; it does not erase an independently repeated slow mechanism.
- **Cessation/current/history:** `no longer/không còn` marks the described mechanism ceased or historical; it cannot become an active current pattern without current evidence.
- **External constraint:** technical impossibility, surgery, authority or capacity can block action without creating freeze behavior by itself.
- **Adaptive precedence:** bounded review for a genuinely unclear detail, required checking, proportionate action and evidence-responsive revisit are neutral/adaptive; repeated checking after sufficiency remains slow.
- **Sequence vs mixed:** temporal connectors preserve order (`ignore → slow → fast`); unordered co-occurrence remains mixed.
- **Known V8.3.121 failures:** unaccented inability, compound unopened avoidance, director attribution, evidence revisit sequence, negated avoidance with bounded review, and `theo lời` attribution are represented at predicate/operator level.

## Historical regression obligations

Exact original inputs/contracts do not survive for FUH-006, FUH-013, U2H-018, SVP-024, SVP-059, the ten V8.3.120 failures, the six original holdout gaps or the six PCH cases. They are therefore marked `HISTORICAL CASE DEFINITION INCOMPLETE`.

Separate replacement regressions cover:

- contextual resource review vs genuine slow checking;
- sufficiency-driven adaptive action;
- avoidance continuing through delay then fast action;
- third-party ownership;
- natural information-seeking composition;
- all six named PCH families;
- accented, unaccented, mixed Vietnamese and English surfaces;
- 320 generated adversarial surfaces and 100 contrast pairs.

The ten V8.3.120 original Batch A cases remain `NOT REPRODUCIBLE FROM SURVIVING ARTIFACTS`; replacement tests cover their documented families but are not historical evidence.
