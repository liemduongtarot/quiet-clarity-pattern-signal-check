# Pattern Signal Check recovery version graph

`V8.3.117 surviving source authority`

→ V8.3.118 failed RC (transcript only; FUH-006/FUH-013 repair; U2H-018 first-run failure)

→ V8.3.119 failed RC (transcript only; U2H-018 repair; SVP-024/SVP-059 first-run failures)

→ V8.3.120 failed RC (transcript only; commit referenced but missing; ten Batch A failures)

→ V8.3.121 failed RC (transcript only; source/evidence commits referenced but missing; six PCH failures)

↘ `V8.3.121-R1-RECONSTRUCTED` (new source; parent is V8.3.117; target reference is V8.3.121)

Future allowed parent after archive PASS:

`V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE` → `V8.3.122`

Step 111 and production lock remain prohibited.
