# V8.3.121-R1 reconstructed recovery baseline hashes

- Frozen source commit: `aaa205bb30de0cdce146f0dc1a8b5bbc54444428`
- Reconstruction layer SHA256: `335766aba72677e20c444b9490a0e1ab98721f8ac579bdee51f990ac6368ab70`
- Source/schema aggregate SHA256 (`psc-v3` + `psc-v4` + reconstruction layer): `d29036c1c9b91f52afcd583158220a499887088c1bd31ae2fd42f18df8944600`
- Config aggregate SHA256 (`package.json` + `.openai/hosting.json`): `6a4d33c9d6e9fa31ed3fe068179eb870cc25d2dcb476751deb446e7da1c5d24b`
- Pre-archive baseline aggregate SHA256 (source, config and reconstruction tests): `77bc678d4bf839f738f1f7c9368fa3dc67cf39b61b7e8a680595bd12d71b29c0`

These hashes identify the reconstructed baseline only. They do not recover or replace either referenced original V8.3.121 commit.
