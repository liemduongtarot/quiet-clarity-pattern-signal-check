# V8.3.121-R1 reconstruction equivalence report

## Classification by area

| Area | Equivalence | Basis |
|---|---|---|
| V8.3.117 source/config/questionnaire/result engine | **EXACTLY REPRODUCED** | Surviving bytes are the direct parent. |
| V8.3.117 atomic, pairwise, property, edge and real-case gates | **EXACTLY REPRODUCED** | Original surviving test files run on reconstructed layer and pass. |
| Third-party/attribution semantics | **FUNCTIONALLY EQUIVALENT** | Implemented from documented rules; replacement regressions pass; original 121 bytes absent. |
| Predicate/clause/temporal representation | **FUNCTIONALLY EQUIVALENT** | New explicit representation satisfies documented behavior; byte identity impossible. |
| Negation, cessation, external constraint, adaptive precedence | **FUNCTIONALLY EQUIVALENT** | Replacement contrasts pass; exact 121 corpus absent. |
| FUH/U2H/SVP/PCH historical cases | **PARTIALLY RECOVERED** | IDs, expected concepts and failure modes survive; exact original contracts/prompts do not. |
| V8.3.118–120 reports/manifests/pools | **NOT RECOVERABLE** | Only transcript evidence and obsolete paths survive. |
| V8.3.120 ten Batch A case definitions | **NOT RECOVERABLE** | Only seven broad semantic categories survive. |
| V8.3.121 source/config/schema hashes | **NOT RECOVERABLE** | Referenced commits absent; no deployed source. |
| V8.3.121 60-case pool and first-run JSON | **NOT RECOVERABLE** | Counts and six family labels survive, not bytes. |
| Reported V8.3.121 pre-holdout counts | **PARTIALLY RECOVERED** | Counts retained as transcript evidence; equivalent replacement gates pass but are not called historical runs. |

## Reconstructed gate results

- Surviving V8.3.117 historical gates on reconstructed layer: PASS.
- Replacement atomic scope: 73,178/73,178.
- Replacement pairwise obligations: 483/483; 3,680 executed journeys.
- Replacement high-risk three-way: 12/12.
- Surviving property executions: 100,000/100,000.
- Replacement adversarial: 320/320.
- Replacement contrast pairs: 100/100.
- Surviving edge cases: 100/100.
- Surviving real cases: 600/600.
- Surviving critical mutation contract: 20/20.
- Replacement mutation campaign: critical subset 55/55; overall 95/95. This is replacement evidence, not recovered V8.3.121 mutation evidence.
- Build/artifact validation: PASS.
- Browser E2E: PASS (landing, questionnaire entry, topic selection, reconstructed semantic input route; no application console error).

## Verdict

The candidate is not “the same source as V8.3.121.” It is a traceable functional reconstruction from V8.3.117 plus surviving transcript/command evidence. Areas lacking original corpora remain explicitly limited.

Subject to archive hash/audit completion, status may become `RECONSTRUCTED RECOVERY BASELINE`; never canonical production and never original V8.3.121.
