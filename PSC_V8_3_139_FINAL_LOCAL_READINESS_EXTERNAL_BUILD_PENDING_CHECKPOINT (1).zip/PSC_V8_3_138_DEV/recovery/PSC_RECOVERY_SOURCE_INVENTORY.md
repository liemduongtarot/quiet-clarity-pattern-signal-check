# Pattern Signal Check recovery source inventory

Status: recovery evidence inventory; not production authority.  
Audit date: 2026-08-15.  
Step 111: prohibited. Production lock: prohibited.

| Artifact | Version | Status | Source location / reference | Hash | Recoverability | Authority level | Notes |
|---|---|---|---|---|---|---|---|
| Git checkout source | V8.3.117 | present | repository checkout | `a08c0729d82e533c6604834380d27ea2793f9d43` | recoverable | latest surviving executable authority | Source, config, parser/schema and tests present. |
| `public/psc-v3.js` | V8.3.117 parent layer | present | checkout | `886936b9...ac` | recoverable | surviving implementation | Full hash in SHA256 manifest. |
| `public/psc-v4.js` | V8.3.117 | present | checkout | `43431840...02f` | recoverable | surviving implementation | Full hash in SHA256 manifest. |
| V8.3.117 test/report set | V8.3.111–117 | present | `tests/` | per-file manifest | recoverable | surviving evidence | Includes atomic, property, mutation, edge, real-case and holdout files through 117. |
| Current deployed Sites checkout | V8.3.117 | present | Site checkout | same Git parent | recoverable | deployed/source authority through 117 only | Site production was not changed during recovery. |
| V8.3.118 status/report/holdout paths | V8.3.118 | transcript references only | historical sandbox paths supplied by Liam | none | **MISSING / NOT RECOVERABLE** | transcript evidence | First-run 29/30; U2H-018. Paths no longer exist. |
| V8.3.119 report/manifest/pool paths | V8.3.119 | transcript references only | historical sandbox paths supplied by Liam | none | **MISSING / NOT RECOVERABLE** | transcript evidence | Batch A first-run 28/30; SVP-024/SVP-059. |
| V8.3.120 report/pool paths | V8.3.120 | transcript references only | historical sandbox paths supplied by Liam | none | **MISSING / NOT RECOVERABLE** | transcript evidence | Batch A first-run 20/30; ten case definitions absent. |
| V8.3.120 failed-RC commit | V8.3.120 | referenced | `0920372d90b04458801c57ed904d56cd0b172acf` | commit reference | **COMMIT REFERENCED / OBJECT NOT RECOVERABLE** | transcript evidence | `git cat-file` cannot resolve it. |
| V8.3.121 original source | V8.3.121 | absent | prior workspace only | referenced source hash `7495d50...e73` | **MISSING / NOT RECOVERABLE** | transcript evidence only | Not deployed; no byte recovery possible. |
| V8.3.121 evidence freeze | V8.3.121 | absent | prior workspace only | referenced `0a76961...f23` | **MISSING / NOT RECOVERABLE** | transcript evidence only | Git object unavailable. |
| V8.3.121 Final Acceptance Report | V8.3.121 | path referenced | historical sandbox path | none | **MISSING / NOT RECOVERABLE** | transcript evidence | Summary supplied: pre-holdout pass, Batch A 24/30. |
| V8.3.121 Acceptance Manifest | V8.3.121 | path referenced | historical sandbox path | none | **MISSING / NOT RECOVERABLE** | transcript evidence | No original bytes. |
| V8.3.121 Batch A first-run | V8.3.121 | path referenced | historical sandbox path | none | **MISSING / NOT RECOVERABLE** | transcript evidence | Six named failure families survive; exact contracts do not. |
| V8.3.121 Review Candidate status | V8.3.121 | path referenced | historical sandbox path | none | **MISSING / NOT RECOVERABLE** | transcript evidence | Failed RC; Step 111 prohibited. |
| V8.3.121 sealed pool/manifest | V8.3.121 | path referenced | historical sandbox path | none | **MISSING / NOT RECOVERABLE** | transcript evidence | 60 cases, zero exact overlap reported; prompts absent. |
| `Pasted text(2).txt` | V8.3.122 locked command | present | saved project file | Library-backed file | recoverable | command/spec evidence | Provides intended semantic architecture and six failure analyses, not V8.3.121 source. |
| Governance reference v1.0 | reference | present | supplied file | Library-backed file | recoverable | reference only | Explicitly not execution authority. |
| V8.3.33/V8.3.35 previews | legacy | present | supplied files | Library-backed files | recoverable | legacy evidence | Older than recovery base; cannot override V8.3.117. |
| V8.3.2 audit notes | legacy | present | supplied file | Library-backed file | recoverable | legacy evidence | Historical only. |
| `V8.3.121-R1-RECONSTRUCTED` | reconstructed | created | current checkout | new hashes | recoverable after archive | reconstructed candidate | Parent V8.3.117; target reference V8.3.121; never represented as original. |

## Historical lineage (transcript evidence)

1. V8.3.118 repaired FUH-006/FUH-013; 16/16 expanded regression; new holdout first-run 29/30 failed at U2H-018; no rerun.
2. V8.3.119 repaired U2H-018 at semantic-family level; 30/30 regression; Batch A first-run 28/30 failed at SVP-024/SVP-059; Batch B not run.
3. V8.3.120 broadened semantic composition; pre-holdout 63/63; Batch A first-run 20/30 exposed ten broader gaps; source/expected unchanged after failure.
4. V8.3.121 used proposition/clause work; pre-holdout gates reported pass; Batch A first-run 24/30 failed at PCH-A03/A04/A08/A18/A23/A30; no rerun; Batch B not run.

All failed holdouts ceased to be pristine when later used for repair/regression. Counts and summaries are evidence; they are not source reconstruction material by themselves.
