# Historical failure-regression chain

Important: no exact original case prompt/complete expected contract survives for the rows below. Every row is therefore `HISTORICAL CASE DEFINITION INCOMPLETE`. “Reconstructed actual” refers to a separately labelled replacement fixture, never the historical case itself.

| Case/family | Historical expected | Historical failure mode | Reconstructed replacement actual | Result | Evidence source |
|---|---|---|---|---|---|
| Original holdout: repeated-reading | slow | lexical gap | slow | replacement PASS | prior transcript summary |
| Original holdout: immediate-acceptance | fast | lexical gap | fast | replacement PASS | prior transcript summary |
| Original holdout: leave-unread | ignore | lexical gap | ignore | replacement PASS | prior transcript summary |
| Original holdout: sufficient-evidence | adaptive | precedence gap | adaptive | replacement PASS | prior transcript summary |
| Original holdout: slow→fast | ordered sequence | sequence gap | slow→fast | replacement PASS | prior transcript summary |
| Original holdout: third-party attribution | no self family | ownership gap | third-party-only | replacement PASS | prior transcript summary |
| FUH-006 | fast primary; resource review contextual | slow leakage from “review resources” | fast | replacement PASS | V8.3.118 transcript evidence |
| FUH-013 | adaptive | sufficiency wording missed | adaptive | replacement PASS | V8.3.118 transcript evidence |
| U2H-018 | ignore→fast | actual slow→fast; “né” missed and delay leaked slow | ignore→fast | replacement PASS | V8.3.118/119 transcript evidence |
| SVP-024 | third-party ownership | `my colleague` routed self-lived | third-party-only | replacement PASS | V8.3.119 transcript evidence |
| SVP-059 | slow/information-seeking | `hỏi thêm ý kiến` missed | slow | replacement PASS | V8.3.119 transcript evidence |
| V8.3.120 Batch A failures 1–10 | original contracts absent | ownership, sufficiency, three-phase, cessation, hypothetical, adaptive precedence, leakage | family-level replacements pass | **original cases NOT REPRODUCIBLE** | V8.3.120 transcript evidence |
| PCH-A03 | freeze | Vietnamese unaccented inability missed | freeze | replacement PASS | V8.3.121 transcript evidence |
| PCH-A04 | ignore | English compound leave-unopened missed | ignore | replacement PASS | V8.3.121 transcript evidence |
| PCH-A08 | attribution/third-party ownership | director attribution scope | third-party-only | replacement PASS | V8.3.121 transcript evidence |
| PCH-A18 | ordered revisit sequence | temporal revisit relationship lost | ignore→slow→fast | replacement PASS | V8.3.121 transcript evidence |
| PCH-A23 | no ignore; bounded review adaptive | negation scope/family leakage | adaptive | replacement PASS | V8.3.121 transcript evidence |
| PCH-A30 | attribution/third-party ownership | `theo lời` scope lost | third-party-only | replacement PASS | V8.3.121 transcript evidence |

No historical expected contract was changed. Failed Batch A executions were not rerun. Once used for later development, prior holdouts are regression evidence and are not called pristine.
