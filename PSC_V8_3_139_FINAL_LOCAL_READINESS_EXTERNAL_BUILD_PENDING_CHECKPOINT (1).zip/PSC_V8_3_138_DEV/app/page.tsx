// Internal workspace sites can read the authenticated OpenAI user from the
// forwarded request headers:
//
// import { headers } from "next/headers";
//
// export default async function Home() {
//   const requestHeaders = await headers();
//   const email = requestHeaders.get("oai-authenticated-user-email");
//   const encodedFullName = requestHeaders.get("oai-authenticated-user-full-name");
//   const fullName =
//     encodedFullName &&
//     requestHeaders.get("oai-authenticated-user-full-name-encoding") ===
//       "percent-encoded-utf-8"
//       ? decodeURIComponent(encodedFullName)
//       : null;
//   const displayName = fullName ?? email;
//   // ...
// }

export default function Home() {
  return (
    <main className="min-h-screen bg-zinc-950 p-6 text-zinc-50">
      <h1 className="mb-4 text-lg font-semibold">Pattern Signal Check V8.3.137 — Development Repair Candidate</h1>
      <p className="mb-4 text-sm text-zinc-300">
        Single canonical UI gate authority reconciliation on the unchanged V8.3.135 runtime.
        Not sealed or production-authorized; Step 111 remains prohibited.
      </p>
      <p><a className="underline" href="/candidate.html">Open V8.3.137 candidate</a></p>
    </main>
  );
}
