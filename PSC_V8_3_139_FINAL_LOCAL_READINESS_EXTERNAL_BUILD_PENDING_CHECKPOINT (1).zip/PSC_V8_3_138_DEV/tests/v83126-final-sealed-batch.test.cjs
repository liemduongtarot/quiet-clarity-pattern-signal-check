const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
process.env.PSC_V83126='1';
const {loadCore}=require('./v83117-helper.cjs');
const batch=process.env.PSC_V83126_BATCH;
if(!['A','B'].includes(batch))throw new Error('PSC_V83126_BATCH must be A or B');
const gold=JSON.parse(fs.readFileSync('tests/V8_3_126_FINAL_SEALED_POOL_GOLD.json','utf8'));
const selected=gold[`batch_${batch}`];
test(`V8.3.126 sealed Batch ${batch} locked 30-case first-run`,()=>{
  assert.equal(selected.length,30);const core=loadCore();
  const results=selected.map(row=>{const a=core.analyze(row.prompt,'work'),actual={families:[...a.families],route:a.input_route.id,sequence:a.sequence},expected={families:row.families,route:row.route,sequence:row.sequence};return{id:row.id,expected,actual,pass:JSON.stringify(actual)===JSON.stringify(expected)};});
  process.stdout.write(`\nPSC_V83126_BATCH_RESULT=${JSON.stringify({version:gold.version,batch,first_run:true,total:30,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results})}\n`);
  assert.equal(results.filter(x=>!x.pass).length,0,results.filter(x=>!x.pass).map(x=>x.id).join(','));
});
