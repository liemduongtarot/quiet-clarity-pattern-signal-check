const test=require('node:test'),assert=require('node:assert/strict');process.env.PSC_V83130='1';const{loadCore}=require('./v83117-helper.cjs');const core=loadCore();
const check=(raw,families,route='input:self-lived',sequence=false)=>{const x=core.analyze(raw,'work');assert.deepEqual([...x.families],families,raw);assert.equal(x.input_route.id,route,raw);assert.equal(!!x.sequence,sequence,raw);};
test('400 composed representation-coverage development cases',()=>{let n=0;
 for(let i=0;i<50;i++){
  check(`I could not submit form ${i} because the portal was offline.`,[]);n++;
  check(`My colleague reviewed file ${i} once.`,[],'input:third-party-only');n++;
  check(`I muted message ${i} so that I would not read the reply.`,['ignore']);n++;
  check(`Without new information I reopened the same complete file ${i}.`,['slow']);n++;
  check(`I accepted quote ${i} before reading the supporting breakdown.`,['fast']);n++;
  check(`Despite enough information I remained stuck and could not choose option ${i}.`,['freeze']);n++;
  check(`I reviewed one newly updated figure ${i} for ten minutes.`,['adaptive']);n++;
  check(`In an invented example, someone remained stuck at option ${i}.`,[],'input:hypothetical-or-example');n++;
 }
 assert.equal(n,400);
});
