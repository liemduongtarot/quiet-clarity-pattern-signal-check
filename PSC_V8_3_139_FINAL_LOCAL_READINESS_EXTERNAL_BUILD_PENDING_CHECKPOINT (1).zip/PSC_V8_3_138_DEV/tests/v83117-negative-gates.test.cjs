const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore } = require('./v83117-helper.cjs');
const core = loadCore();

const establishedEvidence = {
  family: 'slow', clarification: 'v3:slow', answers: { A: ['v3:A:slow:1'], E: ['v3:E:slow:1'] },
  reinforcement: 'v3:E:slow:1', repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
};

test('reinforcement negative gate blocks false established classification', () => {
  const frame = core.analyze('Tôi kiểm tra thêm và trì hoãn bắt đầu.', 'work');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, reinforcement: null }).classification, 'situational_or_unreinforced');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, reinforcementUnknown: true }).classification, 'situational_or_unreinforced');
});

test('current-evidence negative gate blocks false active classification', () => {
  const frame = core.analyze('Tôi kiểm tra thêm và trì hoãn bắt đầu.', 'work');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, repetition: -1 }).classification, 'current_status_insufficient');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, currentEvidenceUnknown: true }).classification, 'current_status_insufficient');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, inactiveNow: true }).classification, 'residual_or_old');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, singleOccurrence: true }).classification, 'situational_reaction');
});

test('safety, prediction, decision request, hypothetical and third-party-only inputs cannot create patterns', () => {
  const cases = [
    ['Tôi đang bị đe dọa và không thấy mình an toàn.', 'redirected_out_of_scope'],
    ['Khi nào người đó sẽ quay lại với tôi?', 'redirected_out_of_scope'],
    ['Tôi có nên nghỉ việc không?', 'redirected_out_of_scope'],
    ['Giả sử một người cứ trì hoãn mọi việc thì sao?', 'clarification_required'],
    ['Sếp tôi luôn kiểm tra và trì hoãn mọi quyết định.', 'clarification_required'],
  ];
  for (const [raw, expected] of cases) {
    const frame = core.analyze(raw, 'other');
    assert.equal(core.evaluate(frame, establishedEvidence).classification, expected, raw);
  }
});

test('external constraint without behaviour beyond it cannot create a pattern', () => {
  const frame = core.analyze('Tôi không bắt đầu vì đang chờ phê duyệt và chưa có quyền quyết định.', 'work');
  assert.equal(core.evaluate(frame, { ...establishedEvidence, family: 'freeze', clarification: 'v3:freeze', behaviourBeyondConstraint: false }).classification, 'external_or_capacity_constraint');
});
