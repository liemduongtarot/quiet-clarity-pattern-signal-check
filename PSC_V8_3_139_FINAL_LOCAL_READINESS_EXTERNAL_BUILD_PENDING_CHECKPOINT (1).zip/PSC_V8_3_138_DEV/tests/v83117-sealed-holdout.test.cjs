/* Sealed only after source freeze 7a7f21af54f1d3427bfed6994b8c0c2be1720afa. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, unaccent, mixedAccent } = require('./v83117-helper.cjs');
const core = loadCore();

// These prompts were not used in source development. Expected contracts are
// hand-authored and do not call the production engine to derive gold labels.
const cases = [
  ['slow', 'Trước khi nộp, tôi đọc đi đọc lại dù đã đủ thông tin.', 'Before submitting, I read it repeatedly although I already have enough information.', { family: 'slow' }],
  ['fast', 'Vừa thấy cơ hội là tôi nhận lời ngay, rồi mới xem mình có đủ sức không.', 'As soon as I see an opportunity, I commit immediately and only later check my capacity.', { family: 'fast' }],
  ['freeze', 'Tôi có thể làm việc này nhưng cứ đứng lại, không khởi động được bước đầu.', 'I can do this task but become stuck and cannot start the first step.', { family: 'freeze' }],
  ['ignore', 'Tôi để tin nhắn đó chưa đọc và lấp thời gian bằng những việc ít quan trọng.', 'I leave that message unread and fill my time with less important tasks.', { family: 'ignore' }],
  ['adaptive', 'Tôi kiểm tra phần cần thiết, chốt khi bằng chứng đã đủ và sẵn sàng cập nhật.', 'I check what is necessary, decide when evidence is sufficient and remain ready to update.', { family: 'adaptive', classification: 'adaptive' }],
  ['mixed', 'Tôi chuẩn bị quá lâu rồi sát giờ lại chốt vội.', 'I prepare for too long and then decide hastily near the deadline.', { families: ['slow', 'fast'], sequence: true }],
  ['safety', 'Tôi đang bị bạo lực và không an toàn ở nhà.', 'I am experiencing violence and I am not safe at home.', { route: 'input:safety', classification: 'redirected_out_of_scope', must_redirect: true }],
  ['prediction', 'Bao giờ cô ấy sẽ nhắn lại cho tôi?', 'When will she message me again?', { route: 'input:prediction', classification: 'redirected_out_of_scope', must_redirect: true }],
  ['decision', 'Mình có nên bỏ dự án này không?', 'Should I stop this project?', { route: 'input:decision-request', classification: 'redirected_out_of_scope', must_redirect: true }],
  ['hypothetical', 'Giả sử một người luôn né việc khó thì hệ thống sẽ nói gì?', 'Suppose someone always avoids hard tasks; what would the system say?', { route: 'input:hypothetical', classification: 'clarification_required' }],
  ['third-party', 'Bạn tôi luôn quyết định vội rồi lại đổi ý.', 'My friend always decides hastily and then changes their mind.', { route: 'input:third-party-only', classification: 'clarification_required' }],
  ['emotion-only', 'Tôi thấy vừa buồn vừa thất vọng.', 'I feel both sad and disappointed.', { classification: 'response_unknown' }],
  ['reinforcement-unknown', 'Tôi thường trì hoãn bắt đầu nhưng chưa rõ điều gì đang củng cố việc đó.', 'I often delay starting but do not know what reinforces it.', { family: 'slow', evidence: { reinforcementUnknown: true }, classification: 'situational_or_unreinforced' }],
  ['current-unknown', 'Tôi kiểm tra lại nhiều lần nhưng không đủ ví dụ gần đây để biết nó còn hoạt động không.', 'I recheck repeatedly but lack enough recent examples to know whether it is still active.', { family: 'slow', evidence: { currentEvidenceUnknown: true }, classification: 'current_status_insufficient' }],
  ['single', 'Chỉ đúng một lần tôi trì hoãn và kiểm tra thêm.', 'Exactly once, I delayed and checked further.', { family: 'slow', evidence: { singleOccurrence: true }, forbidden: 'established_pattern' }],
];

function verify(raw, expected) {
  const frame = core.analyze(raw, 'direction');
  const family = expected.family || frame.families[0] || 'slow';
  const result = core.evaluate(frame, {
    family, clarification: `v3:${family}`,
    answers: { A: [`v3:A:${family}:1`], E: [`v3:E:${family}:1`] },
    reinforcement: `v3:E:${family}:1`, repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
    ...(expected.evidence || {}),
  });
  if (expected.route) assert.equal(frame.input_route.id, expected.route);
  if (expected.family) assert.equal(frame.families[0], expected.family);
  if (expected.families) for (const item of expected.families) assert.ok(frame.families.includes(item));
  if (expected.sequence) assert.equal(frame.sequence, true);
  if (expected.classification) assert.equal(result.classification, expected.classification);
  if (expected.must_redirect) assert.equal(result.must_redirect, true);
  if (expected.forbidden) assert.notEqual(result.classification, expected.forbidden);
}

test('post-freeze sealed holdout passes 60/60 independent contracts', () => {
  let total = 0;
  for (const [, vi, en, expected] of cases) {
    for (const raw of [vi, unaccent(vi), mixedAccent(vi), en]) {
      verify(raw, expected);
      total += 1;
    }
  }
  assert.equal(total, 60);
});
