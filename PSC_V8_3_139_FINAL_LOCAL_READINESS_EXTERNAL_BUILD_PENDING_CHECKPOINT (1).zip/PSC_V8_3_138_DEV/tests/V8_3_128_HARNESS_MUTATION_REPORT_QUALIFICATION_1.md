# V8.3.128 Validation Harness Mutation Report

Status: **PASS**

Killed: 10/10 bypass mutations.

```text
✔ M01 killed: raw duplicate cannot be admitted (3.478495ms)
✔ M02 killed: punctuation normalization bypass cannot be admitted (0.381768ms)
✔ M03 killed: identifier substitution bypass cannot be admitted (0.33647ms)
✔ M04 killed: semantic fingerprint collision cannot be admitted (0.290863ms)
✔ M05 killed: threshold inflation is rejected (0.224634ms)
✔ M06 killed: unreviewed near pair is rejected (0.151105ms)
✔ M07 killed: rationale-free waiver is rejected (0.092428ms)
✔ M08 killed: missing semantic field is rejected (3.405906ms)
✔ M09 killed: prior-corpus collision cannot be hidden (0.61855ms)
✔ M10 killed: premature owner approval is rejected (0.363651ms)
ℹ tests 10
ℹ suites 0
ℹ pass 10
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 83.056517
```
