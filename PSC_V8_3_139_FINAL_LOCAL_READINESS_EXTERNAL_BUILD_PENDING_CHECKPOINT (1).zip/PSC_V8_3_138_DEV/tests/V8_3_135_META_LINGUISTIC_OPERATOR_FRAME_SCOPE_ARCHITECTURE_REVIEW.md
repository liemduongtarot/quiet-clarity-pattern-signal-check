# Meta-linguistic operator / frame-scope architecture review

Status: **DESIGN ONLY — NO V8.3.135 IMPLEMENTATION**

Authority: the 24-case forensic matrix at `V8_3_135_REAL600_24_FAILURE_FORENSIC_MATRIX.json`. V8.3.134 and all earlier frozen candidates remain immutable.

## 1. Architectural conclusion

The current architecture confuses a lexical cue with an active discourse operator. In V8.3.132, `giả định|gia dinh` was added to `RX.hypothetical`. `resolveReality()` tests both the local clause and the whole raw document, while `detectFrames()` promotes any document match to `HYPOTHETICAL_SETUP` and assigns every proposition to that frame. No complement, negation, quotation, metalinguistic-use, or scope validation occurs before promotion.

The replacement architecture must treat regex matches as cues only:

`lexical cue → operator-use resolver → operator status → complement validation → scope resolution → reality frame`

Only a validated active operator with a governed propositional scope may write `reality_status` or create a frame.

## 2. Canonical operator-status model

Every cue produces an `OperatorOccurrence`, not a frame:

| Field | Contract |
|---|---|
| `operator_id` | Stable occurrence ID, never inferred from generation metadata. |
| `operator_lexeme` | Exact source text, e.g. `giả định`, `gia dinh`, `assume`, `giả sử`. |
| `normalized_lexeme` | Accent-folded cross-surface identity. |
| `source_span` | Exact start/end and clause ID. |
| `operator_function` | `HYPOTHETICAL_DISCOURSE`, `ASSUMPTION_PREDICATE`, `INTERPRETATION_POLICY`, `QUOTED_DISCOURSE`, or `UNRESOLVED`. |
| `operator_status` | `ACTIVE_OPERATOR`, `MENTIONED_OPERATOR`, `NEGATED_OPERATOR`, `QUOTED_OPERATOR`, `REPORTED_OPERATOR`, or `UNKNOWN`. |
| `complement_type` | `NOMINAL_OBJECT`, `PROPOSITIONAL_COMPLEMENT`, `CLAUSAL_FRAME`, or `NONE/UNKNOWN`. |
| `scope_type` | `NONE`, `LOCAL_PROPOSITION`, `LOCAL_CLAUSE_SET`, `QUOTED_CLAUSE_SET`, or `DOCUMENT_FRAME`. |
| `governed_clause_ids` | Clauses licensed by syntax/discourse structure. Empty unless scope is proved. |
| `governed_proposition_ids` | Propositions whose reality may change. Empty for mention/policy/nominal-object use. |
| `polarity` | Positive, negated, prohibited, or avoided. |
| `quotation_scope_id` | Quotation/report container, if any. |
| `resolution_evidence` | Cue, complement, boundary, negation, attribution and scope evidence used. |
| `producer` | Single authority: `scoped-operator-resolver`. |

`operator_status` is not a behavioral family and does not compete in family ranking.

## 3. Use/mention/status rules

### Active operator

Requires positive evidence that the cue governs a proposition or clause set.

- `Giả định rằng tôi nghỉ việc.` → `ACTIVE_OPERATOR`, `PROPOSITIONAL_COMPLEMENT`, local governed proposition hypothetical.
- `Giả sử tình huống sau: tôi nghỉ việc; sau đó...` → `ACTIVE_OPERATOR`, `CLAUSAL_FRAME`, document/multi-clause scope if continuation evidence is present.

### Mentioned or assumption predicate

A lexical verb with a nominal object describes assumption behaviour; it does not open a frame.

- `hệ thống giả định động cơ`
- `anh ấy giả định ý định của tôi`
- `the model assumes a cause`

These produce `ASSUMPTION_PREDICATE + NOMINAL_OBJECT`, normally `MENTIONED_OPERATOR` in operator space and an ordinary descriptive proposition in proposition space.

### Negated or prohibited use

Negation/prohibition scopes over the assumption action before frame activation is considered:

- `không muốn hệ thống giả định động cơ`
- `đừng giả định ý định của tôi`
- `không nên suy đoán nguyên nhân`
- `do not assume my motive`

Result: `NEGATED_OPERATOR`, `NOMINAL_OBJECT`, no governed proposition, no frame.

An independent active operator elsewhere is resolved separately; one negated occurrence must not cancel or activate another occurrence.

### Quoted/reported use

Quotation and attribution create a scope container first.

- `Anh ấy nói: “Giả sử tôi nghỉ việc.”` → active operator inside quoted scope; only quoted propositions become hypothetical/reported.
- `Theo lời cô ấy, “nếu giả định rằng...”` → reported operator scoped to reported propositions.

No frame may leak from the quote/report container into narrator propositions.

### Metalinguistic/policy language

An interpretation-policy annotation is licensed by a system/interpreter target plus an inference/interpretation predicate, not by imperative mood alone. Examples include `hệ thống`, `system`, `model`, `công cụ`, combined with `giả định`, `suy đoán`, `infer`, `assume`, `interpret`, `coi đây là`.

`Tôi không muốn hệ thống giả định động cơ` is an `INTERPRETATION_POLICY` proposition and a negated assumption action. It is not user behavioral evidence and not a reality-frame operator. Other imperatives remain ordinary propositions unless this policy relation is established.

## 4. Complement and scope model

Complement classification precedes frame construction:

- `NOMINAL_OBJECT`: noun phrase such as motive, intent, emotion, cause, `động cơ`, `ý định`, `cảm xúc`, `nguyên nhân`. Cannot license a hypothetical frame.
- `PROPOSITIONAL_COMPLEMENT`: explicit `that/rằng/là` complement containing a proposition, or a structurally equivalent subject–predicate clause. May license a local frame.
- `CLAUSAL_FRAME`: explicit discourse introduction followed by colon, sentence boundary or multi-clause continuation whose clauses are structurally attached to the introduction. May license document/multi-clause scope.
- `NONE/UNKNOWN`: cannot activate a frame; fail closed as unresolved operator evidence without changing behavioral reality.

### Local scope

`Tôi vẫn kiểm tra lại hồ sơ. Nếu giả định rằng khách đổi yêu cầu thì tôi sẽ xem lại lần nữa.`

- P1: actual.
- P2/P3 within the conditional/hypothetical clause graph: hypothetical.
- No document promotion.

Local scope ends at the syntactic clause boundary unless an explicit continuation relation extends it.

### Document scope

A document frame requires all of:

1. `ACTIVE_OPERATOR`;
2. `CLAUSAL_FRAME` or explicit frame-introduction construction;
3. operator positioned at a discourse boundary;
4. one or more governed propositions linked by scope relations;
5. no enclosing negation/prohibition or mention/policy classification;
6. no quotation boundary crossing.

Lexical occurrence anywhere in `documentText` is never sufficient.

## 5. Resolution precedence

Mandatory order:

1. token/span and clause segmentation;
2. quotation and attribution containers;
3. negation/prohibition scope;
4. metalinguistic/interpretation-policy classification;
5. complement-type classification;
6. operator status resolution;
7. local governed-scope resolution;
8. document-frame promotion using positive document-scope evidence;
9. proposition `reality_status` writes;
10. frozen family, sequence and route consumers.

Raw hypothetical regexes cannot write reality before these stages complete.

## 6. Cross-language parity

The following functional classes must normalize equivalently across accented Vietnamese, unaccented Vietnamese, mixed Vietnamese and English:

| Function | Vietnamese | Unaccented | English | Expected status |
|---|---|---|---|---|
| propositional operator | `giả định rằng tôi...` | `gia dinh rang toi...` | `assume that I...` | ACTIVE_OPERATOR |
| discourse frame | `giả sử tình huống sau...` | `gia su tinh huong sau...` | `suppose the following...` | ACTIVE_OPERATOR |
| nominal assumption action | `giả định động cơ` | `gia dinh dong co` | `assume a motive` | MENTIONED_OPERATOR / ASSUMPTION_PREDICATE |
| prohibition | `đừng giả định động cơ` | `dung gia dinh dong co` | `do not assume my motive` | NEGATED_OPERATOR |
| policy request | `đừng coi đây là giả định` | `dung coi day la gia dinh` | `do not treat this as hypothetical` | INTERPRETATION_POLICY, no frame |

Accent folding may normalize cue identity, but it cannot determine complement or scope.

## 7. Twenty-four failure architecture map

All cases contain the same failing policy clause; the behavioral prefix and optional suffix differ. No exact-case branch is required.

| Case | Phrase | Expected status | Actual status | Expected scope | Actual scope | Expected reality | Actual reality |
|---|---|---|---|---|---|---|---|
| REAL600-C18-P01-V0 | `không muốn hệ thống giả định động cơ` | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P01-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P02-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P02-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P03-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P03-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P04-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P04-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P05-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P05-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P06-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P06-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P07-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P07-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P08-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P08-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P09-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P09-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P10-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P10-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P11-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P11-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P12-V0 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |
| REAL600-C18-P12-V1 | same policy phrase | NEGATED_OPERATOR / INTERPRETATION_POLICY | ACTIVE_OPERATOR | NONE | DOCUMENT_FRAME | actual | hypothetical |

The proposed resolver prevents every row through the same sequence: prohibition scope → interpretation-policy classification → nominal complement → no governed propositions → no frame. Behavioral propositions remain actual and flow unchanged to the frozen family consumer.

## 8. Architecture-level contrast set

| Contrast | Operator function/status | Scope/reality |
|---|---|---|
| `Giả định rằng tôi nghỉ việc.` | HYPOTHETICAL_DISCOURSE / ACTIVE_OPERATOR | governed proposition hypothetical |
| `Đừng giả định động cơ của tôi.` | ASSUMPTION_PREDICATE / NEGATED_OPERATOR | no frame; narrative actual |
| `Gia dinh rang toi nghi viec.` | HYPOTHETICAL_DISCOURSE / ACTIVE_OPERATOR | local proposition hypothetical |
| `Khong muon he thong gia dinh dong co.` | INTERPRETATION_POLICY / NEGATED_OPERATOR | no frame |
| `Assume that I leave.` | HYPOTHETICAL_DISCOURSE / ACTIVE_OPERATOR | local proposition hypothetical |
| `Do not assume my motive.` | ASSUMPTION_PREDICATE / NEGATED_OPERATOR | no frame |
| `Anh ấy giả định động cơ của tôi.` | ASSUMPTION_PREDICATE / MENTIONED_OPERATOR | descriptive third-party proposition; no frame |
| `Anh ấy nói: “Giả sử tôi nghỉ việc.”` | QUOTED_DISCOURSE / QUOTED_OPERATOR containing active operator | quoted proposition only hypothetical |
| `Tôi kiểm tra hồ sơ. Nếu giả định rằng khách đổi yêu cầu, tôi sẽ xem lại.` | active local operator | first proposition actual; conditional propositions hypothetical |
| `Giả sử tình huống sau: tôi nghỉ việc. Tôi chuyển nhà.` | active discourse-frame operator | explicitly governed continuation hypothetical |

Additional generalization groups must substitute `động cơ/motive` with `ý định/intent`, `cảm xúc/emotion`, and `nguyên nhân/cause`; the status must remain nominal mention/prohibition rather than hypothetical frame.

## 9. Legacy regex authority audit

| Authority | Cue inventory | Where it runs | Scope/complement aware? | Can promote document? | Disposition |
|---|---|---|---|---|---|
| V8.3.123 `RX.hypothetical` | `suppose`, `hypothetically`, `if someone`, `gia su`, `neu mot nguoi` | phase-local family preservation | No | No direct canonical document frame | RETAIN_AS_CUE only |
| V8.3.124 `RX.hypothetical` | `suppose`, `hypothetically`, `imagine`, `gia su`, `neu mot nguoi`, `neu toi` | clause/operator-context parsing | No | Influences routed proposition reality | RETAIN_AS_CUE only |
| V8.3.129 `RX.hypothetical` | `suppose/supposing`, `imagine/imagining`, `hypothetically`, thought experiment, `what if`, `gia su`, `giả sử`, `neu thu` | `resolveReality(local, document)` | No | Yes through document test | MIGRATE_TO_SCOPED_OPERATOR; REMOVE_AS_REALITY_AUTHORITY |
| V8.3.130 | same canonical cue family as V8.3.129 | local plus whole-document reality resolver | No | Yes | MIGRATE_TO_SCOPED_OPERATOR; REMOVE_AS_REALITY_AUTHORITY |
| V8.3.131 | same plus consolidated proposition graph | local plus whole-document reality resolver | No | Yes | MIGRATE_TO_SCOPED_OPERATOR; REMOVE_AS_REALITY_AUTHORITY |
| V8.3.132 | adds `picture`, `gia dinh/giả định`, `hay/hãy hình dung`, `hình dung` | `resolveReality()` and `detectFrames()` | No | **Yes, scopes every proposition** | RETAIN lexical items as cues; REMOVE regex as frame/reality authority |
| V8.3.133 | inherits V8.3.132 state builder and frozen consumers | inherited frame resolver | No | Yes | No independent regex; parent authority must be migrated in new implementation layer |

Counterfactual, fictional and example regexes use the same local-or-document pattern and must enter the same scoped-operator migration review. They must not be deleted blindly, but none may retain direct authority to set document reality.

## 10. Invariants

The implementation design must enforce and trace:

- `OPERATOR_LEXEME_ALONE_NOT_FRAME`
- `HYPOTHETICAL_FRAME_REQUIRES_GOVERNING_PROPOSITIONAL_SCOPE`
- `NEGATED_OPERATOR_NOT_ACTIVE`
- `NEGATED_OR_PROHIBITED_OPERATOR_LEXEME_CANNOT_ACTIVATE_FRAME`
- `META_MENTION_NOT_ACTIVE_FRAME`
- `DOCUMENT_FRAME_REQUIRES_DOCUMENT_SCOPE_EVIDENCE`
- `DOCUMENT_FRAME_CANNOT_BE_CREATED_FROM_NON_GOVERNING_LEXEME`
- `LOCAL_FRAME_DOES_NOT_GLOBALIZE`
- `QUOTED_FRAME_DOES_NOT_LEAK`
- `CROSS_SURFACE_OPERATOR_PARITY`
- `OPERATOR_STATUS_IS_NOT_FAMILY`
- `NOT_INFERRED_MOTIVE_DOES_NOT_CHANGE_BEHAVIOR_REALITY`

Every reality change must trace to one active operator occurrence and its explicit governed proposition IDs.

## 11. V8.3.135 validation design

### Level 1 — text to canonical operator and reality state

- Positive operator/complement cases across four language surfaces.
- Nominal-object mention cases across motive, intent, emotion and cause.
- Negation/prohibition cases.
- Metalinguistic policy cases.
- Local versus document scope cases.
- Quoted/reported containment cases.
- Multiple operator occurrences with independent statuses.
- Span assertions: cue, complement and governed proposition IDs.

Required outputs include operator occurrence, status, function, complement type, scope type and proposition-level reality.

### Level 2 — canonical state to frozen consumers

Use direct states only:

- actual established family plus mentioned/negated operator annotation → family remains eligible; self-lived route;
- local hypothetical proposition alongside actual behavioral proposition → only local proposition suppressed;
- document hypothetical frame → governed propositions suppressed and hypothetical route;
- quoted hypothetical frame → narrator proposition unaffected;
- behaviorally insufficient actual state → no family according to existing contract.

The V8.3.132 family/route/sequence consumer must remain unchanged unless these direct-state tests expose an independent defect. Existing direct-state family contracts already pass.

### Level 3 — raw text to public output

- Replay all 24 contaminated real-case failures across accented, unaccented, mixed and English surfaces.
- Run the architecture contrast set and generalized noun substitutions.
- Confirm family order, route, sequence and no spurious clarification.
- Confirm true hypothetical inputs still redirect correctly.
- Confirm actual-plus-local-hypothetical mixtures preserve the actual behavioral result without global leakage.

Negative mutations must include: lexical cue directly sets reality; negation ignored; nominal complement treated as proposition; quote boundary ignored; local scope globalized; document scope accepted without governed IDs; accent-folded cue loses parity.

## 12. Implementation boundary

The future V8.3.135 implementation should add a scoped operator-resolution layer before canonical reality writes. It must not patch the exact string `giả định động cơ`, alter family ranking, change the 24 expected contracts, or redesign Level-2 consumers. Regex remains lexical detection only.

No source, harness, gold, pool, sealed execution, Browser E2E, Step 111 or production action was performed during this review.

## Final verdict

**ARCHITECTURE READY FOR V8.3.135 SCOPED-OPERATOR IMPLEMENTATION**
