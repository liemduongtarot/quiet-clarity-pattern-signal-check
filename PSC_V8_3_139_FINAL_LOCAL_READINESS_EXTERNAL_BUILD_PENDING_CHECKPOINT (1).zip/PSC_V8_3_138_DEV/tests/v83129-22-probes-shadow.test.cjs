const test=require('node:test');const assert=require('node:assert/strict');process.env.PSC_V83129='1';const {loadCore}=require('./v83117-helper.cjs');const core=loadCore();
const cases=[
 ['V128-A01','Consider a fictional archivist comparing two imaginary maps before sunrise.',s=>s.propositions[0].reality_status==='fictional'],
 ['V128-A03','As a thought experiment, a made-up medic might postpone an unreal appointment.',s=>s.propositions[0].reality_status==='fictional'],
 ['V128-A05','In an invented example, someone cannot choose between two imaginary doors.',s=>['example','fictional'].includes(s.propositions[0].reality_status)],
 ['V128-A06','My supervisor abandoned the draft after the client withdrew the requirement.',s=>s.propositions[0].actor.actor_type==='third-party'&&s.relations.some(r=>r.type==='AFTER')],
 ['V128-A08','Our accountant did not avoid the difficult conversation about overdue invoices.',s=>s.propositions[0].actor.actor_type==='third-party'&&s.propositions[0].polarity==='negative'],
 ['V128-A09','The editor checked one newly corrected citation during a fifteen-minute window.',s=>s.propositions[0].actor.actor_type==='third-party'&&s.propositions[0].predicate==='review'],
 ['V128-A11','I examined one revised assumption, then stopped when the experiment ended.',s=>s.propositions[0].predicate==='review'&&s.relations.some(r=>r.type==='THEN')],
 ['V128-A12','For twelve minutes I compared a fresh measurement with yesterday’s baseline.',s=>s.propositions[0].predicate==='review'&&s.propositions[0].object_semantic_class==='evidence'],
 ['V128-A14','After receiving a corrected reading, I briefly verified the instrument calibration.',s=>s.propositions.some(p=>p.predicate==='review')&&s.relations.some(r=>r.type==='AFTER')],
 ['V128-A15','I inspected the new exception only until the audit window closed.',s=>s.propositions[0].predicate==='review'&&s.propositions[0].evidence_change==='changed'],
 ['V128-A17','Nothing in the file has changed, yet I ask another person to confirm it again.',s=>s.propositions.some(p=>p.predicate==='seek-input')&&s.relations.some(r=>r.type==='CONTRAST')],
 ['V128-A18','I continue rehearsing the same explanation after every uncertainty was resolved.',s=>s.propositions[0].predicate==='preparation'],
 ['V128-A19','I reopened the settled calculation three times without any additional data.',s=>s.propositions[0].predicate==='review'&&s.propositions[0].frequency.count===3],
 ['V128-A20','Although the answer is documented, I repeatedly compare the same two totals.',s=>s.propositions.some(p=>p.predicate==='review')&&s.relations.some(r=>r.type==='CONTRAST')],
 ['V128-A21','I archived the email unread so I would not have to address the complaint.',s=>s.propositions[0].predicate==='avoid-engagement'],
 ['V128-A22','I switched tasks and deliberately left the warning unopened.',s=>s.relations.some(r=>r.type==='AND')&&s.propositions.some(p=>p.predicate==='avoid-engagement')],
 ['V128-A24','I became stuck after the alternatives were fully explained.',s=>s.propositions.some(p=>p.predicate==='unable-to-act')&&s.relations.some(r=>r.type==='AFTER')],
 ['V128-A25','Before the evidence was complete, I accepted the first explanation immediately.',s=>s.propositions.some(p=>p.predicate==='premature-close')&&s.relations.some(r=>r.type==='BEFORE')],
 ['V128-A26','I reviewed for hours, then rushed the choice when the deadline arrived.',s=>s.propositions.some(p=>p.predicate==='review')&&s.propositions.some(p=>p.predicate==='premature-close')&&s.relations.some(r=>r.type==='THEN')],
 ['V128-A27','When is the insurer likely to issue its written response?',s=>s.intent.question_intent==='prediction-request'],
 ['V128-A28','Will the committee reverse its decision next quarter?',s=>s.intent.question_intent==='prediction-request'],
 ['V128-A30','Which of these two delivery plans should we adopt?',s=>s.intent.question_intent==='decision-request'&&s.propositions[0].actor.actor_type==='collective-self']
];
for(const[id,raw,check]of cases)test(`${id} canonical representation architecture probe`,()=>{const frame=core.analyze(raw);assert.equal(frame.version,'V8.3.129-CANONICAL-SEMANTIC-STATE-SHADOW');assert.ok(check(frame.canonical_semantic_state),JSON.stringify(frame.canonical_semantic_state));});
