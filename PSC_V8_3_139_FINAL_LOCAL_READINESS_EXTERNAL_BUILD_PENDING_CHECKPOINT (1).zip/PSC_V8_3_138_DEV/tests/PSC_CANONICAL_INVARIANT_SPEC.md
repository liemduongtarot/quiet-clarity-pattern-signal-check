# PSC Canonical Invariant Specification

Status: architecture proposal only; no V8.3.129 implementation is authorized by this document.

| Invariant | Producer | Consumers | Illegal transition | Runtime assertion | Test strategy |
|---|---|---|---|---|---|
| `ONE_AUTHORITY_PER_SEMANTIC_FACT` | authority registry | all stages | a non-owner writes a governed fact | reject write with producer mismatch | ownership-table unit tests; mutation adds second writer |
| `DOWNSTREAM_DOES_NOT_REPARSE_RAW_MEANING` | canonical builder | qualification, sequence, route, serializer | consumer reads `source.raw/normalized` to infer meaning | capability-scoped state views omit raw source | static dependency test; mutation introduces raw regex |
| `ACTOR_IDENTITY_STABLE` | actor resolver | proposition, family, route | actor/ownership changes without explicit coreference transition | compare actor IDs at boundaries | open-class role and quoted-speaker representation tests |
| `REALITY_STATUS_STABLE` | frame/operator resolver | eligibility, route | non-real becomes actual without an explicit embedded actual proposition | monotonic frame assertion | fictional/example/hypothetical/counterfactual contrasts |
| `NEGATION_SCOPE_STABLE` | scoped operator resolver | eligibility, family | negated predicate becomes active or negation expands across unrelated proposition | active candidate cannot reference negated proposition | scope pairs and resurrection mutations |
| `PREDICATE_IDENTITY_STABLE` | compositional predicate normalizer | qualification, sequence | downstream replaces predicate from raw words | predicate ID is immutable | verb/object composition matrices; replacement mutation |
| `OBJECT_CLASS_STABLE` | object semantic classifier | predicate normalization, evidence, family | downstream reclassifies object from surface text | class changes require recorded transform | open-object tests and class-conflict mutations |
| `EVIDENCE_STATE_STABLE` | evidence-state reducer | review qualification, sequence | sufficient/changed/bounded facts disappear or invert | provenance-bearing values immutable after reduction | evidence contrast/property tests |
| `INTENT_STABLE` | speech-act/intent classifier | public route | generic router replaces explicit prediction/decision intent | route must cite intent ID | interrogative grammar tests; fallback mutation |
| `TEMPORAL_RELATIONS_PRESERVED` | clause/relation parser | sequence, serializer | valid relation/phase is rebuilt from family order or dropped | every sequence edge references proposition IDs | relation graph tests for THEN/BEFORE/AFTER/WHILE/BECAUSE |
| `FAMILY_DERIVES_FROM_CANONICAL_STATE` | family qualification | output | family emitted without eligible proposition and rule | response must reference family-decision ID | state-to-family truth tables; orphan-family mutation |
| `ROUTE_DERIVES_FROM_CANONICAL_STATE` | route resolver | output/evaluation | route inferred from raw text or inherited legacy enum | route cites intent/reality/actor proposition paths | route decision-table tests; raw-fallback mutation |

Assertions are fail-closed in implementation mode: an invariant violation yields `input:clarification-required` plus trace, never a silent legacy guess. Shadow mode records violations without changing public behavior.

## Enforcement boundaries

1. Surface normalization may change text form only; it cannot assign semantic facts.
2. Clause/proposition construction owns spans, IDs and graph structure.
3. Scoped operator resolution owns negation, cessation, reality and attribution attachments.
4. Entity/predicate/evidence/intent resolvers each own only their registered facts.
5. Qualification reads canonical propositions; routing reads canonical intent/reality/actor plus safety/empty/invalid envelope facts.
6. Serializer is read-only and cannot repair missing semantics.
