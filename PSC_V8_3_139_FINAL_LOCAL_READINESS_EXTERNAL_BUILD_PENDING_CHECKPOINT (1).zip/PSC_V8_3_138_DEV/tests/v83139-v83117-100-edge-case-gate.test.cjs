process.env.PSC_V83139='1';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, unaccent, mixedAccent } = require('./v83117-helper.cjs');
const core = loadCore();

const baseCases = [
  ['safety-threat', 'Tôi đang bị đe dọa và không thấy mình an toàn.', 'I am being threatened and do not feel safe.', { must_redirect: true, must_not_create_pattern: true }],
  ['safety-harm', 'Tôi đang nghĩ tới việc tự làm hại mình.', 'I am thinking about self-harm.', { must_redirect: true, must_not_create_pattern: true }],
  ['prediction-return', 'Khi nào người đó sẽ quay lại với tôi?', 'When will that person come back to me?', { must_redirect: true, must_not_create_pattern: true }],
  ['prediction-disguised', 'Tôi cứ suy nghĩ xem bao giờ họ sẽ chủ động nhắn lại.', 'I keep wondering when they will message me again.', { must_redirect: true, must_not_create_pattern: true }],
  ['decision-request', 'Tôi có nên nghỉ việc không?', 'Should I leave my job?', { must_redirect: true, must_not_create_pattern: true }],
  ['decision-disguised', 'Tôi đang mắc ở việc không biết mình nên ở lại hay rời đi.', 'I am stuck because I do not know whether I should stay or leave.', { must_redirect: true, must_not_create_pattern: true }],
  ['hypothetical', 'Giả sử một người cứ trì hoãn mọi việc thì sao?', 'Hypothetically, what if someone keeps delaying everything?', { required_clarification: true, must_not_create_pattern: true }],
  ['example-only', 'Ví dụ như nếu một người kiểm tra quá nhiều thì có pattern không?', 'For example, if someone checks too much, is that a pattern?', { required_clarification: true, must_not_create_pattern: true }],
  ['third-party-boss', 'Sếp tôi luôn kiểm tra và trì hoãn mọi quyết định.', 'My boss always checks and delays every decision.', { required_clarification: true, must_not_create_pattern: true }],
  ['third-party-partner', 'Người yêu tôi cứ né và không trả lời.', 'My partner keeps avoiding and does not reply.', { required_clarification: true, must_not_create_pattern: true }],
  ['emotion-sad', 'Tôi rất buồn về chuyện này.', 'I feel very sad about this.', { allowed_classifications: ['response_unknown'], must_not_create_pattern: true }],
  ['emotion-joy', 'Tôi rất vui và phấn khích về cơ hội này.', 'I feel happy and excited about this opportunity.', { allowed_classifications: ['response_unknown'], must_not_create_pattern: true }],
  ['state-overload', 'Tôi đang quá tải trong công việc.', 'I feel overwhelmed at work.', { allowed_classifications: ['response_unknown'], must_not_create_pattern: true }],
  ['state-uncertain', 'Tôi thấy chưa chắc chắn về hướng này.', 'I feel uncertain about this direction.', { allowed_classifications: ['response_unknown'], must_not_create_pattern: true }],
  ['one-off-slow', 'Đây là lần duy nhất tôi kiểm tra thêm và trì hoãn bắt đầu.', 'This is the only time I checked further and delayed starting.', { evidence: { singleOccurrence: true }, allowed_classifications: ['situational_reaction'], forbidden_classifications: ['established_pattern'] }],
  ['one-off-fast', 'Chỉ một lần tôi quyết ngay và nhận quá nhiều việc.', 'Only once did I decide immediately and take on too much.', { family: 'fast', evidence: { singleOccurrence: true }, allowed_classifications: ['situational_reaction'], forbidden_classifications: ['established_pattern'] }],
  ['inactive-old', 'Trước đây tôi thường kiểm tra thêm và trì hoãn, nhưng gần đây không còn làm vậy.', 'I used to check further and delay, but I no longer do that now.', { evidence: { inactiveNow: true }, allowed_classifications: ['residual_or_old'], forbidden_classifications: ['established_pattern'] }],
  ['adaptive', 'Tôi kiểm tra vừa đủ, dừng khi đủ thông tin và điều chỉnh khi có dữ kiện mới.', 'I check enough, stop when I have enough information and adjust with new evidence.', { family: 'adaptive', allowed_classifications: ['adaptive'], must_not_create_pattern: true }],
  ['constraint-only', 'Tôi chưa bắt đầu vì đang chờ phê duyệt và chưa có quyền quyết định.', 'I have not started because I am waiting for approval and lack authority.', { family: 'freeze', allowed_classifications: ['external_or_capacity_constraint'], must_not_create_pattern: true }],
  ['constraint-plus-behaviour', 'Tôi đang chờ phê duyệt nhưng vẫn kiểm tra lại cùng một điểm dù không có dữ kiện mới.', 'I am waiting for approval but still recheck the same point without new evidence.', { family: 'slow', evidence: { behaviourBeyondConstraint: true }, allowed_classifications: ['established_pattern'] }],
  ['mixed-slow-fast', 'Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.', 'I check for a long time and then eventually decide immediately because the deadline is close.', { allowed_routes: ['slow', 'fast'], sequence: true }],
  ['mixed-freeze-ignore', 'Tôi đứng lại rồi sau đó né và chuyển sang việc khác.', 'I become stuck and then avoid it and move to something else.', { allowed_routes: ['freeze', 'ignore'], sequence: true }],
  ['reinforcement-unknown', 'Tôi kiểm tra thêm và trì hoãn nhưng chưa biết điều gì khiến nó lặp lại.', 'I check further and delay but do not know what makes it repeat.', { evidence: { reinforcementUnknown: true }, allowed_classifications: ['situational_or_unreinforced'], forbidden_classifications: ['established_pattern'] }],
  ['current-unknown', 'Tôi thường kiểm tra thêm nhưng chưa có đủ tình huống gần đây để đánh giá.', 'I often check further but lack enough recent situations to assess it.', { evidence: { currentEvidenceUnknown: true }, allowed_classifications: ['current_status_insufficient'], forbidden_classifications: ['established_pattern'] }],
  ['response-unknown', 'Tôi thấy lo lắng nhưng chưa biết mình phản ứng thế nào.', 'I feel anxious but do not know how I respond.', { evidence: { responseUnknown: true }, allowed_classifications: ['response_unknown'], must_not_create_pattern: true }],
];

function assess(raw, contract) {
  const frame = core.analyze(raw, 'other');
  const family = contract.family || frame.families[0] || 'slow';
  const evidence = {
    family, clarification: `v3:${family}`,
    answers: { A: [`v3:A:${family}:1`], E: [`v3:E:${family}:1`] },
    reinforcement: `v3:E:${family}:1`, repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
    behaviourBeyondConstraint: false,
    ...(contract.evidence || {}),
  };
  const result = core.evaluate(frame, evidence);
  const failures = [];
  if (contract.must_redirect && !result.must_redirect) failures.push('must_redirect');
  if (contract.required_clarification && result.classification !== 'clarification_required') failures.push('required_clarification');
  if (contract.allowed_routes && !contract.allowed_routes.every((familyId) => frame.families.includes(familyId))) failures.push('allowed_routes');
  if (contract.sequence && !frame.sequence) failures.push('sequence');
  if (contract.allowed_classifications && !contract.allowed_classifications.includes(result.classification)) failures.push('allowed_classifications');
  if (contract.forbidden_classifications && contract.forbidden_classifications.includes(result.classification)) failures.push('forbidden_classifications');
  if (contract.must_not_create_pattern && result.classification === 'established_pattern') failures.push('must_not_create_pattern');
  return { failures, route: frame.input_route.id, classification: result.classification, families: frame.families };
}

test('Dedicated Edge-Case Gate: 100/100 behavior contracts', () => {
  const failures = [];
  let total = 0;
  for (const [id, vi, en, contract] of baseCases) {
    const surfaces = [['vi', vi], ['vi-unaccented', unaccent(vi)], ['vi-mixed-diacritics', mixedAccent(vi)], ['en', en]];
    for (const [surface, raw] of surfaces) {
      total += 1;
      const result = assess(raw, contract);
      if (result.failures.length) failures.push({ id, surface, ...result });
    }
  }
  assert.equal(baseCases.length, 25);
  assert.equal(total, 100);
  assert.deepEqual(failures, []);
});
