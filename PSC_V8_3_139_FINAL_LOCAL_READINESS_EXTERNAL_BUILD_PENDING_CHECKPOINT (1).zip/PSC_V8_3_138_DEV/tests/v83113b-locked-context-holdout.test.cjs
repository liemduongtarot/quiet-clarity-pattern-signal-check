/* Successor holdout locked after the final V8.3.113 wording freeze. */
/* Exact phrasings below were not used during implementation or regression design. */
/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm');
const source=process.argv[2]||'public/candidate.html',html=fs.readFileSync(source,'utf8');
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}},document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}},c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};
c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const rows=[
 ['work','khối lượng đầu việc đổi liên tục'],['business','dòng khách mới chưa đều'],['money','những khoản phải trả đến không cùng lúc'],['romantic','hai người ít tìm được tiếng nói chung'],['friends','nhóm bạn dần ít chia sẻ'],['family','trách nhiệm giữa người nhà chưa cân bằng'],['home','việc sửa sang chỗ ở kéo dài'],['daily','lịch sinh hoạt cứ bị xáo trộn'],['wellbeing','thể trạng thay đổi khó đoán'],['direction','lựa chọn tương lai vẫn còn mờ']
],emotions=['cô đơn','quá tải','mệt mỏi'];
const ascii=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d'),cases=[];
for(const[area,event]of rows)for(const emotion of emotions){const input=`Mỗi khi ${event}, tôi nhận ra mình ${emotion}, nhưng chưa hiểu cảm giác ấy đang đổi cách mình phản ứng ra sao.`;cases.push({area,input,emotion,variant:'accented'},{area,input:ascii(input),emotion,variant:'ascii'});}
const results=cases.map(f=>{vm.runInContext(`S.area=${JSON.stringify(f.area)};S.sit=${JSON.stringify(f.input)};S.clar='hyp:avoidance';`,c);const cc=vm.runInContext('caseContext()',c),titles=vm.runInContext(`['A','B','C','D','E','F','G','H'].map(qt)`,c),options=vm.runInContext(`questionOptions('A').map(tp)`,c),flat=ascii(titles.join(' ')),emotion=ascii(f.emotion),topic=ascii(cc.topic),domain=ascii(cc.domain),q1=ascii(options.join(' '));return{...f,context:{domain:cc.domain,topic:cc.topic,emotion:cc.emotion},titles,pass:cc.emotion===f.emotion&&titles.length===8&&titles.every(t=>!/^Khi tình huống này[,?]/.test(t))&&flat.includes(emotion)&&flat.includes(topic)&&flat.includes(domain)&&q1.includes(emotion)&&!q1.includes('cam giac kho chiu')&&options.length===10};});
const passed=results.filter(x=>x.pass).length,report={locked:true,successor:true,source,total:results.length,passed,failed:results.length-passed,results};
console.log(JSON.stringify(report,null,2));if(passed!==results.length)process.exit(1);
