# V8.3.132 Sealed Pool Selection Report

Status: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.

- Candidates generated: 100
- Candidates rejected/not selected: 40
- Final selected: 60
- Historical/adversarial/contrast/convergence items compared: 2170
- Runtime executions: 0

## Rejection distribution

```json
{
  "PRIOR_LEXICAL_NEAR_DUPLICATE": 4,
  "STRICT_PRIOR_SIMILARITY": 4,
  "DIVERSITY_SELECTION_SURPLUS": 32
}
```

## Coverage distribution

```json
{
  "public_route": {
    "input:hypothetical-or-example": 8,
    "input:third-party-only": 8,
    "input:self-lived": 33,
    "input:decision-request": 4,
    "input:prediction": 3,
    "input:clarification-required": 4
  },
  "internal_reality_status": {
    "hypothetical": 8,
    "current": 41,
    "future": 7,
    "unknown": 4
  },
  "actor_type": {
    "third_party": 19,
    "self": 37,
    "unknown": 4
  },
  "ownership": {
    "third_party": 19,
    "self": 37,
    "unknown": 4
  },
  "predicate_class": {
    "review": 28,
    "constraint": 5,
    "avoidance": 7,
    "decision": 5,
    "inability": 4,
    "decision_request": 4,
    "prediction": 3,
    "unknown": 4
  },
  "object_semantic_class": {
    "evidence": 28,
    "requirement": 5,
    "communication": 5,
    "decision_option": 13,
    "event": 3,
    "unknown": 4,
    "task": 2
  },
  "expected_family_set": {
    "NO_FAMILY": 35,
    "ignore": 5,
    "slow": 7,
    "fast": 5,
    "freeze": 4,
    "adaptive": 4
  },
  "polarity": {
    "positive": 54,
    "unknown": 4,
    "negative": 2
  },
  "negation_status": {
    "none": 54,
    "unknown": 4,
    "explicit": 2
  },
  "cessation_status": {
    "none": 55,
    "unknown": 4,
    "ceased": 1
  },
  "evidence_sufficiency": {
    "unknown": 39,
    "sufficient": 12,
    "insufficient": 9
  },
  "evidence_change": {
    "stable": 52,
    "increased": 4,
    "unknown": 4
  },
  "boundedness": {
    "bounded": 40,
    "unbounded": 16,
    "unknown": 4
  },
  "repetition": {
    "single": 48,
    "repeated": 8,
    "unknown": 4
  },
  "constraint_status": {
    "none": 48,
    "external": 5,
    "external_process": 3,
    "unknown": 4
  },
  "question_intent": {
    "none": 49,
    "decision_request": 4,
    "prediction": 3,
    "unknown": 4
  },
  "temporal_structure": {
    "single_phase": 55,
    "unknown": 4,
    "two_phase": 1
  },
  "sequence_shape": {
    "atomic": 39,
    "constraint_only": 5,
    "repetition": 7,
    "bounded_review": 4,
    "unknown": 4,
    "repetition_then_cessation": 1
  },
  "clause_count": {
    "1": 59,
    "2": 1
  },
  "clause_relations": {
    "scoped-imaginary-frame:relation-1": 1,
    "scoped-imaginary-frame:relation-2": 1,
    "scoped-imaginary-frame:relation-3": 1,
    "scoped-imaginary-frame:relation-5": 1,
    "bound-relational-agent:relation-1": 1,
    "bound-relational-agent:relation-2": 1,
    "bound-relational-agent:relation-3": 1,
    "bound-relational-agent:relation-5": 1,
    "causal-external-blockage:relation-1": 1,
    "causal-external-blockage:relation-2": 1,
    "causal-external-blockage:relation-3": 1,
    "causal-external-blockage:relation-5": 1,
    "purpose-non-engagement:relation-1": 1,
    "purpose-non-engagement:relation-2": 1,
    "purpose-non-engagement:relation-3": 1,
    "purpose-non-engagement:relation-5": 1,
    "contrast-repeated-unchanged-review:relation-1": 1,
    "contrast-repeated-unchanged-review:relation-2": 1,
    "contrast-repeated-unchanged-review:relation-3": 1,
    "contrast-repeated-unchanged-review:relation-5": 1,
    "relation-derived-prematurity:relation-1": 1,
    "relation-derived-prematurity:relation-2": 1,
    "relation-derived-prematurity:relation-3": 1,
    "relation-derived-prematurity:relation-5": 1,
    "contrastive-internal-freeze:relation-1": 1,
    "contrastive-internal-freeze:relation-2": 1,
    "contrastive-internal-freeze:relation-3": 1,
    "contrastive-internal-freeze:relation-5": 1,
    "bounded-changed-review:relation-1": 1,
    "bounded-changed-review:relation-2": 1,
    "bounded-changed-review:relation-3": 1,
    "bounded-changed-review:relation-5": 1,
    "decision-question-intent:relation-1": 1,
    "decision-question-intent:relation-2": 1,
    "decision-question-intent:relation-3": 1,
    "decision-question-intent:relation-5": 1,
    "prediction-question-intent:relation-2": 1,
    "prediction-question-intent:relation-3": 1,
    "prediction-question-intent:relation-4": 1,
    "underspecified-account:relation-1": 1,
    "underspecified-account:relation-2": 1,
    "underspecified-account:relation-3": 1,
    "underspecified-account:relation-5": 1,
    "scoped-imaginary-frame:relation-4": 1,
    "scoped-hypothetical-frame:relation-2": 1,
    "scoped-hypothetical-frame:relation-3": 1,
    "scoped-hypothetical-frame:relation-5": 1,
    "bound-relational-agent:relation-4": 1,
    "third-party-role-agent:relation-2": 1,
    "third-party-role-agent:relation-3": 1,
    "third-party-role-agent:relation-5": 1,
    "causal-external-blockage:relation-4": 1,
    "negated-avoidance-engagement:relation-2": 1,
    "negated-avoidance-engagement:relation-3": 1,
    "ceased-historical-pattern:relation-5": 1,
    "purpose-non-engagement:relation-4": 1,
    "contrast-repeated-unchanged-review:relation-4": 1,
    "repeated-input-after-sufficiency:relation-2": 1,
    "repeated-input-after-sufficiency:relation-5": 1,
    "relation-derived-prematurity:relation-4": 1
  },
  "language_surface": {
    "en": 17,
    "vi": 15,
    "vi-unaccented": 14,
    "vi-mixed": 14
  },
  "template_origin": {
    "v132-independent-scoped-imaginary-frame-1": 1,
    "v132-independent-scoped-imaginary-frame-2": 1,
    "v132-independent-scoped-imaginary-frame-3": 1,
    "v132-independent-scoped-imaginary-frame-5": 1,
    "v132-independent-bound-relational-agent-1": 1,
    "v132-independent-bound-relational-agent-2": 1,
    "v132-independent-bound-relational-agent-3": 1,
    "v132-independent-bound-relational-agent-5": 1,
    "v132-independent-causal-external-blockage-1": 1,
    "v132-independent-causal-external-blockage-2": 1,
    "v132-independent-causal-external-blockage-3": 1,
    "v132-independent-causal-external-blockage-5": 1,
    "v132-independent-purpose-non-engagement-1": 1,
    "v132-independent-purpose-non-engagement-2": 1,
    "v132-independent-purpose-non-engagement-3": 1,
    "v132-independent-purpose-non-engagement-5": 1,
    "v132-independent-contrast-repeated-unchanged-review-1": 1,
    "v132-independent-contrast-repeated-unchanged-review-2": 1,
    "v132-independent-contrast-repeated-unchanged-review-3": 1,
    "v132-independent-contrast-repeated-unchanged-review-5": 1,
    "v132-independent-relation-derived-prematurity-1": 1,
    "v132-independent-relation-derived-prematurity-2": 1,
    "v132-independent-relation-derived-prematurity-3": 1,
    "v132-independent-relation-derived-prematurity-5": 1,
    "v132-independent-contrastive-internal-freeze-1": 1,
    "v132-independent-contrastive-internal-freeze-2": 1,
    "v132-independent-contrastive-internal-freeze-3": 1,
    "v132-independent-contrastive-internal-freeze-5": 1,
    "v132-independent-bounded-changed-review-1": 1,
    "v132-independent-bounded-changed-review-2": 1,
    "v132-independent-bounded-changed-review-3": 1,
    "v132-independent-bounded-changed-review-5": 1,
    "v132-independent-decision-question-intent-1": 1,
    "v132-independent-decision-question-intent-2": 1,
    "v132-independent-decision-question-intent-3": 1,
    "v132-independent-decision-question-intent-5": 1,
    "v132-independent-prediction-question-intent-2": 1,
    "v132-independent-prediction-question-intent-3": 1,
    "v132-independent-prediction-question-intent-4": 1,
    "v132-independent-underspecified-account-1": 1,
    "v132-independent-underspecified-account-2": 1,
    "v132-independent-underspecified-account-3": 1,
    "v132-independent-underspecified-account-5": 1,
    "v132-independent-scoped-imaginary-frame-4": 1,
    "v132-independent-scoped-hypothetical-frame-2": 1,
    "v132-independent-scoped-hypothetical-frame-3": 1,
    "v132-independent-scoped-hypothetical-frame-5": 1,
    "v132-independent-bound-relational-agent-4": 1,
    "v132-independent-third-party-role-agent-2": 1,
    "v132-independent-third-party-role-agent-3": 1,
    "v132-independent-third-party-role-agent-5": 1,
    "v132-independent-causal-external-blockage-4": 1,
    "v132-independent-negated-avoidance-engagement-2": 1,
    "v132-independent-negated-avoidance-engagement-3": 1,
    "v132-independent-ceased-historical-pattern-5": 1,
    "v132-independent-purpose-non-engagement-4": 1,
    "v132-independent-contrast-repeated-unchanged-review-4": 1,
    "v132-independent-repeated-input-after-sufficiency-2": 1,
    "v132-independent-repeated-input-after-sufficiency-5": 1,
    "v132-independent-relation-derived-prematurity-4": 1
  }
}
```

All selected cases retain provenance `HUMAN_AUTHORED_SEMANTIC_BRIEF`; deliberate stress variants were not eligible. Pair-level evidence is stored in `V8_3_132_CANDIDATE_BANK_AUDIT.json`.
