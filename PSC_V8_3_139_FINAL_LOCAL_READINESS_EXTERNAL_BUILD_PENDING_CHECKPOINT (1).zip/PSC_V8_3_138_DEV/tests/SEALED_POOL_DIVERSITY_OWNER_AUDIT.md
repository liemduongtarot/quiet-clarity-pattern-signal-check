# V8.3.134 sealed-pool diversity owner audit

- Root construction families: 27
- Largest family count: 3
- Top-three family share: 15.0%
- Route breadth: 6
- Family breadth: 7
- Polarity breadth: 2
- Reality breadth: 3
- Sequence breadth: 3
- Operator breadth: negation=2, cessation=2, constraint=2
- Language breadth: 2

Verdict: **PASS**. Fingerprint uniqueness alone was not used as the verdict.
