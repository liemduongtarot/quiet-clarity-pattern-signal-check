/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm');
const source=process.argv[2]||'public/candidate.html';
const html=fs.readFileSync(source,'utf8');
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}};
const document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}};
const c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const fixtures=[
 ['work','Công việc gần đây không diễn ra như tôi mong muốn.','công việc'],
 ['business','Business của tôi đang ở một giai đoạn không thuận lợi.','business'],
 ['money','Khi số dư giảm, tôi thấy mình không làm được gì để thay đổi tình hình.','tiền bạc'],
 ['romantic','Mối quan hệ tình cảm này gần đây không tiến triển.','mối quan hệ tình cảm'],
 ['friends','Quan hệ bạn bè của tôi gần đây có chuyện không ổn.','quan hệ bạn bè'],
 ['family','Chuyện trong gia đình hiện không diễn ra như tôi muốn.','gia đình'],
 ['home','Chuyện nhà ở hiện tại không được thuận lợi.','chuyện nhà ở'],
 ['daily','Đời sống hằng ngày gần đây không được suôn sẻ.','đời sống hằng ngày'],
 ['wellbeing','Trạng thái hằng ngày của tôi gần đây không ổn.','trạng thái hằng ngày'],
 ['direction','Hướng đi hiện tại của tôi chưa rõ ràng.','hướng đi'],
 ['repeating','Cùng một tình huống cứ quay lại mà chưa thay đổi.','tình huống đang lặp lại']
];
const ascii=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D');
const cases=fixtures.flatMap(([area,input,domain])=>[{area,input,domain,variant:'accented'},{area,input:ascii(input),domain,variant:'ascii'}]);
const results=cases.map(f=>{vm.runInContext(`S.area=${JSON.stringify(f.area)};S.sit=${JSON.stringify(f.input)};S.clar='';`,c);const invalid=vm.runInContext('bad(S.sit)',c),options=invalid?[]:vm.runInContext('uiClarityOptions()',c),text=options.map(x=>x.text).join(' '),flat=ascii(text);return{...f,invalid,pass:!invalid&&options.length===5&&flat.includes(ascii(f.domain))&&!text.startsWith('Điểm khó nhất với tôi nằm ở phản ứng')&&options.some(x=>x.id==='adaptive:no-signal'||x.id==='c4'),options}});
const passed=results.filter(x=>x.pass).length;console.log(JSON.stringify({source,total:results.length,passed,failed:results.length-passed,results},null,2));if(passed!==results.length)process.exit(1);
