# V8.3.122 Browser E2E Temporary Tunnel Report

## Verdict

**BROWSER E2E PASS — INTERNAL PRIVATE AGENT PREVIEW TORN DOWN**

The first Cloudflare quick-tunnel attempt was transport-blocked and never loaded the application. The successful E2E used the Sites internal agent-preview transport, which is private, temporary, non-production and browser-reachable without creating a Sites checkpoint deployment.

## Purpose and exposure controls

- Purpose: Browser E2E only.
- Served artifact: the already-built production-style preview (`dist`), not the development/HMR server.
- Source maps: none were present in the built client artifact.
- Directory listing, repository browser, admin/debug endpoints and filesystem access were not enabled.
- The tunnel was not used for sealed validation, Batch A, Batch B, production traffic or Step 111.
- The tunnel URL is intentionally not recorded here because it was not a usable candidate endpoint and governance limits URL publication.

## Start state

- Build: PASS.
- Historical and V8.3.122 development tests: PASS.
- Local production-style preview: active on loopback only.
- A temporary `.trycloudflare.com` preview-host allowance was added solely for transport setup; it did not alter candidate semantics or runtime classification logic.

## Attempt result

The quick-tunnel helper installed its tunnel binary and reported a generic `https://api.trycloudflare.com/` address rather than a unique routable preview hostname. The cloud browser rejected that address with `ERR_BLOCKED_BY_CLIENT`. No application page loaded, so no Browser E2E assertions were executed.

## End state

- Tunnel command reported `Tunnel closed` immediately after the blocked attempt.
- Preview process was terminated.
- Process audit found no remaining `cloudflared` or `vite preview` process.
- The temporary preview-host allowance was removed from `vite.config.ts`.
- The generic API address remains reachable as a Cloudflare service endpoint; it was not the candidate tunnel and therefore cannot be used to test candidate endpoint reachability.

## Successful private E2E execution

- Frozen working-source commit: `57e4c3584a6546a945e08aae050dbe9aa8e57b8e`.
- Source SHA256: `bd762a7a229146bb8ca7d8fabb1c0eeb1ed1fc5775a7c5401562bf37a54c0c7a`.
- Config SHA256: `43e5f02f727ca043f08ebf34789f330580a7a0cb90f426c92f4a454d066988fc`.
- Candidate loader SHA256: `731abc865ef92403cce4e7228ae7274af39a401f6e43c2a5a54cee896074a976`.
- Transport identifier: Sites internal agent preview for project `pattern-signal-check-v83101-qa`; no checkpoint/deployment identifier exists because no deployment was created.
- Private preview URL: recorded as `INTERNAL SITES AGENT PREVIEW` rather than publishing the transport address.
- Creation/start: 2026-08-15T07:48Z UTC.
- End/teardown: 2026-08-15T07:48:54Z UTC.
- E2E path: landing page loaded; candidate page loaded; start acknowledgement advanced; topic selection advanced; situation entry advanced into clarification; V8.3.122 three-phase input was accepted; application console errors: none.
- Browser-extension metadata errors were excluded as browser-environment noise and were not emitted by the application.
- No semantics, parser, schema, routing, expected contract or test logic changed for E2E.

## Teardown evidence

- `sites-preview stop`: successful.
- `sites-preview status`: stopped.
- Post-teardown browser probe: `ERR_CONNECTION_REFUSED`.
- Source/config/candidate-loader hashes after teardown: unchanged from the frozen values above.

## Governance consequence

- Browser E2E: **PASS**.
- Sealed pool: may now be created and locked, but was not used during E2E.
- Batch A: **NOT RUN**.
- Batch B: **NOT RUN**.
- Candidate freeze: remains subject to sealed Batch A/Batch B first-run governance.
- Step 111: manual and not executed.
- Production lock: prohibited.
