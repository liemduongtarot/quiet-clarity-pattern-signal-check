# V8.3.126 Browser E2E — Internal Preview

- Transport: internal `sites-preview` only; no checkpoint or production deployment.
- Purpose: Browser E2E only.
- Start state: preview stopped.
- Preview endpoint: `http://terminal.local:4173/` (internal transport identifier only).
- Exposure: candidate app/build only; no repository browser, directory listing, filesystem, admin, or debug endpoint.
- Tested UI: V8.3.126 landing identity; candidate launch; exact contaminated regression input; canonical hypothetical/example rewrite response.
- Observed result: PASS.
- Application console: no application-origin error observed. Browser-extension metadata messages were outside candidate origin and are not application failures.
- End state: tab closed; `sites-preview stop` completed; status reported stopped.
- Teardown verification: local endpoint connection failed; `UNREACHABLE`.
- Candidate source/config were unchanged between final build and completed Browser E2E.

This was temporary test transport, not a deployment, promotion, production lock, or Step 111 authorization.

