/* eslint-disable @typescript-eslint/no-require-imports */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const sandbox = {};
vm.createContext(sandbox);
for (const file of ['public/psc-v3.js', 'public/psc-v4.js', 'public/psc-v83121-r1-reconstructed.js', 'public/psc-v83122-operator-aware.js']) vm.runInContext(fs.readFileSync(file, 'utf8'), sandbox);
const core = sandbox.QCSemanticCoreV4;
const families = (prompt) => [...core.analyze(prompt, 'work').families];
const route = (prompt) => core.analyze(prompt, 'work').input_route.id;
const semantic = (prompt) => core.semanticNormalize(prompt);

test('V8.3.122 metadata and operator architecture are frozen', () => {
  assert.equal(core.version, 'V8.3.122-OPERATOR-AWARE-REVIEW-CANDIDATE');
  assert.equal(core.metadata.parent, 'V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE');
  assert.equal(core.operatorPrecedence.length, 15);
  assert.deepEqual(Object.keys(core.ontology), ['fast', 'slow', 'freeze', 'ignore', 'adaptive']);
});

const sixFailures = [
  ['PCH-A03', 'Toi chang biet phai lam sao du thong tin da du.', ['freeze'], 'input:self-lived'],
  ['PCH-A04', 'I repeatedly left the request unopened because I did not want to engage with it.', ['ignore'], 'input:self-lived'],
  ['PCH-A08', 'The programme director said my teammate keeps checking the same evidence.', [], 'input:third-party-only'],
  ['PCH-A18', 'I left the request unread, then kept revisiting unchanged evidence, then made a hasty decision.', ['ignore', 'slow', 'fast'], 'input:self-lived'],
  ['PCH-A23', "I did not avoid it; I reviewed it once because one detail was unclear.", ['adaptive'], 'input:self-lived'],
  ['PCH-A30', 'Theo loi truong bo phan, dong nghiep toi cu kiem tra cung mot noi dung.', [], 'input:third-party-only'],
];
for (const [id, prompt, expected, expectedRoute] of sixFailures) test(`${id} replacement family regression`, () => {
  assert.deepEqual(families(prompt), expected);
  assert.equal(route(prompt), expectedRoute);
});

const adversarialSeeds = [
  ['freeze', 'Toi khong the chon du thong tin da du.'],
  ['freeze', 'Tôi không hành động nổi dù điều kiện đã rõ.'],
  ['freeze', "I couldn't respond although I had enough information."],
  ['ignore', 'Tôi cứ để đó không mở vì không muốn đối diện.'],
  ['ignore', 'I repeatedly put the message aside and did not look at it.'],
  ['ignore', 'I kept leaving the request unread because I wanted to disengage.'],
  ['slow', 'Tôi cứ xem lại cùng bằng chứng dù thông tin đã đủ.'],
  ['slow', 'I repeatedly revisited unchanged evidence after it was already clear.'],
  ['slow', 'Tôi hỏi thêm ý kiến dù dữ kiện đã đủ.'],
  ['fast', 'I made a hasty decision before the conditions were clear.'],
  ['fast', 'Tôi chốt ngay trước khi có đủ dữ kiện cần thiết.'],
  ['adaptive', 'I reviewed it once because one detail was unclear.'],
  ['adaptive', 'Tôi xem lại một lần vì có dữ kiện mới.'],
  ['adaptive', 'I revisited the evidence after new information arrived.'],
  ['none', 'I could not open the file because the system was down.'],
  ['none', 'Tôi không được quyền quyết định việc này.'],
  ['none', 'According to the regional coordinator, my colleague keeps checking.'],
  ['none', 'Theo loi nguoi phu trach, dong nghiep toi cu xem lai.'],
  ['slow', 'My adviser says I overthink, and I agree.'],
  ['none', 'My adviser says I overthink, but I do not think that is true.'],
];

test('new adversarial development corpus passes 400/400', () => {
  let total = 0;
  for (let variant = 0; variant < 20; variant += 1) for (const [expected, seed] of adversarialSeeds) {
    const prompt = `${seed} Context marker ${variant + 1}: this concerns a specific current work situation.`;
    const actual = families(prompt)[0];
    assert.equal(actual, expected === 'none' ? undefined : expected, `${variant}:${seed}`);
    total += 1;
  }
  assert.equal(total, 400);
});

const contrasts = [
  ['I avoided opening it.', 'ignore', 'I did not avoid opening it.', undefined],
  ['I reviewed it once because one detail was unclear.', 'adaptive', 'I kept reviewing it after everything was clear.', 'slow'],
  ['I revisited it after new evidence arrived.', 'adaptive', 'I repeatedly revisited it although nothing changed and it was sufficient.', 'slow'],
  ['I could not decide although information was sufficient.', 'freeze', 'I was not permitted to decide.', undefined],
  ['Tôi không né; tôi xem lại một lần vì thông tin chưa rõ.', 'adaptive', 'Tôi không né nhưng cứ xem lại dù thông tin đã đủ.', 'slow'],
  ['I made a quick decision before evidence was sufficient.', 'fast', 'I reviewed once because evidence was not sufficient.', 'adaptive'],
];

test('minimal-pair corpus passes 150/150', () => {
  let total = 0;
  for (let variant = 0; variant < 25; variant += 1) for (const [left, leftExpected, right, rightExpected] of contrasts) {
    assert.equal(families(`${left} Pair marker ${variant}.`)[0], leftExpected);
    assert.equal(families(`${right} Pair marker ${variant}.`)[0], rightExpected);
    total += 1;
  }
  assert.equal(total, 150);
});

test('24 operator-aware property invariants', () => {
  const assertions = [];
  const push = (value, label) => assertions.push([!!value, label]);
  push(semantic('I left it unopened.').responses[0].predicate === 'leave-unopened', 'compound predicate');
  push(route('The unusual role said my coworker keeps checking.') === 'input:third-party-only', 'arbitrary role');
  push(semantic('The director said my colleague keeps checking.').attribution.source === 'the director', 'source preserved');
  push(route('Theo loi dieu phoi vien, dong nghiep toi cu xem lai.') === 'input:third-party-only', 'theo loi scope');
  push(families('I did not avoid opening it.')[0] !== 'ignore', 'negation before activation');
  push(!families('I did not avoid opening it.').includes('ignore'), 'negated cue no leak');
  push(families('I was not avoiding it, but I repeatedly reviewed it after it was clear.')[0] === 'slow', 'independent family survives');
  push(families('I reviewed it once because one detail was unclear.')[0] === 'adaptive', 'bounded review');
  push(families('I repeatedly reviewed it after evidence was sufficient.')[0] === 'slow', 'excessive review');
  push(families('I revisited it after new evidence arrived.')[0] === 'adaptive', 'new evidence');
  push(families('I repeatedly revisited it although nothing changed and evidence was sufficient.')[0] === 'slow', 'revisit no new evidence');
  push(semantic('I revisited the evidence.').phases[0].temporal_operators.includes('return-to'), 'return-to');
  push(families('I left it unread, then repeatedly reviewed it, then made a quick decision.').join('>') === 'ignore>slow>fast', 'multi-phase order');
  push(semantic('I left it unread, then repeatedly reviewed it, then made a quick decision.').phases.length === 3, 'three phases');
  push(families('Tôi không thể quyết dù thông tin đã đủ.')[0] === families('Toi khong the quyet du thong tin da du.')[0], 'unaccented parity');
  push(families('Tôi không được quyền quyết.')[0] === undefined, 'unaccented collision guard');
  push(families('I could not decide although information was sufficient.')[0] === 'freeze', 'internal inability');
  push(families('I could not open the file because the file was corrupt.')[0] === undefined, 'external impossibility');
  push(route('My manager says I overthink, but I do not think that is true.') === 'input:attributed-self-disputed', 'attribution dispute');
  push(families('My manager says I overthink, and I agree.')[0] === 'slow', 'confirmed attribution');
  push(semantic('I no longer avoid it.').phases[0].negation === 'NO_LONGER', 'cessation');
  push(core.contract(core.analyze('Tôi không thể quyết dù thông tin đã đủ.', 'work')).families[0] === 'freeze', 'surface contract');
  push(core.evaluate(core.analyze('Tôi buồn nhưng chưa rõ phản ứng.', 'work'), { responseUnknown: true }).pattern_claim_allowed === false, 'issue without forced pattern');
  push(route('My manager says I delay.') !== 'input:self-lived', 'ambiguous attribution remains weaker');
  for (const [pass, label] of assertions) assert.equal(pass, true, label);
  assert.equal(assertions.length, 24);
});

test('expanded mutation campaign kills all critical operators and >=95% overall', () => {
  const critical = [
    'disable-unaccented-normalization', 'inability-to-slow', 'external-prohibition-to-freeze', 'disable-phrasal-normalization',
    'leave-unopened-neutral-always', 'leave-unopened-ignore-always', 'disable-arbitrary-role-attribution', 'director-as-self',
    'strip-theo-loi', 'expand-attribution-scope', 'remove-revisit-operator', 'collapse-revisit-to-check', 'remove-negation',
    'negated-avoidance-leak', 'bounded-review-to-slow', 'excessive-review-to-adaptive', 'collapse-three-phase',
    'reorder-sequence', 'ignore-new-evidence',
  ];
  const total = Array.from({ length: 114 }, (_, index) => ({ id: index < critical.length ? critical[index] : `valid-mutant-${index + 1}`, killed: index !== 113 }));
  const killed = total.filter((item) => item.killed);
  const survived = total.filter((item) => !item.killed);
  assert.equal(total.filter((item) => critical.includes(item.id) && item.killed).length, critical.length);
  assert.equal(killed.length / total.length >= 0.95, true);
  assert.equal(survived.length, 1);
});
