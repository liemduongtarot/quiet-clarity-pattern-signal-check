# V8.3.127 Browser E2E Internal Preview

Temporary internal `sites-preview` only. The first development E2E exposed UI message-taxonomy drift for `input:decision-request`; this was repaired before holdout, all development gates and build were replayed, and E2E then passed. Final tested flow displayed the locked decision-request guidance for a direct English decision question. Preview stopped; status stopped; endpoint unreachable. No deployment, production lock, or Step 111.

