# V8.3.127 Forensic Root-Cause Table

Status: **PRE-IMPLEMENTATION AUTHORITY**  
Parent: `V8.3.126 FAILED REVIEW CANDIDATE` (immutable)  
Target: review qualification authority + question-intent routing authority

No V8.3.127 source modification preceded this record. V8.3.126 sealed Batch A was not rerun, Batch B was not run, and its gold/expected contracts remain unchanged.

## V126-A20 — review qualification trace

| Field | Trace |
|---|---|
| Raw text | `I checked one amended estimate for five minutes.` |
| Normalized text | `i checked one amended estimate for five minutes.` |
| Predicate | parent emits `review-evidence` plus suppressed `gather-missing-evidence` |
| Object semantic class | estimate / reviewable quantitative evidence; not present in V8.3.125 `reviewObject` enum |
| Change-status | lexical modifier `amended` is present, but V8.3.124 binds change only when followed by its narrow evidence/information/detail/fact object set; therefore `new_evidence=false` |
| Review count | `one` = single |
| Duration | five minutes |
| Repetition | false |
| Sufficiency | unspecified |
| Boundedness | parent false; richer composition should be true from single object + finite duration + no repetition |
| Adaptive eligibility | incorrectly suppressed as `NO_ADAPTIVE_QUALIFIER` |
| Slow eligibility | generic review candidate remains active without excess/repetition proof |
| Family competition | generic parent `slow` survives because the V8.3.125 authoritative review layer does not recognize `estimate` as a reviewable object and therefore never adjudicates it |
| Final family | actual `slow`; locked expected `adaptive` |

Root cause: **object-class and modifier attachment are lexically narrow, so richer changed/bounded evidence never reaches the authoritative qualification stage; generic review candidacy is allowed to survive without excess evidence.** Duration did not itself prove slow, but the absence of authoritative qualification allowed the generic slow default to win.

Architectural obligation: construct review facts independently of the candidate family, bind change modifiers to a semantic review-object class, compute boundedness compositionally, and deterministically suppress generic slow when changed + bounded + non-repeated evidence establishes adaptive review.

## V126-A30 — question-intent trace

| Field | Trace |
|---|---|
| Raw text | `Should I accept this offer?` |
| Sentence type | direct interrogative |
| Question syntax | modal `should` + first-person subject + action predicate |
| Decision verb | `accept` |
| Choice object | `this offer` |
| Self-lived evidence presence | first-person token exists, but no completed/current behavioral proposition exists |
| Intent classification | should be `direct-decision-request`; no canonical intent object currently exists |
| Route candidate | V8.3.117 base decision regex covers only choose/leave/stay/do/continue/stop, so `accept` falls through to `input:self-lived` |
| Route precedence | V8.3.126 preserves priority routes only after the base has emitted them; its positive-self assertion then canonicalizes the fallback as self-lived |
| Final public route | actual `input:self-lived`; locked expected `input:decision-request` |

Root cause: **decision intent is represented as a narrow verb regex rather than a canonical speech-act analysis, and first-person presence becomes a self-lived default before question intent has independent authority.**

Architectural obligation: derive a canonical intent frame (`speech_act`, `question_type`, request flags, behavioral-self-report evidence), then apply precedence: safety/invalid → timing/prediction → decision request → hypothetical/example → third-party-only → behavioral self-lived → clarification/fallback. A first-person marker alone is never behavioral evidence.

## Shared architectural gap

Both failures arise because a broad surface candidate (generic review→slow; first-person→self-lived) is not subordinated to a richer semantic authority. V8.3.127 must introduce two explicit adjudication boundaries:

1. proposition-fact authority for final review-family eligibility;
2. speech-act/intent authority for final route eligibility.

Exact-phrase repair is prohibited. Required invariants include `EXPLICIT_CHANGED_EVIDENCE_CANNOT_BE_OVERRIDDEN_BY_DURATION_ALONE`, `QUESTION_INTENT_PRECEDES_GENERIC_SELF_ROUTE`, and `SURFACE_HEURISTIC_CANNOT_OVERRIDE_EXPLICIT_SEMANTIC_FACT`.

