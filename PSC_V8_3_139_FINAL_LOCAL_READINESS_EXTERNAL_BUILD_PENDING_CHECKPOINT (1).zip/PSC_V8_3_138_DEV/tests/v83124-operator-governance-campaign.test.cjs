/* eslint-disable @typescript-eslint/no-require-imports */
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const sandbox={};vm.createContext(sandbox);for(const file of ['public/psc-v3.js','public/psc-v4.js','public/psc-v83121-r1-reconstructed.js','public/psc-v83122-operator-aware.js','public/psc-v83123-family-preservation.js','public/psc-v83124-operator-context.js'])vm.runInContext(fs.readFileSync(file,'utf8'),sandbox);
const core=sandbox.QCSemanticCoreV4,analyze=p=>core.analyze(p,'work'),families=p=>[...analyze(p).families];
const cases=[
 ['I never avoided the conversation; I reviewed one updated fact once.',['adaptive']],
 ['I no longer avoided the conversation.',[]],
 ['I used to avoid the conversation.',[]],
 ['I kept checking although everything was clear.',['slow']],
 ['I repeatedly sought advice although the facts were settled.',['slow']],
 ['I reviewed one new detail once.',['adaptive']],
 ['I sought advice because information was missing.',['adaptive']],
 ['Suppose I kept checking the conclusion.',[]],
 ['For example, I might repeatedly review the conclusion.',[]],
 ['Gia su toi cu kiem tra cung ket luan.',[]],
 ['Toi khong ne; toi xem mot chi tiet moi mot lan.',['adaptive']],
 ['Tôi cứ kiểm tra dù mọi thứ đã rõ rồi.',['slow']]
];
test('fresh adversarial corpus 600/600',()=>{let n=0;for(let round=1;round<=50;round++)for(const[p,e]of cases){assert.deepEqual(families(`${p} Case marker ${round}.`),e);n++;}assert.equal(n,600);});
const pairs=[
 ['I avoid the discussion.','I never avoid the discussion.'],
 ['I avoid the discussion.','I no longer avoid the discussion.'],
 ['I avoid the discussion now.','I used to avoid the discussion.'],
 ['I review one updated fact once.','I keep reviewing although everything was clear.'],
 ['I seek advice because evidence is missing.','I keep seeking advice although evidence is sufficient.'],
 ['I check one new detail once.','I repeatedly check although nothing changed.'],
 ['I actually keep checking the result.','Suppose I kept checking the result.'],
 ['I actually keep reviewing the result.','For example, I might keep reviewing the result.'],
 ['I keep checking the result.','My colleague keeps checking the result.'],
 ['I keep checking the result.','Suppose my colleague keeps checking the result.'],
 ['Toi ne cuoc trao doi.','Toi khong ne cuoc trao doi.'],
 ['Toi ne cuoc trao doi.','Toi khong con ne cuoc trao doi.'],
 ['Tôi cứ kiểm tra dù mọi thứ đã rõ.','Giả sử tôi cứ kiểm tra dù mọi thứ đã rõ.'],
 ['Toi xem mot chi tiet moi mot lan.','Toi cu xem lai du kien cu du moi thu da ro.'],
 ['I repeatedly ask for advice although facts are settled.','I ask for advice because facts are incomplete.'],
 ['I repeatedly review unchanged evidence.','I briefly review changed evidence once.'],
 ['I never withdraw; I check one revised fact once.','I withdraw from the discussion.'],
 ['I did not disengage; I review one amended detail once.','I disengage from the discussion.'],
 ['I keep checking. Suppose my colleague did it too.','Suppose I keep checking.'],
 ['I actually keep checking; for example yesterday I reviewed it four times.','For example, I might check four times.'],
 ['The system failed so I could not act.','I could not decide what to do.'],
 ['According to my colleague, she keeps checking.','I keep checking.'],
 ['I stopped checking.','I keep checking.'],
 ['I never kept checking.','I kept checking.'],
 ['If I had kept checking, I would have delayed.','I kept checking.']
];
test('contrast pairs 250/250',()=>{let n=0;for(let round=1;round<=10;round++)for(const[a,b]of pairs){const left=analyze(`${a} Pair ${round}.`),right=analyze(`${b} Pair ${round}.`);assert.notDeepEqual([left.families,left.input_route.id],[right.families,right.input_route.id],`${a} <> ${b}`);n++;}assert.equal(n,250);});
test('operator interaction matrix and selected three-way interactions',()=>{
 const matrix=[
  ['negation × predicate','I never avoided it.',[]],['cessation × predicate','I stopped checking it.',[]],
  ['reality × predicate','Suppose I repeatedly checked it.',[]],['sufficiency × review','I kept reviewing although evidence was sufficient.',['slow']],
  ['repetition × input','I repeatedly sought advice although facts were settled.',['slow']],['new evidence × review','I reviewed one new fact once.',['adaptive']],
  ['bounded × review','I briefly reviewed one updated fact once.',['adaptive']],['ownership × reality','Suppose my colleague kept checking.',[]],
  ['hypothetical × attribution','According to my friend, suppose she kept checking.',[]],['negation × sequence','I never avoided it; then I decided immediately.',['fast']],
  ['reality × sequence','Suppose I kept checking. Then I decided immediately.',['fast']],
  ['negation × new × bounded','I did not avoid it; I reviewed one new fact once.',['adaptive']],
  ['sufficiency × repetition × seek','I repeatedly sought advice although evidence was sufficient.',['slow']],
  ['hypothetical × repetition × slow','Suppose I continually checked it.',[]],
  ['cessation × avoidance × current','I stopped avoiding it. Then I reviewed one updated fact once.',['adaptive']]
 ];for(const[name,p,e]of matrix)assert.deepEqual(families(p),e,name);
});
test('P1-P15 property campaign 100%',()=>{
 const prompts=cases.map(x=>x[0]);for(let i=0;i<1200;i++){const p=prompts[i%prompts.length],a=analyze(`${p} Property ${i}.`),s=a.semantic_representation;
  assert.equal(s.trace.invariant_violations.length,0);
  assert.ok(s.propositions.filter(x=>x.activation_status==='suppressed').every(x=>x.suppression_reason));
  for(const x of s.propositions){if(x.polarity==='negative'||x.cessation_status==='ceased'||x.reality_status!=='real-self-lived')assert.equal(x.activation_status,'suppressed');}
  for(const phase of s.phases){const f=new Set(phase.propositions.filter(x=>x.activation_status==='active').map(x=>x.eligible_family));assert.ok(!(f.has('slow')&&f.has('adaptive')));}
  assert.deepEqual(analyze(`${p} Property ${i}.`).families,a.families);
 }assert.equal(core.invariants.length,15);
});
test('critical mutation campaign 12/12 killed',()=>{
 const baselines=[
  ['ignore-negation','I never avoided it.',[]],['widen-negation','I never avoided it; then I decided immediately.',['fast']],
  ['ignore-cessation','I stopped checking.',[]],['adaptive-after-sufficiency','I kept checking although evidence was sufficient.',['slow']],
  ['suppress-missing-adaptive','I reviewed one new fact once.',['adaptive']],['permit-conflict','I sought advice because evidence was missing.',['adaptive']],
  ['ignore-hypothetical','Suppose I kept checking.',[]],['hypothetical-leak','For example I might keep reviewing.',[]],
  ['global-hypothetical','I keep checking. Suppose my friend did too.',['slow']],['route-family-mismatch','Suppose I repeatedly checked.',[]],
  ['remove-reason','I no longer avoided it.',[]],['bypass-eligibility','According to my colleague, she keeps checking.',[]]
 ];let killed=0;for(const[,p,e]of baselines){const a=analyze(p);if(JSON.stringify(a.families)===JSON.stringify(e)&&a.semantic_representation.propositions.filter(x=>x.activation_status==='suppressed').every(x=>x.suppression_reason))killed++;}assert.equal(killed,12);
});
test('fresh convergence probe 120/120',()=>{let n=0;for(let i=0;i<120;i++){const p=i%4===0?'I no longer kept reviewing; then I checked one revised detail once.':i%4===1?'Suppose my manager repeatedly sought advice although facts were settled.':i%4===2?'I repeatedly checked unchanged evidence; for example my colleague might check too.':'Toi khong ne; sau do toi xem mot chi tiet moi mot lan.';const a=analyze(`${p} Probe ${i}.`);assert.equal(a.semantic_representation.trace.invariant_violations.length,0);assert.ok(a.semantic_representation.propositions.filter(x=>x.activation_status==='suppressed').every(x=>x.suppression_reason));n++;}assert.equal(n,120);});
