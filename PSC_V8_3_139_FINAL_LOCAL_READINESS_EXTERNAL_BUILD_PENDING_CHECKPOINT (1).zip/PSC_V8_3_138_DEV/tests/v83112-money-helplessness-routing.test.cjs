/* eslint-disable @typescript-eslint/no-require-imports */
const fs = require('fs');
const vm = require('vm');

const source = process.argv[2] || 'public/candidate.html';
const html = fs.readFileSync(source, 'utf8');
let js = html.match(/<script>([\s\S]*)<\/script>/i)[1]
  .replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/, '');
const el = { innerHTML: '', style: {}, dataset: {}, classList: { add() {}, remove() {} } };
const document = {
  body: { dataset: {}, setAttribute() {}, removeAttribute() {} },
  documentElement: { style: { setProperty() {} } },
  getElementById() { return el; }, querySelectorAll() { return []; },
  createElement() { return { ...el, click() {} }; },
};
const c = { console, document, window: null, globalThis: null, navigator: {}, Blob() {}, URL: { createObjectURL() { return ''; }, revokeObjectURL() {} }, setTimeout, clearTimeout };
c.window = c; c.globalThis = c; c.scrollTo = () => {}; c.addEventListener = () => {};
vm.createContext(c); new vm.Script(js).runInContext(c);

const cases = [
  'toi thuong cam thay bat luc khi tien bac khong suon se',
  'Tôi thường cảm thấy bất lực khi tiền bạc không suôn sẻ.',
  'Mỗi khi tài chính trục trặc, tôi thấy bất lực và không biết phải làm gì.',
  'Thu nhập không ổn định làm tôi thường cảm thấy bất lực.',
  'Khi số dư giảm, tôi thấy mình không làm được gì để thay đổi tình hình.',
  'Tôi hay rơi vào cảm giác vô vọng mỗi khi chuyện tiền bạc xấu đi.',
  'Tiền bạc dạo này không thuận lợi và tôi thường không biết làm gì tiếp.',
  'Tôi cảm thấy bất lực khi các khoản chi vượt khỏi kế hoạch.',
  'Khi tài chính không như mong muốn, tôi dễ nghĩ mình không đủ khả năng.',
  'Tôi thường bất lực trước việc thu nhập và chi tiêu không cân bằng.',
  'Mỗi lần tiền bạc không suôn sẻ, tôi né xem lại các quyết định tài chính.',
  'Khi tiền không ổn, tôi kiểm tra và tính toán mãi nhưng vẫn thấy bất lực.'
];

const results = cases.map(input => {
  vm.runInContext(`S.area='money';S.sit=${JSON.stringify(input)};S.clar='';`, c);
  const invalid = vm.runInContext('bad(S.sit)', c);
  const options = invalid ? [] : vm.runInContext('uiClarityOptions()', c);
  const text = options.map(x => x.text).join(' ');
  const pass = !invalid && options.length === 5 && !text.startsWith('Điểm khó nhất với tôi nằm ở phản ứng') && options.some(x => x.id === 'adaptive:no-signal' || x.id === 'c4');
  return { input, invalid, pass, options };
});

const passed = results.filter(x => x.pass).length;
console.log(JSON.stringify({ source, total: results.length, passed, failed: results.length - passed, results }, null, 2));
if (passed !== results.length) process.exit(1);
