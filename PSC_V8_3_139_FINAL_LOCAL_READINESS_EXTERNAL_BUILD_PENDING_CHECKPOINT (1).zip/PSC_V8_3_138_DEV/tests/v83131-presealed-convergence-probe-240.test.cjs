const test=require('node:test'),assert=require('node:assert/strict');process.env.PSC_V83131='1';const core=require('./v83117-helper.cjs').loadCore();
const check=(raw,family,route='input:self-lived')=>{const a=core.analyze(raw,'other');assert.equal(a.input_route.id,route,raw);assert.deepEqual([...a.families],family?[family]:[],raw);};
test('240 fresh pre-sealed compositional probes',()=>{let n=0;for(let i=0;i<40;i++){
 check(`My neighbour inspected archive entry ${i}.`,null,'input:third-party-only');n++;
 check(`Trong tình huống minh họa không có thật, người gác cổng xem bản đồ ${i}.`,null,'input:hypothetical-or-example');n++;
 check(`I put away message ${i} to avoid reading it.`,'ignore');n++;
 check(`I rechecked the identical record ${i} many passes.`,'slow');n++;
 check(`I committed to plan ${i} before reviewing the document.`,'fast');n++;
 check(`I inspected amended data ${i} in one round.`,'adaptive');n++;
}assert.equal(n,240);});
