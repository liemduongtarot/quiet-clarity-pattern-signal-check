const fs = require('node:fs');
const vm = require('node:vm');

function loadCore() {
  const sandbox = {};
  const v139 = process.env.PSC_V83139 === '1';
  const v138 = process.env.PSC_V83138 === '1' || v139;
  const v135 = process.env.PSC_V83135 === '1' || v138;
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync('public/psc-v3.js', 'utf8'), sandbox);
  vm.runInContext(fs.readFileSync('public/psc-v4.js', 'utf8'), sandbox);
  if (process.env.PSC_RECONSTRUCTED === '1' || process.env.PSC_V83122 === '1' || process.env.PSC_V83123 === '1' || process.env.PSC_V83124 === '1' || process.env.PSC_V83125 === '1' || process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1' || process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83121-r1-reconstructed.js', 'utf8'), sandbox);
  if (process.env.PSC_V83122 === '1' || process.env.PSC_V83123 === '1' || process.env.PSC_V83124 === '1' || process.env.PSC_V83125 === '1' || process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1' || process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83122-operator-aware.js', 'utf8'), sandbox);
  if (process.env.PSC_V83123 === '1' || process.env.PSC_V83124 === '1' || process.env.PSC_V83125 === '1' || process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1' || process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83123-family-preservation.js', 'utf8'), sandbox);
  if (process.env.PSC_V83124 === '1' || process.env.PSC_V83125 === '1' || process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1' || process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83124-operator-context.js', 'utf8'), sandbox);
  if (process.env.PSC_V83125 === '1' || process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1' || process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83125-semantic-routing.js', 'utf8'), sandbox);
  if (!v135 && (process.env.PSC_V83126 === '1' || process.env.PSC_V83127 === '1')) vm.runInContext(fs.readFileSync('public/psc-v83126-public-route-canonicalization.js', 'utf8'), sandbox);
  if (process.env.PSC_V83129 === '1' || process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) {
    vm.runInContext(fs.readFileSync('public/psc-v83126-public-route-canonicalization.js', 'utf8'), sandbox);
    vm.runInContext(fs.readFileSync('public/psc-v83127-review-intent-authority.js', 'utf8'), sandbox);
    vm.runInContext(fs.readFileSync('public/psc-v83129-canonical-shadow.js', 'utf8'), sandbox);
  }
  if (process.env.PSC_V83130 === '1' || process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83130-representation-coverage.js', 'utf8'), sandbox);
  if (process.env.PSC_V83131 === '1' || process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83131-proposition-consolidation.js', 'utf8'), sandbox);
  if (process.env.PSC_V83132 === '1' || process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83132-relation-graph.js', 'utf8'), sandbox);
  if (process.env.PSC_V83133 === '1' || v135) vm.runInContext(fs.readFileSync('public/psc-v83133-canonical-role-binding.js', 'utf8'), sandbox);
  if (v135) vm.runInContext(fs.readFileSync('public/psc-v83135-scoped-operator.js', 'utf8'), sandbox);
  if (v138) vm.runInContext(fs.readFileSync('public/psc-v83138-semantic-convergence.js', 'utf8'), sandbox);
  if (v139) vm.runInContext(fs.readFileSync('public/psc-v83139-semantic-convergence.js', 'utf8'), sandbox);
  if (!v135 && process.env.PSC_V83127 === '1') vm.runInContext(fs.readFileSync('public/psc-v83127-review-intent-authority.js', 'utf8'), sandbox);
  return v139 ? sandbox.QCSemanticCoreV10 : v138 ? sandbox.QCSemanticCoreV9 : process.env.PSC_V83135 === '1' ? sandbox.QCSemanticCoreV8 : process.env.PSC_V83133 === '1' ? sandbox.QCSemanticCoreV7 : process.env.PSC_V83132 === '1' ? sandbox.QCSemanticCoreV6 : process.env.PSC_V83131 === '1' ? sandbox.QCSemanticCoreV5 : sandbox.QCSemanticCoreV4;
}

const unaccent = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
const mixedAccent = (value) => value.split(/(\s+)/).map((part, index) => index % 4 === 0 ? unaccent(part) : part).join('');

module.exports = { loadCore, unaccent, mixedAccent };
