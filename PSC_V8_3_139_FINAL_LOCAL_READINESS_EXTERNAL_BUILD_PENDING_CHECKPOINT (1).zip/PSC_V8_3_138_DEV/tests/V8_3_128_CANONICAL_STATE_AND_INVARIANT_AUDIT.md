# V8.3.128 Canonical State and Cross-Layer Invariant Audit

## Canonical-state verdict

The runtime has proposition-shaped objects, phase objects, trace fragments, route assertions and named invariants. It does **not** have one canonical proposition/state object that is produced once and consumed without reinterpretation.

Evidence from the frozen source:

- V122 creates `surface`, `attribution`, `phases`, predicates and families from `raw`.
- V123 calls both `parent.semanticNormalize(raw)` and `parent.analyze(raw)`, reparses phases, reconstructs propositions and may insert a `legacyPredicate` solely to preserve a parent-routed family.
- V124 calls the parent, then replaces `phases` and `propositions` with a new split/candidate/govern pass over `raw`.
- V125 calls the parent, reparses actor/reality/review/sequence, appends a second review proposition, filters parent families and adds new primary/sequence responses.
- V126 canonicalizes the public route from V125 route assertions plus the current proposition array.
- V127 separately reparses review qualification and question intent, filters/adds families, then invokes the V126 route canonicalizer again.

This is a stack of partial representations. State is repeatedly flattened to final families/routes and then reconstructed from raw text. The `rule_source` fields document origin but do not establish sole authority.

## Cross-layer invariants

| Invariant | Defined? | Tested? | Enforced at runtime? | Can downstream bypass? | Finding |
|---|---|---|---|---|---|
| actor does not change downstream | No single end-to-end invariant | Fragment tests for third-party routes | No | YES | Five actor/ownership producers exist; no identity lock |
| reality does not change without explicit transition | Partially (`INTERNAL_REALITY_SUBTYPE_PRESERVED`) | Narrow hypothetical corpora | No | YES | Each layer reparses reality from a different marker set |
| negated predicate cannot resurrect | Defined in V124 | Tested for known avoidance phrases | Locally only | YES | V125/V127 can independently add/filter responses from raw text |
| hypothetical proposition cannot become active self evidence | Defined in V124 | Tested for known frames | Locally only | YES | If V124 fails to recognize the frame, the invariant never activates; A01/A03 demonstrate this boundary |
| sufficient evidence survives into family qualification | Defined in several variants | Tested for locked phrases | No end-to-end identity | YES | V122/V123/V124/V125/V127 each infer sufficiency independently |
| changed evidence survives into review qualification | Named in V127 | Tested for review lexicon | Conditional | YES | Requires separate verb/object recognition; A12/A14/A15 fail before qualifier |
| boundedness survives into final family | Named in V125/V127 | Tested for count/duration phrases | Conditional | YES | Six boundedness parsers use different scopes/lexicons |
| intent survives into final route | Named in V127 | Tested for canonical word orders | Conditional | YES | Missed intent falls back to inherited route; A27/A28/A30 |
| valid sequence phases cannot disappear | Named in V123/V124 | Tested for listed connectors | No | YES | Later sequence values are recomputed; A22/A24 and A26 show disappearance |
| public route derives from canonical intent/reality | Named as route canonicalization | Taxonomy tested | No | YES | Canonicalizer consumes partial route assertion/propositions and prioritizes inherited route categories |

## Enforcement finding

Most invariants are post-recognition guards: they work only after a specific local parser has recognized the semantic fact. They are not end-to-end invariants over a stable state identity. A downstream layer can bypass them by failing to see the fact, replacing propositions/phases, or adding a response from its own raw-text parser.

## Type audit

The frozen Batch A evidence does not include intermediate snapshots at every stage. Static code-path analysis shows all 22 failures diverge at representation before a correct state is available to propagate. Therefore:

- TYPE 1: 22
- TYPE 2: 0 proven
- TYPE 3: 0 proven as first divergence

There is nonetheless strong **architectural evidence** of competing authority: 15/15 audited facts have multiple producers. That risk must not be mislabeled as the captured first cause of a case where the initial proposition was never represented correctly.
