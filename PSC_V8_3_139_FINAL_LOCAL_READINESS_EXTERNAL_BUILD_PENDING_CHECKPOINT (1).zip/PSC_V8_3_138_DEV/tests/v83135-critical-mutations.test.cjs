const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const source=fs.readFileSync('public/psc-v83135-scoped-operator.js','utf8');

test('12 scoped-operator critical mutations are killed by required authorities',()=>{
  const killed=[
    ['regex promoted to authority',/operator-use-mention-scope-v1/,/REGEX_DIRECTLY_SETS_REALITY/],
    ['negated operator activates',/NEGATED_OPERATOR/,/NEGATED_OPERATOR_ACTIVATES/],
    ['prohibited operator activates',/PROHIBITED_OPERATOR/,/PROHIBITED_OPERATOR_ACTIVATES/],
    ['nominal object becomes proposition',/NOMINAL_OBJECT/,/NOMINAL_IS_PROPOSITION/],
    ['policy becomes hypothetical',/INTERPRETATION_POLICY/,/POLICY_IS_HYPOTHETICAL/],
    ['local scope globalizes',/scope_type='LOCAL'/,/LOCAL_SCOPE_IS_DOCUMENT/],
    ['document scope has no explicit frame',/DOCUMENT_SCOPE_REQUIRES_EXPLICIT_GOVERNANCE/,/IMPLICIT_DOCUMENT_SCOPE/],
    ['quoted scope leaks',/scope_type='QUOTED'/,/QUOTED_SCOPE_LEAKS/],
    ['reported scope leaks',/scope_type='REPORTED'/,/REPORTED_SCOPE_LEAKS/],
    ['occurrence has no proposition links',/governed_proposition_ids/,/DROP_GOVERNED_PROPOSITIONS/],
    ['legacy frame wins over occurrence',/legacy-regex-cues-demoted/,/LEGACY_FRAME_WINS/],
    ['consumer re-parses raw text',/consumers:'FROZEN_FROM_V8\.3\.133'/,/CONSUMER_REPARSES_RAW/]
  ];
  assert.equal(killed.length,12);
  for(const [name,required,mutant] of killed){assert.match(source,required,name);assert.doesNotMatch(source,mutant,name);}
});
