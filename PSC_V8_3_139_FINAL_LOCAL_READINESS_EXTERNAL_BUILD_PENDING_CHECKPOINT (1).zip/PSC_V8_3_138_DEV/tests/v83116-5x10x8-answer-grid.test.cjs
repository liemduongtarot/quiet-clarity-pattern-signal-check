/* V8.3.116 deterministic answer-grid coverage.
 * This is coverage, not a claim of 400 independent real-world cases.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const sandbox = {};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync('public/psc-v3.js', 'utf8'), sandbox);
const core = sandbox.QCSemanticCoreV3;

const families = {
  slow: {
    vi: 'Khi yêu cầu chưa rõ, tôi cứ kiểm tra thêm và trì hoãn bắt đầu.',
    en: 'When the requirements are unclear, I keep checking and delay getting started.',
  },
  fast: {
    vi: 'Khi thấy phấn khích, tôi quyết ngay và nhận quá nhiều việc cùng lúc.',
    en: 'When I feel excited, I decide immediately and take on too much at once.',
  },
  freeze: {
    vi: 'Tôi biết cần xử lý nhưng bị đứng lại và không biết bắt đầu từ đâu.',
    en: 'I know it needs dealing with, but I become stuck and cannot see where to begin.',
  },
  ignore: {
    vi: 'Tôi chuyển sang việc khác, giữ mình bận và né phần đang khó chịu.',
    en: 'I move to something else, keep busy and avoid the uncomfortable part.',
  },
  adaptive: {
    vi: 'Tôi xem lại vừa đủ, dừng khi đã đủ thông tin và điều chỉnh khi có dữ kiện mới.',
    en: 'I review it sufficiently, stop when I have enough information and adjust when new evidence appears.',
  },
};

const unaccent = (x) => x.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
const mixedAccent = (x) => x.split(/(\s+)/).map((part, index) => index % 4 === 0 ? unaccent(part) : part).join('');
const surfaces = [
  ['vi', (x) => x],
  ['vi-unaccented', unaccent],
  ['vi-mixed-diacritics', mixedAccent],
  ['en', (x) => x],
];
const dimensions = [...'ABCDEFGH'];

test('5 families x 10 answer positions x 8 questions cover every answer cell on every language surface', () => {
  let cells = 0;
  let fullPaths = 0;
  const failures = [];

  for (const [family, copy] of Object.entries(families)) {
    for (const [surface, transform] of surfaces) {
      const raw = transform(surface === 'en' ? copy.en : copy.vi);
      const frame = core.analyze(raw, 'work');
      const clarification = `v3:${family}`;

      for (let answerPosition = 1; answerPosition <= 10; answerPosition += 1) {
        const answers = {};
        for (const dimension of dimensions) {
          const title = core.title(frame, dimension, clarification);
          const options = core.options(frame, dimension, clarification);
          const option = options[answerPosition - 1];
          cells += 1;
          if (!title || options.length !== 10 || !option || option.id !== `v3:${dimension}:${family}:${answerPosition}`) {
            failures.push({ family, surface, dimension, answerPosition, title, option, optionCount: options.length });
          }
          answers[dimension] = [option.id];
        }

        const result = core.evaluate(frame, {
          family,
          clarification,
          answers,
          reinforcement: answers.E[0],
          repetition: 3,
          enactment: 3,
          interruptibility: 3,
          trend: 3,
          behaviourBeyondConstraint: true,
        });
        fullPaths += 1;
        if (!result.label || result.family !== family) failures.push({ family, surface, answerPosition, result });
        if (answerPosition === 9 && result.classification !== 'adaptive') failures.push({ family, surface, answerPosition, result });
      }
    }
  }

  assert.equal(cells, 5 * 10 * 8 * surfaces.length);
  assert.equal(fullPaths, 5 * 10 * surfaces.length);
  assert.deepEqual(failures, []);
});
