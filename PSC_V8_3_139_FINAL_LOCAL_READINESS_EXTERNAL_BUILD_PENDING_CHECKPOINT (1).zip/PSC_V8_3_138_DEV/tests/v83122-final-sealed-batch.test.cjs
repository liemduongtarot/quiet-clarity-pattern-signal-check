/* eslint-disable @typescript-eslint/no-require-imports */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const batchName = process.env.PSC_SEALED_BATCH;
if (!['A', 'B'].includes(batchName)) throw new Error('PSC_SEALED_BATCH must be A or B');
const sandbox = {};
vm.createContext(sandbox);
for (const source of ['public/psc-v3.js', 'public/psc-v4.js', 'public/psc-v83121-r1-reconstructed.js', 'public/psc-v83122-operator-aware.js']) vm.runInContext(fs.readFileSync(source, 'utf8'), sandbox);
const core = sandbox.QCSemanticCoreV4;
const gold = JSON.parse(fs.readFileSync('tests/V8_3_122_FINAL_SEALED_POOL_GOLD.json', 'utf8'));

test(`V8.3.122 sealed Batch ${batchName} first-run contracts`, () => {
  const failures = [];
  for (const row of gold.batches[batchName]) {
    const frame = core.analyze(row.prompt, 'work');
    const actual = { families: [...frame.families], route: frame.input_route.id };
    if (JSON.stringify(actual.families) !== JSON.stringify(row.families) || actual.route !== row.route) failures.push({ id: row.id, expected: { families: row.families, route: row.route }, actual });
  }
  assert.equal(gold.batches[batchName].length, 30);
  assert.deepEqual(failures, []);
});
