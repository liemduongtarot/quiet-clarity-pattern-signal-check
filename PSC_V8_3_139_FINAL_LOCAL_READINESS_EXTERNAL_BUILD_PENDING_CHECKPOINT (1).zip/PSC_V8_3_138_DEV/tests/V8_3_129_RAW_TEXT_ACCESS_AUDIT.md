# V8.3.129 Raw-Text Access Audit

Authority basis: static inspection of the V8.3.128 runtime stack. This inventory precedes migration. V8.3.128 remains immutable.

| Module | Semantic facts inferred from raw | Reason for access | Canonical overlap | Disposition |
|---|---|---|---|---|
| `psc-v3.js` / `psc-v4.js` base | locale, safety/input routing, legacy families | pre-canonical runtime | broad | `SHADOW_COMPARISON_ONLY`; retain empty/safety/invalid envelope separately |
| `psc-v83121-r1-reconstructed.js` | phases, actor/ownership, attribution, predicate, evidence, negation, cessation, families, route | reconstruction authority | complete overlap | `SHADOW_COMPARISON_ONLY`, then remove from decision path |
| `psc-v83122-operator-aware.js` | clauses, attribution, operators, predicates, evidence, constraint, families, route | operator repair | complete overlap | `MIGRATE_TO_STATE`; lexical fixtures only |
| `psc-v83123-family-preservation.js` | actor, propositions, predicate/state, eligibility, sequence | prevent predicate/family loss | proposition/family overlap | `REMOVE`; replace preservation with identity invariant |
| `psc-v83124-operator-context.js` | clause split, reality, actor, candidates, suppression, route | context repair | complete overlap | `MIGRATE_TO_STATE`; rules become graph/operator tests |
| `psc-v83125-semantic-routing.js` | actor/ownership/reality, review facts, family, sequence, route | semantic routing/review repair | complete overlap | `MIGRATE_TO_STATE`; retire raw primary/sequence fallbacks |
| `psc-v83126-public-route-canonicalization.js` | no direct raw parse in mapper; aggregates partial semantic records | route enum stabilization | route overlap | `MIGRATE_TO_STATE`; retain only pure state→route mapping |
| `psc-v83127-review-intent-authority.js` | review predicate/object/evidence, intent, family, route | final review/intent repair | complete overlap | `MIGRATE_TO_STATE`; retire raw parser |
| `psc-v83129-canonical-shadow.js` surface/clause/lexical producers | normalized surface, graph, lexical candidates, canonical facts | authorized pre-canonical and registered producer access | canonical authority | `KEEP_PRE_CANONICAL` only for registered producers |
| V8.3.129 family consumer | none | canonical state transformation | none | state-only; raw source capability denied |
| V8.3.129 sequence consumer | none | relation projection | none | state-only; raw source capability denied |
| V8.3.129 route consumer | none | intent/reality/actor projection | none | state-only; raw source capability denied |

## Boundary rule

Raw access is permitted only before the canonical-state seal: normalization, clause/proposition construction, registered lexical candidate extraction, and safety/empty/invalid envelope detection. After the seal, family, route, sequence and serializer consumers receive a deep-frozen semantic projection without `source.raw` or `source.normalized`.

Static boundary tests must fail if consumer functions contain raw-input parameters, folding, regex literals, or calls to a legacy analyzer.
