const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, unaccent, mixedAccent } = require('./v83117-helper.cjs');
const core = loadCore();

const meaningful = [
  ['Tôi kiểm tra thêm và trì hoãn bắt đầu.', 'I check further and delay starting.', 'slow'],
  ['Tôi quyết ngay và nhận quá nhiều việc.', 'I decide immediately and take on too much.', 'fast'],
  ['Tôi bị đứng lại và không bắt đầu được.', 'I become stuck and cannot begin.', 'freeze'],
  ['Tôi né rồi chuyển sang việc khác.', 'I avoid it and move to another task.', 'ignore'],
  ['Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay.', 'I check for a long time and then eventually decide immediately.', 'slow'],
];

test('hard invariant: no pattern classification never erases a meaningful issue analysis', () => {
  let total = 0;
  for (const [vi, en, family] of meaningful) for (const raw of [vi, unaccent(vi), mixedAccent(vi), en]) {
    for (const evidence of [
      { reinforcementUnknown: true },
      { currentEvidenceUnknown: true },
      { singleOccurrence: true },
    ]) {
      const frame = core.analyze(raw, 'work');
      const result = core.evaluate(frame, {
        family, clarification: `v3:${family}`,
        answers: { A: [`v3:A:${family}:1`], E: [`v3:E:${family}:1`] },
        reinforcement: `v3:E:${family}:1`, repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
        ...evidence,
      });
      assert.notEqual(result.classification, 'established_pattern');
      assert.equal(result.pattern_claim_allowed, false);
      assert.equal(result.analysis_continues, true);
      assert.ok(result.issue_summary.length > 20);
      assert.ok(result.consequence.length > 20);
      assert.notEqual(result.consequence_basis, 'pattern_mechanism');
      assert.ok(result.response_structure.ordered_families.length >= 1);
      total += 1;
    }
  }
  assert.equal(total, 60);
});

test('temporal combinations preserve ordered families and response IDs', () => {
  const frame = core.analyze('Tôi đứng lại rồi suy nghĩ đi suy nghĩ lại, sau đó quyết ngay.', 'work');
  const result = core.evaluate(frame, { family: frame.families[0], reinforcementUnknown: true });
  assert.equal(result.response_structure.type, 'temporal_sequence');
  assert.ok(result.response_structure.ordered_families.length >= 2);
  assert.ok(result.response_structure.ordered_response_ids.length >= 2);
  assert.equal(result.pattern_claim_allowed, false);
  assert.equal(result.analysis_level, 'meaningful_issue_without_pattern');
});

test('emotion/state ambiguity receives situation analysis without invented response family', () => {
  for (const raw of ['Tôi rất buồn và mệt.', 'I feel sad and exhausted.']) {
    const frame = core.analyze(raw, 'wellbeing');
    const result = core.evaluate(frame, {});
    assert.equal(result.classification, 'response_unknown');
    assert.equal(result.response_structure.type, 'unresolved_ambiguity');
    assert.equal(result.response_structure.ordered_families.length, 0);
    assert.equal(result.consequence_basis, 'situation_only');
    assert.equal(result.pattern_claim_allowed, false);
    assert.ok(result.issue_summary.length > 20);
  }
});
