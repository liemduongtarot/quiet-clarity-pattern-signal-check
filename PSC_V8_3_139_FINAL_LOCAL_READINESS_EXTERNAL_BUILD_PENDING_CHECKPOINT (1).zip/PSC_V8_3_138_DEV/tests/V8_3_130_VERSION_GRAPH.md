# V8.3.130 Version Graph

V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE
→ V8.3.122
→ V8.3.123 FAILED RC
→ V8.3.124 FAILED RC
→ V8.3.125 FAILED RC
→ V8.3.126 FAILED RC
→ V8.3.127 READY FOR MANUAL STEP 111 REVIEW
→ V8.3.128 FAILED RC
→ V8.3.129 FAILED RC
→ V8.3.130 FAILED REVIEW CANDIDATE

The original V8.3.121 source remains unavailable. The reconstructed baseline is not byte-identical original-source recovery; replacement regressions remain labeled as replacements.
