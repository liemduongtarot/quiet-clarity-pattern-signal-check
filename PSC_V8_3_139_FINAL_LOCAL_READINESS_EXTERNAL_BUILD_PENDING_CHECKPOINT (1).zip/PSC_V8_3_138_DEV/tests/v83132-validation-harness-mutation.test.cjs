const test = require('node:test');
const assert = require('node:assert/strict');
const h = require('../scripts/v83132-validation-harness.cjs');

const baseSemantic = {
  public_route: 'review', internal_reality_status: 'current', actor_type: 'self', ownership: 'self',
  predicate_class: 'evidence_review', expected_family_set: ['slow'], polarity: 'positive',
  negation_status: 'none', cessation_status: 'none', evidence_sufficiency: 'insufficient', evidence_change: 'stable',
  boundedness: 'bounded', repetition: 'single', constraint_status: 'none', temporal_structure: 'single_phase',
  sequence_shape: 'atomic', question_type: 'what_to_do', attribution_status: 'none', clause_count: 1,
  clause_relation: 'single', language_surface: 'en'
};
const c = (case_id, input, semantic = baseSemantic, extra = {}) => ({
  case_id, input, expected: { public_route: semantic.public_route, expected_family_set: semantic.expected_family_set },
  semantic: { ...semantic }, ...extra
});

test('M01 killed: raw duplicate cannot be admitted', () => {
  assert.equal(h.auditPool([c('A', 'same'), c('B', 'same', { ...baseSemantic, polarity: 'negative' })]).pass, false);
});
test('M02 killed: punctuation normalization bypass cannot be admitted', () => {
  assert(h.auditPool([c('A', 'Same!'), c('B', 'same', { ...baseSemantic, polarity: 'negative' })]).flagged_pairs.some(x => x.kind === 'NORMALIZED_DUPLICATE'));
});
test('M03 killed: identifier substitution bypass cannot be admitted', () => {
  assert(h.auditPool([c('A', 'Mr Stone reviews it.'), c('B', 'Mr Reed reviews it.', { ...baseSemantic, polarity: 'negative' })]).flagged_pairs.some(x => x.kind === 'IDENTIFIER_STRIPPED_DUPLICATE'));
});
test('M04 killed: semantic fingerprint collision cannot be admitted', () => {
  assert(h.auditPool([c('A', 'Alpha wording.'), c('B', 'Completely separate wording.')]).flagged_pairs.some(x => x.kind === 'FINGERPRINT_DUPLICATE'));
});
test('M05 killed: threshold inflation is rejected', () => {
  assert.throws(() => h.auditPool([], [], { nearThreshold: 0.95 }));
});
test('M06 killed: unreviewed near pair is rejected', () => {
  assert.equal(h.validatePairReview({ flagged_pairs: [{ kind: 'LEXICAL_NEAR_DUPLICATE', decision: 'UNREVIEWED', rationale: '' }] }).pass, false);
});
test('M07 killed: rationale-free waiver is rejected', () => {
  assert.equal(h.validatePairReview({ flagged_pairs: [{ kind: 'TEMPLATE_ORIGIN_COLLISION', decision: 'ACCEPT_DISTINCT', rationale: '  ' }] }).pass, false);
});
test('M08 killed: missing semantic field is rejected', () => {
  const item = c('A', 'text'); delete item.semantic.question_type;
  assert.throws(() => h.materialize(item));
});
test('M09 killed: prior-corpus collision cannot be hidden', () => {
  assert.equal(h.auditPool([c('A', 'same')], [c('OLD', 'same')]).pass, false);
});
test('M10 killed: premature owner approval is rejected', () => {
  const p = { pass: true };
  assert.equal(h.preRunOwnerAudit({ harness_tests: p, harness_mutations: p, duplicate_audit: p, contamination_audit: p,
    pair_review: p, diversity_audit: p, pool: Array(60), gold: Array(60), execution_count: 1,
    locked_before_execution: true, hashes: { source: 'a'.repeat(64) } }).pass, false);
});


