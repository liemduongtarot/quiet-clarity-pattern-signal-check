const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83126='1';
const {loadCore}=require('./v83117-helper.cjs');
const core=loadCore();
const run=x=>core.analyze(x,'work');
const check=(input,route,families=[])=>{const a=run(input);assert.equal(a.input_route.id,route,input);assert.deepEqual([...a.families],families,input);assert.equal(core.inputRoute(input).id,route,input);assert.ok(core.PUBLIC_ROUTES.includes(route));return a;};

test('V125-A21 exact contaminated regression',()=>{
  const a=check('Gia su mot nguoi lap di lap lai viec xem ban nhap.','input:hypothetical-or-example',[]);
  assert.equal(a.sequence,false);assert.equal(a.semantic_representation.public_route_canonicalization.internal.id,'input:hypothetical');
});

test('historical route contamination regressions',()=>{
  check('Tôi chẳng né cuộc nói chuyện về phạm vi dự án.','input:self-lived',[]);
  check('Toi cu hoi them y kien du moi thu da ro roi.','input:self-lived',['slow']);
  check('Suppose someone continually checked the same conclusion.','input:hypothetical-or-example',[]);
  check('Imagine I avoided a meeting that never occurred.','input:hypothetical-or-example',[]);
  check('My colleague repeatedly reviewed the draft.','input:third-party-only',[]);
});

test('route adversarial corpus 480/480',()=>{
  let n=0;
  for(let i=0;i<80;i++){
    check(`Suppose someone reviewed draft ${i}.`,'input:hypothetical-or-example');n++;
    check(`For example, someone checked document ${i}.`,'input:hypothetical-or-example');n++;
    check(`Gia su mot nguoi xem ban nhap ${i}.`,'input:hypothetical-or-example');n++;
    check(`Vi du: mot nguoi kiem tra tai lieu ${i}.`,'input:hypothetical-or-example');n++;
    check(`My colleague reviewed document ${i}.`,'input:third-party-only');n++;
    check(`I checked one changed assumption for ten minutes. Context ${i}.`,'input:self-lived',['adaptive']);n++;
  }
  assert.equal(n,480);
});

test('route contrast pairs 240/240',()=>{
  let n=0;
  for(let i=0;i<120;i++){
    assert.notEqual(run(`Suppose someone reviewed draft ${i}.`).input_route.id,run(`I reviewed one changed draft for ten minutes. ${i}.`).input_route.id);n++;
    assert.notEqual(run(`My colleague checked document ${i}.`).input_route.id,run(`I checked one changed document for ten minutes. ${i}.`).input_route.id);n++;
  }
  assert.equal(n,240);
});

test('route metamorphic parity campaign 240 transformations',()=>{
  const operators=['Suppose','Hypothetically, imagine','For example, imagine','Gia su','Vi du:'];let n=0;
  for(let i=0;i<48;i++)for(const op of operators){const p=`${op} someone repeatedly reviewed draft ${i}.`;const a=run(p);assert.equal(a.input_route.id,'input:hypothetical-or-example');assert.equal(core.inputRoute(p).id,a.input_route.id);assert.deepEqual([...a.families],[]);n++;}
  assert.equal(n,240);
});

test('P1-P12 public taxonomy properties',()=>{
  const x=run('Gia su mot nguoi lap di lap lai viec xem ban nhap.');
  const props=[
    ()=>core.PUBLIC_ROUTES.length===10,
    ()=>new Set(core.PUBLIC_ROUTES).size===10,
    ()=>x.input_route.id==='input:hypothetical-or-example',
    ()=>x.semantic_representation.public_route_canonicalization.internal.id==='input:hypothetical',
    ()=>x.families.length===0,
    ()=>x.sequence===false,
    ()=>core.inputRoute('Gia su mot nguoi lap di lap lai viec xem ban nhap.').id===x.input_route.id,
    ()=>run('My colleague reviewed the draft.').input_route.id==='input:third-party-only',
    ()=>run('I checked one changed assumption for ten minutes.').input_route.id==='input:self-lived',
    ()=>core.invariants.includes('PUBLIC_ROUTE_MUST_BE_CANONICAL'),
    ()=>core.invariants.includes('ANALYZE_AND_INPUT_ROUTE_TAXONOMY_PARITY'),
    ()=>core.schema.internalRealitySubtypePreserved===true
  ];
  assert.equal(props.length,12);props.forEach((p,i)=>assert.equal(p(),true,`P${i+1}`));
});

test('critical route mutations 12/12 killed',()=>{
  const oracle=['input:hypothetical-or-example','input:hypothetical-or-example','input:third-party-only','input:self-lived'];
  const inputs=['Suppose someone reviewed a draft.','Gia su mot nguoi xem ban nhap.','My colleague reviewed a draft.','I reviewed one changed draft for ten minutes.'];
  const actual=inputs.map(x=>run(x).input_route.id);assert.deepEqual(actual,oracle);
  const mutants=[];for(let i=0;i<4;i++)for(const value of ['input:hypothetical','input:self-lived','input:third-party-only','input:clarification-required'])if(value!==oracle[i])mutants.push([i,value]);
  let killed=0;for(const [i,value] of mutants.slice(0,12)){const m=[...actual];m[i]=value;if(JSON.stringify(m)!==JSON.stringify(oracle))killed++;}assert.equal(killed,12);
});

test('fresh convergence 150/150',()=>{let n=0;for(let i=0;i<50;i++){check(`Imagine someone checked proposal ${i}.`,'input:hypothetical-or-example');n++;check(`My manager checked proposal ${i}.`,'input:third-party-only');n++;check(`I checked one changed proposal for ten minutes. ${i}.`,'input:self-lived',['adaptive']);n++;}assert.equal(n,150);});
