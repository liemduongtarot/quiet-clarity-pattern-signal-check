const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

const sandbox={console};sandbox.globalThis=sandbox;vm.createContext(sandbox);
for(const file of ['public/psc-v3.js','public/psc-v4.js','public/psc-v83121-r1-reconstructed.js','public/psc-v83122-operator-aware.js','public/psc-v83123-family-preservation.js','public/psc-v83124-operator-context.js','public/psc-v83125-semantic-routing.js'])vm.runInContext(fs.readFileSync(file,'utf8'),sandbox,{filename:file});
const core=sandbox.QCSemanticCoreV4;
const gold=JSON.parse(fs.readFileSync('tests/V8_3_125_FINAL_SEALED_POOL_GOLD.json','utf8'));

function execute(c){const a=core.analyze(c.prompt,'work');return{id:c.id,expected:{families:c.families,route:c.route,sequence:!!c.sequence},actual:{families:[...a.families],route:a.input_route.id,sequence:!!a.sequence},pass:JSON.stringify([...a.families])===JSON.stringify(c.families)&&a.input_route.id===c.route&&(!c.sequence||a.sequence===true)};}

test('V8.3.125 Batch A first-run contracts',()=>{
  if(process.env.V83125_SEALED_BATCH!=='A')return;
  const rows=gold.cases.filter(x=>x.id.startsWith('V125-A')).map(execute);
  console.log('V83125_BATCH_RESULT='+JSON.stringify(rows));
  assert.equal(rows.length,30);
  assert.deepEqual(rows.filter(x=>!x.pass),[]);
});

test('V8.3.125 Batch B first-run contracts',()=>{
  if(process.env.V83125_SEALED_BATCH!=='B')return;
  const rows=gold.cases.filter(x=>x.id.startsWith('V125-B')).map(execute);
  console.log('V83125_BATCH_B_RESULT='+JSON.stringify(rows));
  assert.equal(rows.length,30);
  assert.deepEqual(rows.filter(x=>!x.pass),[]);
});
