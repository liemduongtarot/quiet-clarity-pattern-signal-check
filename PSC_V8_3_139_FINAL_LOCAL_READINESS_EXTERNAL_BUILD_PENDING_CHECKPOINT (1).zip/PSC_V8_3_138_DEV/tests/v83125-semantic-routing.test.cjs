const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83125='1';
const {loadCore}=require('./v83117-helper.cjs');
const core=loadCore();

function expectCase(input,families,route='input:self-lived'){
  const actual=core.analyze(input,'work');
  assert.deepEqual([...actual.families],families,input);
  assert.equal(actual.input_route.id,route,input);
  return actual;
}

test('exact contaminated V8.3.124 failures replay as regression',()=>{
  expectCase('Tôi chẳng né cuộc nói chuyện về phạm vi dự án.',[]);
  expectCase('Toi lap di lap lai viec xem ban nhap du moi thu da ro.',['slow']);
  expectCase('I checked one changed assumption for ten minutes.',['adaptive']);
});

test('negated self-lived avoidance preserves route without family leakage',()=>{
  for(const input of [
    'Tôi không né cuộc trao đổi về dự án.',
    'Toi chang tranh cuoc trao doi ve du an.',
    'I did not avoid the project conversation.',
    'I never sidestepped the discussion.'
  ]) expectCase(input,[]);
});

test('nominalized repeated review after sufficient evidence is slow across surfaces',()=>{
  for(const input of [
    'Tôi lặp đi lặp lại việc xem bản nháp dù mọi thứ đã rõ.',
    'Toi lap di lap lai viec kiem tra tai lieu du thong tin.',
    'I repeatedly reviewed the draft after everything was clear.',
    'I kept checking the proposal although the facts were settled.'
  ]) expectCase(input,['slow']);
});

test('bounded review of changed evidence is adaptive across surfaces',()=>{
  for(const input of [
    'Tôi xem một giả định đã thay đổi trong mười phút.',
    'Toi kiem tra mot chi tiet cap nhat trong 10 phut.',
    'I reviewed one updated fact for five minutes.',
    'I checked a single revised assumption briefly.'
  ]) expectCase(input,['adaptive']);
});

test('qualification trace exposes rule rationale',()=>{
  const slow=expectCase('I repeatedly reviewed the draft after enough information.',['slow']);
  assert.equal(slow.semantic_representation.review_qualification.qualification.reason,'REPEATED_REVIEW_AFTER_SUFFICIENT_EVIDENCE');
  const adaptive=expectCase('I checked one changed assumption for ten minutes.',['adaptive']);
  assert.equal(adaptive.semantic_representation.review_qualification.qualification.reason,'BOUNDED_PROPORTIONAL_REVIEW_OF_CHANGED_OR_MISSING_EVIDENCE');
});
