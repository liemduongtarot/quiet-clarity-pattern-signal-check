# PSC Legacy Parser Retirement Plan

Architecture review only. V8.3.128 remains immutable.

## Current stack truth

Seven semantic wrapper layers (V121–V127) are active. All call or inherit prior analysis; six directly reparse raw text for semantic meaning, while V126 recomputes public route from overlapping partial states. The result has at least 15 duplicated fact-production paths.

| Layer | Original problem | Facts currently inferred | Overlap | Raw access classification | Disposition |
|---|---|---|---|---|---|
| V121 reconstructed | recovery of ownership, attribution, negation, cessation, evidence and phases | actor, ownership, predicates, evidence, families, sequence, route | all later semantic layers | **MIGRATE TO CANONICAL STATE** | extract useful lexical fixtures; retire parser and router |
| V122 operator-aware | operator precedence, attribution and predicate ontology | clauses, attribution, negation, cessation, predicates, evidence, constraints, families, route | V121, V123–V125 | **MIGRATE TO CANONICAL STATE** | migrate scoped operators; retire raw family/route inference |
| V123 family-preservation | stop valid family/predicate loss | actor, propositions, predicates, state, family activation, sequence | V122, V124–V125, V127 | **REMOVE** as decision authority | replace preservation fallback with proposition identity invariant |
| V124 operator-context | contextual suppression and reality | clause split, reality, actor, candidate governance, sequence, route | V121–V125 | **MIGRATE TO CANONICAL STATE** | migrate tests/rules to operator graph; retire wrapper |
| V125 semantic-routing | route assertions and compositional review qualification | actor/ownership/reality, review facts, evidence, family, sequence, route | V121–V127 | **MIGRATE TO CANONICAL STATE** | preserve qualification decision table; remove raw `primaryFamily/sequenceFamilies` |
| V126 route canonicalization | stable public route taxonomy | route from assertion/proposition aggregates | base routes, V124–V125, V127 | **RETAIN CANONICAL-STATE ACCESS** | keep enum mapping logic rewritten as pure state→route resolver; no raw access |
| V127 review/intent authority | deterministic review and question routing | review predicate/object/evidence; intent; family; route | V125 review, base input route, V126 | **MIGRATE TO CANONICAL STATE** | preserve qualification/intent contracts; retire raw parser |

## Specific fallback removals

- Remove V123 `v83122-routed-family-preservation`; a family without a canonical proposition becomes illegal.
- Remove V125 `primaryFamily(raw)` and `sequenceFamilies(raw)`; family and sequence derive from proposition/relation IDs.
- Remove V127 replacement of inherited slow/adaptive responses after raw `reviewFacts`; qualification reads canonical review propositions.
- Remove generic self-lived fallback when actor/reality/intent is unknown; return clarification with trace.
- Remove every downstream use of raw/folded text in family, route, sequence and serializer stages.

## Contraction target

- Current semantic authority layers: **7 wrappers**, with **15/15 audited facts duplicated**.
- Proposed semantic decision architecture: **1 canonical construction pipeline** with registered single-owner stages, followed by **3 pure consumers** (family qualification, sequence projection, public-route resolution).
- Duplicate fact producers targeted for removal: **all 15 audited duplicate authorities**.
- Raw-text semantic reparsers targeted for removal from downstream: **V121, V122, V123, V124, V125 and V127 wrapper reparsers**; V126 becomes a state-only mapper.
- Compatibility logic is callable only in shadow comparison, never as fallback decision authority.

## Retirement gates

No layer retires until its fact set has: schema coverage; Level-1 representation tests; Level-2 invariants; mutation kill evidence; shadow differences classified; and owner approval. Retirement changes must be made only in a separately authorized V8.3.129 working copy. V8.3.128 and its sealed evidence remain untouched.
