# V8.3.125 Forensic Root-Cause Analysis

Status: **ROOT CAUSE FROZEN BEFORE V8.3.125 SOURCE CHANGE**

Parent: `V8.3.124 FAILED REVIEW CANDIDATE` restored byte-for-byte from the externally retained full archive. V8.3.124 Batch A remains first-run-only, is now contaminated regression evidence, is not rerun, and Batch B remains not run.

## Root-cause table

| Case | Exact surviving input | Historical expected | V8.3.124 actual | Loss point | Failure class | Architectural obligation |
|---|---|---|---|---|---|---|
| V124-A05 | `Tôi chẳng né cuộc nói chuyện về phạm vi dự án.` | no family; `input:self-lived` | no family; `input:hypothetical-or-example` | `chẳng` correctly negates `né`, but the route layer infers non-real input from the presence of suppressed propositions instead of preserving the positive self-lived reality assertion. | Route/family conflation after negation | Route must derive from actor + reality assertions independently of whether a behavioral family survives polarity suppression. A negated self-lived predicate remains self-lived input. |
| V124-A18 | `Toi lap di lap lai viec xem ban nhap du moi thu da ro.` | `slow`; `input:self-lived` | no family; `input:self-lived` | Review recognition is verb-centric and does not compose the nominalized construction `việc xem bản nháp`; the object ontology also lacks `bản nháp` as a reviewable artefact. Repetition and sufficiency therefore have no predicate to qualify. | Compositional predicate omission | Build a review proposition from action head + reviewable object across verbal and nominalized syntax; attach repetition and sufficiency before slow/adaptive qualification. |
| V124-A24 | `I checked one changed assumption for ten minutes.` | `adaptive`; `input:self-lived` | `slow`; `input:self-lived` | The review candidate sees `checked`; `changed` is recognized only when followed by a narrow evidence noun, while `assumption` is absent from the evidence-object ontology. `one` and duration are not composed into a bounded proportional review qualifier. | Modifier/object ontology gap and wrong qualification precedence | Represent changed evidence object, cardinality and bounded duration compositionally. One bounded review of changed evidence must qualify adaptive and suppress inherited slow for that proposition. |

## Shared architectural gap

The three failures share **NON-COMPOSITIONAL SEMANTIC ROUTING AND REVIEW QUALIFICATION**.

V8.3.124 detects route, predicate and modifiers through partially independent surface regexes. It does not first construct a positive semantic route assertion and an operator-complete predicate record. Therefore a negated predicate can distort route reality, nominalized review can disappear entirely, and valid bounded/new-evidence modifiers can fail to attach to a recognized review proposition.

## V8.3.125 repair contract

V8.3.125 must repair at semantic/operator architecture level:

1. Create an explicit route assertion containing actor, ownership, reality and proposition polarity; family eligibility must not determine route reality.
2. Normalize verbal and nominalized review predicates using a shared review-head and review-object ontology.
3. Attach repetition, evidence sufficiency, changed/new evidence, cardinality, bounded duration, necessity and completion to the proposition before family qualification.
4. Apply deterministic precedence: repeated review after sufficient evidence is `slow`; a single bounded proportional review of changed/missing evidence is `adaptive`; an unqualified review does not gain adaptive status.
5. Preserve suppression reasons and prevent parent-family leakage when V8.3.125 has authoritative proposition coverage.
6. Repair families, not exact strings, across accented Vietnamese, unaccented Vietnamese, mixed Vietnamese and English.

## Evidence governance

V124-A05, V124-A18 and V124-A24 are exact contaminated regressions because their exact input and expected contracts survive in `V8_3_124_FINAL_SEALED_POOL_GOLD.json`. They may be replayed as regression but must never again be described as pristine or first-run holdout evidence. No V8.3.124 expected contract is changed.

Step 111 remains prohibited. Production lock remains prohibited.
