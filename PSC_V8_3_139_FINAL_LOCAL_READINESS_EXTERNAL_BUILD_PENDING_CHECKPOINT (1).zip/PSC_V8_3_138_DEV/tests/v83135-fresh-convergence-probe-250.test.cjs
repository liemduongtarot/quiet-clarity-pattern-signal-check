const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83135='1';
const core=require('./v83117-helper.cjs').loadCore();

const behaviors=[
  ['I keep checking the unchanged record repeatedly','slow'],
  ['I leave the message unopened on purpose','ignore'],
  ['I choose before reviewing the relevant details','fast'],
  ['I remain unable to choose despite enough information','freeze'],
  ['Tôi kiểm tra lại hồ sơ không đổi nhiều lần','slow'],
  ['Tôi cố ý để thư chưa mở','ignore'],
  ['Tôi chọn trước khi xem dữ kiện liên quan','fast'],
  ['Tôi vẫn không thể chọn dù thông tin đã đủ','freeze']
];
const mentions=[
  'Do not assume my motive.','The system must not imagine my intent.','Avoid inferring an unseen cause.',
  'Tôi không muốn hệ thống giả định động cơ.','Đừng tưởng tượng ý định của tôi.','Không được suy đoán nguyên nhân.'
];
const prefixes=['','Currently, ','In this account, ','Theo mô tả hiện tại, ','Lúc này, '];

test('250 fresh composed probes preserve behavior under non-governing meta-language',()=>{
  let count=0;
  outer: for(let i=0;i<behaviors.length;i++)for(let j=0;j<mentions.length;j++)for(let k=0;k<prefixes.length;k++)for(const join of ['. ','; ']){
    const [behavior,family]=behaviors[i],input=`${prefixes[k]}${behavior}${join}${mentions[j]}`;
    const result=core.analyze(input);count++;
    assert.ok(result.families.includes(family),`${count}: ${input} => ${JSON.stringify(result.families)}`);
    assert.notEqual(result.input_route.id,'input:hypothetical-or-example',`${count}: ${input}`);
    assert.ok(result.operator_occurrences.every(op=>op.governed_proposition_ids.length===0),`${count}: ${input}`);
    if(count===250)break outer;
  }
  assert.equal(count,250);
});
