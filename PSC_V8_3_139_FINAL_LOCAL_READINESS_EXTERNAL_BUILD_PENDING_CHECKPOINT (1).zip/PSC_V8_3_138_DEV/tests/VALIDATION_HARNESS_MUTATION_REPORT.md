# V8.3.128 Validation Harness Mutation Report

Status: **PASS** — 10/10 bypass mutations killed.

```text
✔ M01 killed: raw duplicate cannot be admitted (3.068175ms)
✔ M02 killed: punctuation normalization bypass cannot be admitted (0.379965ms)
✔ M03 killed: identifier substitution bypass cannot be admitted (0.341378ms)
✔ M04 killed: semantic fingerprint collision cannot be admitted (0.293997ms)
✔ M05 killed: threshold inflation is rejected (0.214319ms)
✔ M06 killed: unreviewed near pair is rejected (0.151516ms)
✔ M07 killed: rationale-free waiver is rejected (0.145907ms)
✔ M08 killed: missing semantic field is rejected (0.164415ms)
✔ M09 killed: prior-corpus collision cannot be hidden (0.661183ms)
✔ M10 killed: premature owner approval is rejected (0.329561ms)
ℹ tests 10
ℹ suites 0
ℹ pass 10
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 77.828765
```
