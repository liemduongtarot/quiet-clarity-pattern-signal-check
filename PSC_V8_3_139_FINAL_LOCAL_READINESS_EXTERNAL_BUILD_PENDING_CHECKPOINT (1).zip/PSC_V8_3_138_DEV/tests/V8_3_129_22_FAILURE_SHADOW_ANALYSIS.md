# V8.3.129 — 22-Failure Shadow Analysis

Execution mode: canonical shadow only. V8.3.128 Batch A was not rerun; the preserved raw cases are architecture probes and legacy output remains the user-facing authority.

## Result

- Probe definitions: 22
- Canonical representation checks passed: **22/22**
- Canonical invariant violations: **0** in the probe campaign
- Direct case/phrase patches: **0**
- Legacy expected contracts changed: **0**

| Cases | Legacy first divergence | Expected canonical structure | Actual shadow result | Canonical field correctness |
|---|---|---|---|---|
| A01, A03, A05 | reality/frame | proposition-scoped non-real operator | non-real subtype represented and route contribution derived | PASS 3/3 |
| A06, A08, A09 | actor/ownership | explicit third-party actor graph | actor and third-party ownership represented | PASS 3/3 |
| A11, A12, A14, A15, A17, A18, A19, A20, A21, A25, A26 | predicate/object | compositional predicate + object/context facts | canonical predicate/object/evidence distinctions represented | PASS 11/11 |
| A22, A24 | clause/relation | proposition IDs connected by AND/AFTER | typed graph edges preserved | PASS 2/2 |
| A27, A28, A30 | question intent | speech act + semantic target intent | prediction/decision intent represented | PASS 3/3 |

Detailed executable contracts are in `v83129-22-probes-shadow.test.cjs`. They test semantic structures, not final-family-only outputs.

## Difference governance

The initial shadow comparator uses `BOTH_CORRECT_EQUIVALENT`, `REPRESENTATION_DIFFERENCE_OUTPUT_SAME`, or `INSUFFICIENT_EXPECTED_AUTHORITY` when no independent case-level expected authority is supplied. It never silently promotes the canonical result. The 22 probes use the preserved architecture-map expectations solely for field correctness.

## Limitation

Passing these 22 representation probes is necessary but not sufficient for canonical authority cutover. Broader shadow convergence and historical canonical-derived output parity remain required before final family/route/sequence authority can migrate.
