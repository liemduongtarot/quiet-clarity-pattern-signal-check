# PSC Semantic Authority Migration Map

Design status only. Frozen authority remains V8.3.128; this document does not modify runtime behavior.

## Target authority table

Default raw-text reparse permission is **NO**. Only the named producer receives the normalized token/span view needed for its fact.

| Semantic fact | Authoritative stage | Input dependencies | Allowed mutations | Downstream consumers | Raw reparse |
|---|---|---|---|---|---|
| clause IDs/spans | clause graph builder | normalized tokens, punctuation, connectors | split/merge during graph build only | all resolvers | NO downstream |
| proposition IDs | proposition builder | clause graph, predicate arguments | add proposition before seal | operators, entities, relations | NO downstream |
| actor/person | entity/coreference resolver | proposition subject span, attribution graph | unknown→resolved; never resolved→different without coreference record | ownership, family, route | NO |
| ownership | ownership resolver | actor graph, possessive/coreference relation | unknown→self/shared/third-party | eligibility, route | NO |
| target | argument resolver | proposition arguments | unknown→resolved | predicate/family | NO |
| predicate | compositional predicate normalizer | lemma, auxiliaries, particles, object class | unknown→canonical predicate before seal | evidence, family, sequence | NO |
| predicate class | predicate ontology | predicate + object semantic class | unknown→class before seal | family qualification | NO |
| object/class | argument + object classifier | direct/oblique object spans | unknown→class before seal | predicate, evidence, family | NO |
| polarity/negation scope | scoped operator resolver | negation operator and proposition graph | attachment correction before seal only | eligibility, family | NO |
| cessation | scoped operator resolver | aspect/cessation operator | unknown→active/ceased | eligibility, sequence | NO |
| reality/hypothetical/example | frame operator resolver | frame operators and graph scope | subtype refinement before seal | eligibility, route | NO |
| quotation/attribution | attribution resolver | quote/report operators, speaker graph | unknown→resolved | actor, ownership, route | NO |
| constraint | constraint resolver | causal/constraint proposition and relation | unknown→external/internal/none | family, route | NO |
| frequency/repetition | quantifier resolver | quantifier/operator attachment | unknown→value | evidence/family | NO |
| evidence sufficiency/change | evidence reducer | canonical evidence propositions/relations | monotonic refinement before seal | review qualification | NO |
| boundedness | quantifier/temporal reducer | duration/count/completion operators | unknown→bounded/unbounded | family qualification | NO |
| temporal position/relation | relation graph builder | clause graph and connector operators | graph edits before seal only | sequence/serializer | NO |
| speech act/question intent | intent resolver | interrogative syntax + proposition graph | unknown→classified before seal | route | NO |
| family candidate/eligibility | family qualifier | sealed canonical propositions | candidate→eligible/ineligible with reason | output/route guard | NO |
| suppression reason | family qualifier | canonical facts + rule | append reason only | trace/output | NO |
| public route | route resolver | safety envelope + canonical intent/reality/actor/ownership | one deterministic resolution | serializer/evaluator | NO |

## Downstream ownership contract

- Each stage receives a read-only projection. A stage cannot inspect raw text except surface, clause, proposition-argument, and its explicitly registered lexical resolver.
- Lexical recognizers propose lemmas/features with spans; they do not emit families or routes.
- Unknown remains explicit. Defaults cannot silently mean `self`, `actual`, positive, sufficient, or eligible.
- Every accepted mutation appends a provenance event with producer, rule, span, previous and new values.
- Qualification, sequence, route and serializer cannot call legacy `analyze`, `semanticNormalize`, `inputRoute`, regex dictionaries, or fold raw input.

## Migration phases recommended for this source

1. **Schema and trace scaffold:** add canonical builder behind a feature flag in a new working copy; public V8.3.128 output remains authoritative.
2. **Shadow construction:** on existing non-sealed regression corpora, record legacy result, canonical state, canonical-derived result and structured diff. Do not alter user-visible behavior.
3. **Representation authorities:** migrate clause/proposition graph, actor/ownership, reality/operators, then predicate/object. Gate each transfer with Level-1 representation and invariant mutations.
4. **Derived authorities:** migrate evidence, boundedness/frequency, intent, and sequence. Remove the corresponding raw reparsers once parity/conflict review passes.
5. **Decision authorities:** family qualification and public route consume canonical state only. Compare against legacy in shadow mode; owner reviews intentional differences.
6. **Contraction:** retire duplicate V121–V127 inference paths; keep only a separately callable compatibility oracle during a bounded observation window. It must not participate in production decisions.
7. **Fallback retirement:** remove compatibility oracle after required regression/E2E and new first-run governance. No sealed pool is created during architecture or migration convergence.

## Shadow-mode record

For every eligible development-regression input: `{case_id, legacy_result, canonical_state, canonical_derived_result, field_diffs, output_diff, invariant_violations}`. Sealed V8.3.128 Batch A is evidence-only and must not be rerun or used for tuning.

## Risk

Highest risk is behavioral drift during authority transfer because known V8.3.127 behavior is produced by interactions among seven wrappers. Mitigation is field-by-field shadow comparison, explicit unknowns, fail-closed assertions, and retirement only after the replacement authority has representation, invariant, mutation, and E2E evidence. A big-bang rewrite is rejected.
