# V8.3.132 Version Graph

`V8.3.121 original source unavailable`
→ `V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE`
→ `V8.3.122`
→ `V8.3.123 FAILED RC`
→ `V8.3.124 FAILED RC`
→ `V8.3.125 FAILED RC`
→ `V8.3.126 FAILED RC`
→ `V8.3.127 READY FOR MANUAL STEP 111 REVIEW`
→ `V8.3.128 FAILED RC`
→ `V8.3.129 FAILED RC`
→ `V8.3.130 FAILED RC`
→ `V8.3.131 FAILED RC`
→ `V8.3.132 FAILED REVIEW CANDIDATE`

V8.3.132 parent authority is the immutable V8.3.131 failed candidate. Recovery provenance remains disclosed: reconstructed evidence is not relabeled as original V8.3.121 evidence.
