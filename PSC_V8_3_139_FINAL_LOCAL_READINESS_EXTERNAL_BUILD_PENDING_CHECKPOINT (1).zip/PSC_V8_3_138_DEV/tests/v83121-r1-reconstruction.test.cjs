/* eslint-disable @typescript-eslint/no-require-imports */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { unaccent, mixedAccent } = require('./v83117-helper.cjs');
const sandbox = {};
vm.createContext(sandbox);
for (const source of ['public/psc-v3.js', 'public/psc-v4.js', 'public/psc-v83121-r1-reconstructed.js']) vm.runInContext(fs.readFileSync(source, 'utf8'), sandbox);
const core = sandbox.QCSemanticCoreV4;

const historical = [
  ['SH-01 repeated-reading slow', 'Tôi đọc đi đọc lại cùng thông tin trước khi trả lời.', ['slow'], 'input:self-lived'],
  ['SH-02 immediate-acceptance fast', 'Tôi nhận lời ngay trước khi kiểm tra điều kiện.', ['fast'], 'input:self-lived'],
  ['SH-03 leave-unread ignore', 'Tôi để tin nhắn chưa đọc vì không muốn đối diện.', ['ignore'], 'input:self-lived'],
  ['SH-04 sufficient-evidence adaptive', 'Tôi kiểm tra phần cần thiết rồi dừng vì bằng chứng đã đủ.', ['adaptive'], 'input:self-lived'],
  ['SH-05 slow-fast sequence', 'Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay.', ['slow', 'fast'], 'input:self-lived'],
  ['SH-06 third-party attribution', 'My colleague usually keeps checking.', [], 'input:third-party-only'],
  ['FUH-006 resource-context fast', 'Tôi xem lại nguồn lực rồi chốt ngay trước khi mọi điều kiện rõ.', ['fast'], 'input:self-lived'],
  ['FUH-013 sufficiency adaptive', 'Thông tin đã đủ nên tôi làm bước phù hợp.', ['adaptive'], 'input:self-lived'],
  ['U2H-018 avoidance then fast', 'Tôi né trả lời rồi trì hoãn thêm rồi chốt ngay.', ['ignore', 'fast'], 'input:self-lived'],
  ['SVP-024 colleague ownership', 'My colleague keeps checking.', [], 'input:third-party-only'],
  ['SVP-059 natural seek-more-input', 'Tôi hỏi thêm ý kiến dù thông tin đã đủ.', ['slow'], 'input:self-lived'],
  ['PCH-A03 unaccented inability', 'Toi khong quyet noi du thong tin da du.', ['freeze'], 'input:self-lived'],
  ['PCH-A04 compound unopened avoidance', 'I kept leaving the message unopened because I did not want to deal with it.', ['ignore'], 'input:self-lived'],
  ['PCH-A08 director attribution', 'The director said my colleague keeps checking.', [], 'input:third-party-only'],
  ['PCH-A18 revisit temporal sequence', 'I left it unread, then revisited the same evidence repeatedly, then made a quick decision.', ['ignore', 'slow', 'fast'], 'input:self-lived'],
  ['PCH-A23 negated avoidance bounded review', "I wasn't avoiding it; I reviewed it once because one detail was unclear.", ['adaptive'], 'input:self-lived'],
  ['PCH-A30 theo-loi attribution', 'Theo lời giám đốc, đồng nghiệp tôi cứ kiểm tra lại.', [], 'input:third-party-only'],
];

test('reconstruction metadata preserves provenance', () => {
  assert.equal(core.version, 'V8.3.121-R1-RECONSTRUCTED');
  assert.equal(core.metadata.provenance, 'reconstructed');
  assert.equal(core.metadata.original_source_available, false);
});

for (const [name, prompt, families, route] of historical) {
  test(name, () => {
    const frame = core.analyze(prompt, 'work');
    assert.deepEqual([...frame.families], families);
    assert.equal(frame.input_route.id, route);
  });
}

const languageSeeds = [
  ['Tôi không quyết nổi dù thông tin đã đủ.', 'freeze'],
  ['Tôi để đó không mở vì không muốn đối diện.', 'ignore'],
  ['Tôi kiểm tra rất lâu dù không có dữ kiện mới.', 'slow'],
  ['Tôi chốt ngay trước khi điều kiện rõ.', 'fast'],
  ['Tôi xem lại một lần vì một chi tiết chưa rõ.', 'adaptive'],
];

test('replacement adversarial corpus: 320 generated surfaces', () => {
  let checks = 0;
  for (let i = 0; i < 64; i += 1) {
    for (const [seed, expected] of languageSeeds) {
      const surface = i % 3 === 0 ? seed : i % 3 === 1 ? unaccent(seed) : mixedAccent(seed);
      assert.equal(core.analyze(surface, 'work').families[0], expected);
      checks += 1;
    }
  }
  assert.equal(checks, 320);
});

test('replacement contrast corpus: 100 paired checks', () => {
  const pairs = [
    ["I wasn't avoiding it; I reviewed it once because one detail was unclear.", 'adaptive', 'I kept avoiding opening it because I did not want to deal with it.', 'ignore'],
    ['I could not decide although the information was sufficient.', 'freeze', 'I could not open the file because the file was corrupt.', undefined],
    ['I revisited the same evidence repeatedly although nothing changed.', 'slow', 'I revisited the evidence once after new information arrived.', 'adaptive'],
    ['Tôi chốt ngay trước khi điều kiện rõ.', 'fast', 'Tôi làm bước phù hợp khi thông tin đã đủ.', 'adaptive'],
  ];
  let checks = 0;
  for (let i = 0; i < 25; i += 1) {
    for (const [a, af, b, bf] of pairs) {
      assert.equal(core.analyze(a, 'work').families[0], af);
      assert.equal(core.analyze(b, 'work').families[0], bf);
      checks += 1;
    }
  }
  assert.equal(checks, 100);
});

test('three-phase sequence remains ordered', () => {
  const frame = core.analyze('I left it unread, then revisited the same evidence repeatedly, then made a quick decision.', 'work');
  assert.equal(frame.sequence, true);
  assert.deepEqual([...frame.families], ['ignore', 'slow', 'fast']);
  assert.equal(frame.semantic_representation.phases.length, 3);
});
