/* eslint-disable @typescript-eslint/no-require-imports */
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const sandbox={};vm.createContext(sandbox);for(const file of ['public/psc-v3.js','public/psc-v4.js','public/psc-v83121-r1-reconstructed.js','public/psc-v83122-operator-aware.js','public/psc-v83123-family-preservation.js'])vm.runInContext(fs.readFileSync(file,'utf8'),sandbox);const core=sandbox.QCSemanticCoreV4;
const family=text=>[...core.analyze(text,'work').families];
const probes=[
  ['ignore',['I set the request aside without opening it so the exchange would remain untouched.']],
  ['ignore',['Tôi bỏ thông báo sang bên không đọc để không phải tham gia trao đổi.']],
  ['slow',['Even after the facts were settled, I kept consulting people and checking the same record.']],
  ['slow',['Dù thông tin đã đủ, tôi cứ hỏi thêm ý kiến và đối chiếu lại cùng dữ kiện.']],
  ['fast',['I made a quick decision before the necessary evidence was available.']],
  ['fast',['Tôi quyết ngay cho xong trước khi có đủ dữ kiện cần thiết.']],
  ['adaptive',['I checked the amended evidence once and then stopped.']],
  ['adaptive',['Tôi xem chi tiết mới đúng một lần rồi dừng.']],
  ['none',['I could not read the record because the network was down.']],
  ['none',['Tôi không thể mở hồ sơ vì hệ thống bị lỗi.']],
  ['sequence',['At first I left the brief unread, then continually rechecked unchanged facts, and finally made a hasty decision.']],
  ['sequence',['Ban đầu tôi để hồ sơ chưa đọc, sau đó cứ xem lại dữ kiện cũ, cuối cùng quyết vội cho xong.']]
];
const contexts=['The account concerns my own conduct.','This is a current real event.','No quotation changes who acted.','The clauses retain their stated order.','The description adds no hypothetical condition.','The wording does not change the evidence.','This is being assessed in a work context.','The narrative ends here.'];
test('development convergence probe: 96 unseen compositional variants',()=>{let count=0;for(const [expected,items]of probes)for(const text of items)for(const context of contexts){const actual=family(`${text} ${context}`);if(expected==='sequence')assert.deepEqual(actual,['ignore','slow','fast']);else if(expected==='none')assert.deepEqual(actual,[]);else assert.equal(actual[0],expected,`${expected}: ${text}`);count++;}assert.equal(count,96);});
test('convergence invariants remain clean',()=>{for(const [,items]of probes)for(const text of items)assert.deepEqual(Array.from(core.semanticNormalize(text).trace.invariant_violations),[]);});
