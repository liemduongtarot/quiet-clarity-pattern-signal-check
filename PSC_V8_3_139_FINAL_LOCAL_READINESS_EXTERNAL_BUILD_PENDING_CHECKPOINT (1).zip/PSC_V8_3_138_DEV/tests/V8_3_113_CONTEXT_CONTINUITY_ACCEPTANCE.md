# V8.3.113 Context Continuity Acceptance

## Defect class

The questionnaire could recognize a user's domain and emotion during clarification, then fall back to generic language such as “tình huống này” or “khó chịu” on later screens. That made the flow appear to lose the user's original context.

## Architectural correction

- A single memoized `caseContext()` now owns domain, topic, explicit emotion, label, hypothesis, and event wording.
- Question titles A–H, question labels, question options, and the evidence target consume that same object.
- Explicit emotions are preserved instead of being replaced by a generic discomfort label.
- Special trust and contact-waiting routes remain intact.

## Verification

| Suite | Result |
|---|---:|
| V8.3.113 context-continuity contract | 88/88 |
| Money + helplessness routing | 12/12 |
| Emotion-only matrix | 128/128 |
| Context fallback matrix | 22/22 |
| Paired routing regression | 30/30 |
| Family routing regression | 12/12 |
| Successor locked holdout | 60/60 |
| Total accepted checks | 352/352 |

Lint and production build passed. The first V8.3.113 holdout run was superseded because a final wording polish followed it; it is not counted as final acceptance. The successor 60-case holdout was designed and run only after the final source freeze and passed on its first run.

## Source lock

`public/candidate.html` SHA-256: `c86284d38afafffdb014c47abd2e4cfddb2c027c071cc99fc179524051376a22`

This acceptance closes the context-loss and generic-wording defect class covered by the invariants above. It does not claim that no future natural-language phrasing can ever require lexicon expansion.
