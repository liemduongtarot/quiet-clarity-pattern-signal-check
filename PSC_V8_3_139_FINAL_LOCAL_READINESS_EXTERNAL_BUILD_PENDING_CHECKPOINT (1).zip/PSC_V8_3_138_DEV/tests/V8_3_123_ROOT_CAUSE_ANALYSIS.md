# V8.3.123 Root-Cause Analysis — V8.3.122 Batch A Failures

## Governance

This analysis was completed before any V8.3.123 semantic-source change. V8.3.122 remains immutable. Its gold contracts, Batch A first-run evidence and failed-RC archive are unchanged. The five exact failed inputs are now **CONTAMINATED REGRESSION** evidence, never pristine holdout evidence.

## Root-cause table

| Case | Surface / language | Clause structure | Canonical proposition | Predicate normalization | Negation | Temporal operator | Evidence status | Ownership | Expected family activation | Actual family activation | Where activation was lost | Shared failure family | Proposed architectural repair |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V122-A02 | English phrasal construction | One causal clause: maintained object-state + avoidance purpose | deliberately leave a communication unopened / avoid engagement | **Missing**: `kept … unopened` was outside the verb-object-state normalization grammar | `not have to engage` is purpose/complement scope, not cancellation of the maintained unopened state | none | unspecified | real, self | ignore | none | Predicate normalization, before family generation | phrasal/implicit ignore false negative | Introduce proposition extraction for maintain/keep/leave/put + communication object + unopened/unread/pending state; attach purpose complement without globally negating the proposition |
| V122-A16 | Vietnamese accented, three clauses | P1 `để … chưa đọc` → P2 repeated revisit → P3 immediate closure | P1 leave request unread; P2 revisit old evidence; P3 decide immediately | P1 **missing** because ontology covered `chưa xem` and `không đọc`, not the productive `chưa đọc` state; P2/P3 normalized | P1 `chưa` marks object state, not negation cancelling ignore | `rồi` → `rồi` | unspecified/old evidence | real, self | ignore → slow → fast | slow → fast | Predicate normalization in P1; sequence builder received only P2/P3 | first-phase loss caused upstream by ignore normalization gap | Normalize unread/unopened pending-state propositions independently of surface verb; preserve all valid phase candidates by phase ID and order |
| V122-A20 | Vietnamese accented attribution/confirmation | Attributed self proposition + explicit agreement | self-confirmed over-processing / excessive consideration | Candidate cue `nghĩ quá nhiều` existed, but was suppressed | False cessation: token `từng` in `từng lựa chọn` was interpreted as historical `used to`; false `still`: `vẫn` matcher collided with `cố vấn` after accent folding | spurious `cessation`, spurious `still` | confirmed attributed claim | attributed self, explicitly confirmed | slow | none | Operator detection and attribution parsing before activation | token-boundary collision + incomplete attribution grammar | Replace ambiguous single-token cessation/still rules with contextual operators; parse `X nói [tôi…], và tôi đồng ý` as confirmed attributed-self proposition; require explicit suppression grounds |
| V122-A25 | English | One clause: rapid response before threshold | respond immediately before sufficient evidence | **Successfully normalized** to `immediate-resolution-seeking` / fast | none | before | threshold not yet met semantically, though the legacy lexical sufficiency bit sees `enough evidence` without modelling `before` scope | real, self | fast | none | Integration gate after normalization: semantic fast candidate existed but V8.3.122 `targetedCorrection` did not select it over inherited no-family | canonical predicate dropped downstream | Enforce CANONICAL_PREDICATE_PRESERVATION: a valid real self predicate survives unless an explicit suppression record exists; model threshold scope (`before enough evidence`) |
| V122-A26 | English three clauses | P1 maintained unopened state → P2 repeated checking → P3 quick decision | P1 leave communication unopened; P2 repeated check; P3 premature decision | P1 **missing** for the same productive `kept … unopened` gap; P2/P3 normalized | none | then → then | old notes / unspecified threshold | real, self | ignore → slow → fast | slow → fast | Predicate normalization in P1; downstream sequence correctly retained only propositions it received | first-phase loss caused upstream by ignore normalization gap | Same productive ignore proposition grammar plus phase-preservation invariant and stage-level trace |

## Failure location classification

| Case | Classification | Evidence |
|---|---|---|
| V122-A02 | **A + E** | Predicate did not normalize; purpose-clause negation must be scoped locally rather than applied as proposition cancellation. |
| V122-A16 | **A**, producing apparent **C** | Phase segmentation was correct, but P1 had no predicate, so it could not reach sequence construction. |
| V122-A20 | **D + E + H** | False cessation/still operators and incomplete self-confirmed attribution grammar suppressed an otherwise recognisable slow cue. |
| V122-A25 | **B + F/H** | Canonical fast predicate and family candidate existed; downstream integration selection discarded it. |
| V122-A26 | **A**, producing apparent **C** | Phase segmentation was correct, but P1 normalization failed. |

## Shared architectural conclusions

1. The five failures are not one synonym problem.
2. Three demonstrate loss before or during proposition normalization.
3. One demonstrates operator/token-scope suppression.
4. One demonstrates a post-normalization family-preservation failure.
5. The sequence builder cannot preserve a phase whose proposition disappeared upstream, so phase tracing must begin before normalization.
6. V8.3.123 must expose a proposition-level intermediate representation and an explicit suppression reason whenever a canonical family candidate does not activate.

## Required invariants

### CANONICAL_PREDICATE_PRESERVATION

If a proposition is real and self-relevant, is not cancelled by correctly scoped negation or cessation, is not solely an external constraint, and maps to a canonical behavioural predicate, its family candidate must survive into sequence/classification unless a documented suppression reason is attached.

### VALID_FAMILY_MUST_NOT_DROP_TO_NONE

If at least one proposition reaches `activation_status = active`, final routing must contain at least one corresponding family.

### TEMPORAL_PHASE_PRESERVATION

If P1, P2 and P3 each contain a valid active behavioural proposition, the sequence layer must retain P1 → P2 → P3 without dropping, merging, reordering or flattening them.

## Repair boundary

The repair must operate on productive proposition grammar, operator scope, family-candidate preservation and ordered phase construction. It must not special-case the five exact sentences or alter their historical expected contracts.
