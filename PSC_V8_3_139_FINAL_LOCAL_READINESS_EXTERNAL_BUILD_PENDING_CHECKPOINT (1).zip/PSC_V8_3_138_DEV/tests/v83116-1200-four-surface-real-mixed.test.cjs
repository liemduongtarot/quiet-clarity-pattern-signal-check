/* V8.3.116 Review Candidate: 300 VN + 300 EN full semantic-flow runs. */
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const c={};vm.createContext(c);vm.runInContext(fs.readFileSync('public/psc-v3.js','utf8'),c);const core=c.QCSemanticCoreV3;
const pairs=[
 ['Mỗi khi yêu cầu chưa rõ, tôi lo mình làm sai nên cứ kiểm tra thêm và trì hoãn bắt đầu.','When the requirements are unclear, I worry I may get it wrong, so I keep checking and delay getting started.','slow'],
 ['Tôi thường hỏi thêm người khác để được xác nhận rồi vẫn chuẩn bị thêm trước khi bắt đầu.','I usually ask someone else for reassurance and then prepare further before I begin.','slow'],
 ['Tôi rất phấn khích nên muốn quyết ngay và nhận quá nhiều việc cùng lúc.','I feel very excited, so I want to decide straight away and take on too much at once.','fast'],
 ['Khi thấy áp lực, tôi làm ngay và cam kết quá sớm dù điều kiện còn chưa rõ.','When I feel under pressure, I act immediately and commit too early even though the conditions remain unclear.','fast'],
 ['Tôi biết cần xử lý nhưng bị đứng lại, không biết bắt đầu từ đâu và chưa chốt được gì.','I know it needs dealing with, but I become stuck, cannot see where to begin and cannot decide.','freeze'],
 ['Tôi buồn và muốn làm gì đó nhưng cứ đứng yên, không chuyển được suy nghĩ thành bước đầu tiên.','I feel sad and want to do something, but I remain stuck and cannot turn my thoughts into a first step.','freeze'],
 ['Tôi cứ chuyển sang việc khác và giữ mình bận để né phần đang làm mình khó chịu.','I keep moving to something else and staying busy to avoid the part that makes me uncomfortable.','ignore'],
 ['Tôi làm như chuyện đó không quan trọng, không mở phản hồi và chờ vấn đề tự biến mất.','I behave as though it does not matter, do not open the response and wait for the problem to disappear.','ignore'],
 ['Tôi kiểm tra rất lâu rồi cuối cùng lại quyết ngay chỉ vì deadline đã gần.','I keep checking for a long time and then eventually decide straight away simply because the deadline is close.','slow'],
 ['Tôi đứng lại một thời gian rồi chuyển sang né và làm như mình không còn quan tâm.','I remain stuck for a while and then avoid it and behave as though I no longer care.','freeze'],
 ['Tôi không bắt đầu vì thật sự đang chờ phê duyệt và chưa có quyền quyết định.','I do not start because I am genuinely waiting for approval and do not have the authority to decide.','freeze'],
 ['Tôi xem lại vừa đủ, dừng khi đã đủ thông tin và điều chỉnh khi có dữ kiện mới.','I review it sufficiently, stop when I have enough information and adjust when new evidence appears.','adaptive']
];
const contexts=[
 ['Điều này đã xảy ra nhiều lần gần đây.','This has happened repeatedly recently.'],['Nó đang ảnh hưởng rõ đến thời gian của tôi.','It is clearly affecting my time.'],['Tôi nhận ra nó nhưng vẫn thường làm theo.','I notice it but still usually follow it.'],['Chuyện này chỉ xảy ra với một người cụ thể.','This only happens with one particular person.'],['Ở những hoàn cảnh khác tôi phản ứng linh hoạt hơn.','In other circumstances I respond more flexibly.'],['Tôi chưa chắc chuyện cũ ảnh hưởng bao nhiêu.','I am not sure how much the past affects it.'],['Khả năng xấu thường chiếm nhiều sự chú ý.','A negative possibility often takes much of my attention.'],['Kết quả thực tế chưa nghiêm trọng nhưng tiến độ đã chậm.','The practical outcome is not severe, but progress has slowed.'],['Tôi vẫn phân biệt được dữ kiện với điều mình đang sợ.','I can still distinguish evidence from what I fear.'],['Việc này liên quan đến tiền và nguồn lực.','This involves money and resources.'],['Nó ảnh hưởng cách tôi giao tiếp với người khác.','It affects how I communicate with other people.'],['Có lúc tôi phản ứng khác khi quá mệt.','At times I respond differently when exhausted.'],['Tôi có đủ kỹ năng nhưng không phải lúc nào cũng đủ thời gian.','I have the skills but do not always have enough time.'],['Người khác không trực tiếp ép tôi chọn.','No one else is directly forcing me to choose.'],['Tôi muốn hiểu phản ứng chứ không hỏi dự đoán.','I want to understand the response rather than ask for a prediction.'],['Tình huống có một số ràng buộc thực tế.','The situation includes some practical constraints.'],['Tôi chưa biết đây là thói quen hay phản ứng nhất thời.','I do not yet know whether this is a habit or a temporary response.'],['Nó có thể nhẹ đi khi yêu cầu được làm rõ.','It may ease when the requirements are clarified.'],['Tôi không muốn hệ thống giả định động cơ của mình.','I do not want the system to assume my motive.'],['Có cả cảm xúc lẫn quyết định thực tế liên quan.','Both emotion and a practical decision are involved.'],['Tôi thấy hậu quả rõ nhất ở việc chưa hoàn tất.','The clearest consequence is that it remains unfinished.'],['Mức độ phản ứng thay đổi theo bối cảnh.','The strength of the response changes with context.'],['Tôi vẫn có thể ngắt phản ứng trong một số lần.','I can still interrupt the response on some occasions.'],['So với trước đây, phản ứng chưa thay đổi nhiều.','Compared with before, the response has not changed much.'],['Tôi muốn kiểm tra một tình huống thật đang xảy ra.','I want to examine a real situation that is happening now.']
];
const domains=['work','money','romantic','family','friends','home','daily','direction'];
const unaccent=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D');
const mixedAccent=s=>s.split(/(\s+)/).map((part,i)=>i%4===0?unaccent(part):part).join('');
test('300 real situations x 400 answer-grid cells x 4 language surfaces',()=>{
 let runs=0,pairsChecked=0,routeCells=0,fullAnswerPaths=0;const failures=[],allFamilies=['slow','fast','freeze','ignore','adaptive'],dimensions='ABCDEFGH'.split('');
 pairs.forEach((p,pi)=>contexts.forEach((m,mi)=>{
   const domain=domains[(pi+mi)%domains.length],vi=`${p[0]} ${m[0]}`,en=`${p[1]} ${m[1]}`,vf=core.analyze(vi,domain),ef=core.analyze(en,domain);
   const vu=core.analyze(unaccent(vi),domain),vmix=core.analyze(mixedAccent(vi),domain);
   for(const [frame,lang] of [[vf,'vi'],[vu,'vi'],[vmix,'vi'],[ef,'en']]){
     runs++;const family=frame.families[0]||p[2],clar=`v3:${family}`;
     const titles=dimensions.map(F=>core.title(frame,F,clar)),banks=dimensions.map(F=>core.options(frame,F,clar));
     const answers=Object.fromEntries(dimensions.map(F=>[F,[`v3:${F}:${family}:1`]]));
     const result=core.evaluate(frame,{family,clarification:clar,answers,reinforcement:`v3:E:${family}:1`,repetition:3,enactment:3,interruptibility:3,trend:3,behaviourBeyondConstraint:p[2]!=='freeze'});
     const pass=frame.language===lang&&titles.every(Boolean)&&banks.every(x=>x.length===10)&&result.label&&result.classification&&(p[2]==='adaptive'?result.classification==='adaptive':true);
     if(!pass)failures.push({pi,mi,lang,frame,result});
     for(const routedFamily of allFamilies)for(let answerPosition=1;answerPosition<=10;answerPosition++){
       const routedClar=`v3:${routedFamily}`,routedAnswers={};
       for(const F of dimensions){const opts=core.options(frame,F,routedClar),option=opts[answerPosition-1];routeCells++;if(!option||opts.length!==10||option.id!==`v3:${F}:${routedFamily}:${answerPosition}`)failures.push({pi,mi,lang,routedFamily,F,answerPosition,option});routedAnswers[F]=[option.id]}
       const routedResult=core.evaluate(frame,{family:routedFamily,clarification:routedClar,answers:routedAnswers,reinforcement:routedAnswers.E[0],repetition:3,enactment:3,interruptibility:3,trend:3,behaviourBeyondConstraint:true});
       fullAnswerPaths++;if(!routedResult.label||routedResult.family!==routedFamily)failures.push({pi,mi,lang,routedFamily,answerPosition,routedResult});
     }
   }
   const parity=core.parity(vi,en,domain),surfaceParity=core.parity(vi,unaccent(vi),domain),mixedParity=core.parity(vi,mixedAccent(vi),domain);pairsChecked++;if((!parity.pass||!surfaceParity.pass||!mixedParity.pass)&&p[2]!=='adaptive')failures.push({pi,mi,type:'parity',left:parity.left.responses,right:parity.right.responses});
 }));
 assert.equal(runs,1200);assert.equal(pairsChecked,300);assert.equal(routeCells,300*4*5*10*8);assert.equal(fullAnswerPaths,300*4*5*10);assert.deepEqual(failures,[]);
});
