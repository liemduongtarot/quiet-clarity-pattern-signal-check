# V8.3.129 Sealed Pool Selection Report

Status: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.

- Candidates generated: 100
- Candidates rejected/not selected: 40
- Final selected: 60
- Historical/adversarial/contrast/convergence items compared: 556
- Runtime executions: 0

## Rejection distribution

```json
{
  "DELIBERATE_AUDIT_STRESS_VARIANT": 32,
  "NORMALIZED_DUPLICATE": 32,
  "IDENTIFIER_STRIPPED_DUPLICATE": 32,
  "FINGERPRINT_DUPLICATE": 32,
  "TEMPLATE_ORIGIN_COLLISION": 32,
  "PRIOR_LEXICAL_NEAR_DUPLICATE": 1,
  "DIVERSITY_SELECTION_SURPLUS": 7
}
```

## Coverage distribution

```json
{
  "public_route": {
    "input:hypothetical-or-example": 4,
    "input:third-party-only": 8,
    "input:self-lived": 37,
    "input:decision-request": 3,
    "input:prediction": 4,
    "input:clarification-required": 4
  },
  "internal_reality_status": {
    "hypothetical": 4,
    "current": 41,
    "future": 7,
    "unknown": 4,
    "reported_actual": 4
  },
  "actor_type": {
    "third_party": 12,
    "self": 40,
    "unknown": 4,
    "reported_actor": 4
  },
  "ownership": {
    "third_party": 16,
    "self": 40,
    "unknown": 4
  },
  "predicate_class": {
    "review": 24,
    "constraint": 4,
    "avoidance": 5,
    "decision": 8,
    "inability": 4,
    "decision_request": 3,
    "prediction": 4,
    "unknown": 4,
    "behavioral_question": 4
  },
  "object_semantic_class": {
    "evidence": 24,
    "requirement": 4,
    "communication": 4,
    "decision_option": 15,
    "event": 4,
    "unknown": 4,
    "behavior": 4,
    "task": 1
  },
  "expected_family_set": {
    "NO_FAMILY": 32,
    "ignore": 4,
    "slow": 6,
    "fast": 4,
    "freeze": 4,
    "adaptive": 6,
    "fast+slow": 4
  },
  "polarity": {
    "positive": 55,
    "unknown": 4,
    "negative": 1
  },
  "negation_status": {
    "none": 55,
    "unknown": 4,
    "explicit": 1
  },
  "cessation_status": {
    "none": 56,
    "unknown": 4
  },
  "evidence_sufficiency": {
    "unknown": 36,
    "sufficient": 10,
    "insufficient": 14
  },
  "evidence_change": {
    "stable": 50,
    "increased": 6,
    "unknown": 4
  },
  "boundedness": {
    "bounded": 38,
    "unbounded": 18,
    "unknown": 4
  },
  "repetition": {
    "single": 42,
    "repeated": 14,
    "unknown": 4
  },
  "constraint_status": {
    "none": 44,
    "external": 4,
    "external_deadline": 4,
    "external_process": 4,
    "unknown": 4
  },
  "question_intent": {
    "none": 45,
    "decision_request": 3,
    "prediction": 4,
    "unknown": 4,
    "behavioral_pattern": 4
  },
  "temporal_structure": {
    "single_phase": 52,
    "three_phase": 4,
    "unknown": 4
  },
  "sequence_shape": {
    "atomic": 32,
    "constraint_only": 4,
    "repetition": 6,
    "bounded_review": 6,
    "review_then_constraint_then_action": 4,
    "unknown": 4,
    "attribution": 4
  },
  "clause_count": {
    "1": 52,
    "2": 4,
    "3": 4
  },
  "clause_relations": {
    "illustrative": 1,
    "conditional": 1,
    "example_frame": 1,
    "mixed_hypothetical": 1,
    "possessive_actor": 1,
    "role_actor": 1,
    "possessive_third": 1,
    "code_switch_actor": 1,
    "causal_constraint": 1,
    "external_capacity": 1,
    "external_interruption": 1,
    "mixed_requirement": 1,
    "purpose_avoidance": 1,
    "object_avoidance": 1,
    "displacement": 1,
    "compound_avoidance": 1,
    "concessive_repetition": 1,
    "sufficient_reassurance": 1,
    "stable_repetition": 1,
    "mixed_repetition": 1,
    "premature_choice": 1,
    "insufficient_action": 1,
    "pre_review_action": 1,
    "mixed_premature": 1,
    "concessive_inability": 1,
    "explained_inability": 1,
    "sufficient_freeze": 1,
    "mixed_freeze": 1,
    "changed_bounded": 1,
    "time_bounded": 1,
    "new_evidence": 1,
    "mixed_bounded": 1,
    "three_phase_deadline": 1,
    "three_phase_pressure": 1,
    "seek_then_rush": 1,
    "mixed_three_phase": 1,
    "co_nen": 1,
    "which_self": 1,
    "mixed_decision": 1,
    "when_future": 1,
    "whether_future": 1,
    "when_external": 1,
    "mixed_prediction": 1,
    "underspecified": 1,
    "ambiguous_scope": 1,
    "missing_proposition": 1,
    "mixed_ambiguous": 1,
    "according_to": 1,
    "theo_loi": 1,
    "reported_clause": 1,
    "mixed_attribution": 1,
    "why_repetition": 1,
    "why_behavior": 1,
    "why_reassurance": 1,
    "mixed_why": 1,
    "post_resolution": 1,
    "comparison_repetition": 1,
    "scope_bounded": 1,
    "evidence_scoped": 1,
    "explicit_negation": 1
  },
  "language_surface": {
    "en": 16,
    "vi": 16,
    "vi-unaccented": 14,
    "vi-mixed": 14
  },
  "template_origin": {
    "independent-brief-001": 1,
    "independent-brief-002": 1,
    "independent-brief-003": 1,
    "independent-brief-004": 1,
    "independent-brief-005": 1,
    "independent-brief-006": 1,
    "independent-brief-007": 1,
    "independent-brief-008": 1,
    "independent-brief-013": 1,
    "independent-brief-014": 1,
    "independent-brief-015": 1,
    "independent-brief-016": 1,
    "independent-brief-017": 1,
    "independent-brief-018": 1,
    "independent-brief-019": 1,
    "independent-brief-020": 1,
    "independent-brief-021": 1,
    "independent-brief-022": 1,
    "independent-brief-023": 1,
    "independent-brief-024": 1,
    "independent-brief-027": 1,
    "independent-brief-028": 1,
    "independent-brief-029": 1,
    "independent-brief-030": 1,
    "independent-brief-031": 1,
    "independent-brief-032": 1,
    "independent-brief-033": 1,
    "independent-brief-034": 1,
    "independent-brief-035": 1,
    "independent-brief-036": 1,
    "independent-brief-037": 1,
    "independent-brief-038": 1,
    "independent-brief-041": 1,
    "independent-brief-042": 1,
    "independent-brief-043": 1,
    "independent-brief-044": 1,
    "independent-brief-046": 1,
    "independent-brief-047": 1,
    "independent-brief-048": 1,
    "independent-brief-049": 1,
    "independent-brief-050": 1,
    "independent-brief-051": 1,
    "independent-brief-052": 1,
    "independent-brief-065": 1,
    "independent-brief-066": 1,
    "independent-brief-067": 1,
    "independent-brief-068": 1,
    "independent-brief-009": 1,
    "independent-brief-010": 1,
    "independent-brief-011": 1,
    "independent-brief-012": 1,
    "independent-brief-053": 1,
    "independent-brief-054": 1,
    "independent-brief-055": 1,
    "independent-brief-056": 1,
    "independent-brief-025": 1,
    "independent-brief-026": 1,
    "independent-brief-039": 1,
    "independent-brief-040": 1,
    "independent-brief-057": 1
  }
}
```

All selected cases retain provenance `HUMAN_AUTHORED_SEMANTIC_BRIEF`; deliberate stress variants were not eligible. Pair-level evidence is stored in `V8_3_129_CANDIDATE_BANK_AUDIT.json`.
