# V8.3.126 Forensic Root-Cause and Route Enum Inventory

Status: **PRE-IMPLEMENTATION FORENSIC RECORD**  
Parent: `V8.3.125 FAILED REVIEW CANDIDATE` (immutable)  
Target: `V8.3.126 PUBLIC ROUTE CANONICALIZATION + CROSS-SURFACE TAXONOMY PARITY`

No V8.3.126 source change preceded this record. V8.3.125 Batch A was not rerun and its expected contracts were not changed.

## Exact failure trace

| Field | Evidence |
|---|---|
| Case | `V125-A21` (contaminated historical regression only) |
| Raw | `Gia su mot nguoi lap di lap lai viec xem ban nhap.` |
| Normalized lexical surface | `gia su mot nguoi lap di lap lai viec xem ban nhap.` |
| Historical expected | families `[]`; route `input:hypothetical-or-example`; sequence `false` |
| V8.3.125 actual | families `[]`; route `input:hypothetical`; sequence `false` |
| Parser/semantic result | actor and ownership `third-party`; reality assertion `hypothetical-or-example`; review proposition suppressed as non-real; no active family |
| Internal route inherited from base | `input:hypothetical` |
| Public route emitted | the same internal alias, without final canonicalization |

The behavioral result is correct. The defect is confined to the public route identifier. The unaccented Vietnamese operator `Gia su` is recognized by V8.3.125 `routeFacts`; therefore this is not a missing exact phrase and must not be repaired as one.

## Root-cause table

| Layer | Observed behavior | Verdict |
|---|---|---|
| Lexical normalization | `Gia su` is normalized and recognized as non-real | correct |
| Operator/reality semantics | `route_assertion.reality = hypothetical-or-example` | correct |
| Proposition activation | hypothetical review proposition is suppressed | correct |
| Family output | no family, no sequence | correct |
| Internal routing | legacy/base layer retains `input:hypothetical` | valid internal alias |
| Public canonicalization | no mandatory final mapping from internal reality to public taxonomy | **architectural gap** |
| UI routing surface | candidate UI calls inherited `inputRoute()` directly and recognizes only legacy `input:hypothetical` | **cross-surface parity gap** |

Shared architectural gap: **internal semantic/reality status and externally contracted route IDs are not separated by one mandatory, final public-route canonicalization boundary.** `analyze()` and the UI's direct `inputRoute()` path can therefore expose different route taxonomies for the same normalized semantics.

## Internal route/status enum inventory

These identifiers/statuses are implementation facts and are not all public-contract values:

- Reality/operator statuses: `real`, `real-self-lived`, `hypothetical`, `conditional-hypothetical`, `counterfactual`, `example`, `hypothetical-or-example`, `external-only`, `quoted-third-party`.
- Legacy/internal route aliases: `input:hypothetical`, `input:third-party`, `input:attributed-third-party`, `input:attributed-self-disputed`, `input:attributed-self-unconfirmed`.
- Stable route values also used internally: `input:empty`, `input:safety`, `input:prediction`, `input:decision-request`, `input:self-lived`, `input:external-only`, `input:invalid`, `input:clarification-required`.

Internal subtype information may survive in semantic metadata, but an internal alias must never leak through the public boundary.

## Canonical public route enum inventory

- `input:empty`
- `input:safety`
- `input:prediction`
- `input:decision-request`
- `input:self-lived`
- `input:hypothetical-or-example`
- `input:third-party-only`
- `input:external-only`
- `input:invalid`
- `input:clarification-required`

Canonical mapping obligations:

- all hypothetical/example/counterfactual/conditional-hypothetical internal states -> `input:hypothetical-or-example`;
- all exclusively third-party/quoted-third-party real states -> `input:third-party-only`;
- real self-lived states -> `input:self-lived`, except higher-priority safety/prediction/decision-request/empty/invalid contracts;
- external-only and clarification-required retain their canonical public IDs;
- priority routes remain stable and are never inferred from behavioral-family presence.

## Required repair boundary

V8.3.126 must introduce one explicit canonical mapper used by both `analyze()` and `inputRoute()`. It must preserve internal reality/subtype metadata, leave behavioral families unchanged, and enforce `PUBLIC_ROUTE_MUST_BE_CANONICAL`. UI routing must consume that same boundary. Exact-phrase handling for `Gia su` is prohibited.
