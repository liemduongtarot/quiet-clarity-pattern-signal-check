# PSC Legacy Parser Retirement Status — V8.3.129 Development

No parent or legacy file was deleted, overwritten, or relabeled. Retirement means removal from the active decision path, not destruction of historical code.

| Fact group / layer | Canonical producer | Consumer switched | Legacy authority on public result | Status |
|---|---:|---:|---:|---|
| clause/proposition graph | YES | YES | NO | CANONICAL AUTHORITY |
| predicate/object | YES | YES | NO | CANONICAL AUTHORITY |
| actor/ownership | YES | YES | NO | CANONICAL AUTHORITY |
| reality/operators | YES | YES | NO | CANONICAL AUTHORITY |
| question intent | YES | YES | NO | CANONICAL AUTHORITY |
| negation/cessation/evidence | YES | YES | NO | CANONICAL AUTHORITY |
| temporal relation/sequence | YES | YES | NO | CANONICAL AUTHORITY |
| family decision | state-only | YES | NO | LEGACY DECISION AUTHORITY RETIRED |
| public route | state-only | YES | NO | LEGACY DECISION AUTHORITY RETIRED |
| V121–V127 wrappers | historical implementation | diagnostic shadow only | NO | PRESERVED, NON-AUTHORITATIVE |

## Authority count

- Active semantic decision authority: **1 canonical state pipeline**.
- Legacy analyzers remain callable only to populate diagnostic `canonical_shadow.legacy` evidence.
- Canonical family, route and sequence results are assigned exclusively from canonical consumers.
- Structural mutation tests reject raw-text downstream parsing, legacy override, recomputed actor/reality, sequence reconstruction from family arrays, provenance loss, and canonical-producer bypass.

This is a development retirement result. It does not authorize production, Step 111, or sealed validation by itself.
