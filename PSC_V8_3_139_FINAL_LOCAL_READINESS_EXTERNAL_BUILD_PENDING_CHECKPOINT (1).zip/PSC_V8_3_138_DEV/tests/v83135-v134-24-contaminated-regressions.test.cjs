const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
process.env.PSC_V83135='1';
const core=require('./v83117-helper.cjs').loadCore();
const evidence=JSON.parse(fs.readFileSync('tests/V8_3_135_REAL600_24_FAILURE_FORENSIC_MATRIX.json','utf8'));

test('all 24 V8.3.134 contaminated real-case definitions preserve expected family on all four surfaces',()=>{
  assert.equal(evidence.matrix.length,24);
  let executions=0;
  for(const row of evidence.matrix)for(const [surface,input] of Object.entries(row.raw_input)){
    const result=core.analyze(input);executions++;
    assert.ok(result.families.includes(row.expected_primary_family),`${row.case_id}/${surface}: ${JSON.stringify(result.families)}`);
    assert.notEqual(result.input_route.id,'input:hypothetical-or-example',`${row.case_id}/${surface}`);
    const assumption=result.operator_occurrences.find(op=>/^(?:assume|gia dinh)$/.test(op.operator_lexeme));
    assert.ok(assumption,`${row.case_id}/${surface}: missing occurrence`);
    assert.equal(assumption.scope_type,'NONE',`${row.case_id}/${surface}`);
    assert.equal(assumption.governed_proposition_ids.length,0,`${row.case_id}/${surface}`);
  }
  assert.equal(executions,96);
});
