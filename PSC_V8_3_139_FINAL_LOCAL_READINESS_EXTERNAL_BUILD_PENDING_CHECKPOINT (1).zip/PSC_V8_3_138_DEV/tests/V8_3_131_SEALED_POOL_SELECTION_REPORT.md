# V8.3.131 Sealed Pool Selection Report

Status: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.

- Candidates generated: 100
- Candidates rejected/not selected: 40
- Final selected: 60
- Historical/adversarial/contrast/convergence items compared: 1699
- Runtime executions: 0

## Rejection distribution

```json
{
  "STRICT_PRIOR_SIMILARITY": 3,
  "DIVERSITY_SELECTION_SURPLUS": 37
}
```

## Coverage distribution

```json
{
  "public_route": {
    "input:hypothetical-or-example": 8,
    "input:third-party-only": 8,
    "input:self-lived": 32,
    "input:decision-request": 4,
    "input:prediction": 4,
    "input:clarification-required": 4
  },
  "internal_reality_status": {
    "hypothetical": 8,
    "current": 39,
    "future": 8,
    "unknown": 4,
    "reported_actual": 1
  },
  "actor_type": {
    "third_party": 19,
    "self": 36,
    "unknown": 4,
    "reported_actor": 1
  },
  "ownership": {
    "third_party": 20,
    "self": 36,
    "unknown": 4
  },
  "predicate_class": {
    "review": 28,
    "constraint": 3,
    "avoidance": 9,
    "decision": 4,
    "inability": 4,
    "decision_request": 4,
    "prediction": 4,
    "unknown": 4
  },
  "object_semantic_class": {
    "evidence": 28,
    "requirement": 3,
    "communication": 5,
    "decision_option": 12,
    "task": 4,
    "event": 4,
    "unknown": 4
  },
  "expected_family_set": {
    "NO_FAMILY": 35,
    "ignore": 5,
    "slow": 8,
    "fast": 4,
    "freeze": 4,
    "adaptive": 4
  },
  "polarity": {
    "positive": 52,
    "negative": 4,
    "unknown": 4
  },
  "negation_status": {
    "none": 52,
    "explicit": 4,
    "unknown": 4
  },
  "cessation_status": {
    "none": 56,
    "unknown": 4
  },
  "evidence_sufficiency": {
    "unknown": 40,
    "sufficient": 12,
    "insufficient": 8
  },
  "evidence_change": {
    "stable": 52,
    "increased": 4,
    "unknown": 4
  },
  "boundedness": {
    "bounded": 40,
    "unbounded": 16,
    "unknown": 4
  },
  "repetition": {
    "single": 48,
    "repeated": 8,
    "unknown": 4
  },
  "constraint_status": {
    "none": 49,
    "external": 3,
    "external_process": 4,
    "unknown": 4
  },
  "question_intent": {
    "none": 48,
    "decision_request": 4,
    "prediction": 4,
    "unknown": 4
  },
  "temporal_structure": {
    "single_phase": 56,
    "unknown": 4
  },
  "sequence_shape": {
    "atomic": 40,
    "constraint_only": 3,
    "repetition": 8,
    "bounded_review": 4,
    "unknown": 4,
    "attribution": 1
  },
  "clause_count": {
    "1": 59,
    "2": 1
  },
  "clause_relations": {
    "fictional-contained-proposition:graph-1": 1,
    "fictional-contained-proposition:graph-2": 1,
    "fictional-contained-proposition:graph-3": 1,
    "fictional-contained-proposition:graph-5": 1,
    "relational-agent-not-possessor:graph-1": 1,
    "relational-agent-not-possessor:graph-2": 1,
    "relational-agent-not-possessor:graph-3": 1,
    "relational-agent-not-possessor:graph-5": 1,
    "external-prevention-cause:graph-3": 1,
    "external-prevention-cause:graph-4": 1,
    "external-prevention-cause:graph-5": 1,
    "purpose-voluntary-avoidance:graph-1": 1,
    "purpose-voluntary-avoidance:graph-2": 1,
    "purpose-voluntary-avoidance:graph-3": 1,
    "purpose-voluntary-avoidance:graph-5": 1,
    "repeated-review-no-change:graph-1": 1,
    "repeated-review-no-change:graph-2": 1,
    "repeated-review-no-change:graph-3": 1,
    "repeated-review-no-change:graph-5": 1,
    "premature-before-review:graph-1": 1,
    "premature-before-review:graph-2": 1,
    "premature-before-review:graph-3": 1,
    "premature-before-review:graph-5": 1,
    "internal-inability-sufficient:graph-1": 1,
    "internal-inability-sufficient:graph-2": 1,
    "internal-inability-sufficient:graph-3": 1,
    "internal-inability-sufficient:graph-5": 1,
    "bounded-changed-review:graph-1": 1,
    "bounded-changed-review:graph-2": 1,
    "bounded-changed-review:graph-3": 1,
    "bounded-changed-review:graph-5": 1,
    "negated-avoidance-active-engagement:graph-2": 1,
    "decision-intent-route:graph-1": 1,
    "decision-intent-route:graph-2": 1,
    "decision-intent-route:graph-3": 1,
    "decision-intent-route:graph-5": 1,
    "prediction-intent-route:graph-1": 1,
    "prediction-intent-route:graph-2": 1,
    "prediction-intent-route:graph-3": 1,
    "prediction-intent-route:graph-5": 1,
    "underspecified-clarification:graph-1": 1,
    "underspecified-clarification:graph-2": 1,
    "underspecified-clarification:graph-3": 1,
    "underspecified-clarification:graph-5": 1,
    "fictional-contained-proposition:graph-4": 1,
    "conditional-unreal-agent:graph-2": 1,
    "conditional-unreal-agent:graph-3": 1,
    "conditional-unreal-agent:graph-5": 1,
    "relational-agent-not-possessor:graph-4": 1,
    "institutional-third-agent:graph-2": 1,
    "institutional-third-agent:graph-3": 1,
    "reported-third-agent:graph-5": 1,
    "negated-avoidance-active-engagement:graph-3": 1,
    "negated-avoidance-active-engagement:graph-1": 1,
    "negated-avoidance-active-engagement:graph-5": 1,
    "purpose-voluntary-avoidance:graph-4": 1,
    "repeated-review-no-change:graph-4": 1,
    "repeated-seek-sufficient:graph-2": 1,
    "repeated-seek-sufficient:graph-3": 1,
    "repeated-seek-sufficient:graph-5": 1
  },
  "language_surface": {
    "en": 16,
    "vi": 14,
    "vi-unaccented": 15,
    "vi-mixed": 15
  },
  "template_origin": {
    "v131-independent-fictional-contained-proposition-1": 1,
    "v131-independent-fictional-contained-proposition-2": 1,
    "v131-independent-fictional-contained-proposition-3": 1,
    "v131-independent-fictional-contained-proposition-5": 1,
    "v131-independent-relational-agent-not-possessor-1": 1,
    "v131-independent-relational-agent-not-possessor-2": 1,
    "v131-independent-relational-agent-not-possessor-3": 1,
    "v131-independent-relational-agent-not-possessor-5": 1,
    "v131-independent-external-prevention-cause-3": 1,
    "v131-independent-external-prevention-cause-4": 1,
    "v131-independent-external-prevention-cause-5": 1,
    "v131-independent-purpose-voluntary-avoidance-1": 1,
    "v131-independent-purpose-voluntary-avoidance-2": 1,
    "v131-independent-purpose-voluntary-avoidance-3": 1,
    "v131-independent-purpose-voluntary-avoidance-5": 1,
    "v131-independent-repeated-review-no-change-1": 1,
    "v131-independent-repeated-review-no-change-2": 1,
    "v131-independent-repeated-review-no-change-3": 1,
    "v131-independent-repeated-review-no-change-5": 1,
    "v131-independent-premature-before-review-1": 1,
    "v131-independent-premature-before-review-2": 1,
    "v131-independent-premature-before-review-3": 1,
    "v131-independent-premature-before-review-5": 1,
    "v131-independent-internal-inability-sufficient-1": 1,
    "v131-independent-internal-inability-sufficient-2": 1,
    "v131-independent-internal-inability-sufficient-3": 1,
    "v131-independent-internal-inability-sufficient-5": 1,
    "v131-independent-bounded-changed-review-1": 1,
    "v131-independent-bounded-changed-review-2": 1,
    "v131-independent-bounded-changed-review-3": 1,
    "v131-independent-bounded-changed-review-5": 1,
    "v131-independent-negated-avoidance-active-engagement-2": 1,
    "v131-independent-decision-intent-route-1": 1,
    "v131-independent-decision-intent-route-2": 1,
    "v131-independent-decision-intent-route-3": 1,
    "v131-independent-decision-intent-route-5": 1,
    "v131-independent-prediction-intent-route-1": 1,
    "v131-independent-prediction-intent-route-2": 1,
    "v131-independent-prediction-intent-route-3": 1,
    "v131-independent-prediction-intent-route-5": 1,
    "v131-independent-underspecified-clarification-1": 1,
    "v131-independent-underspecified-clarification-2": 1,
    "v131-independent-underspecified-clarification-3": 1,
    "v131-independent-underspecified-clarification-5": 1,
    "v131-independent-fictional-contained-proposition-4": 1,
    "v131-independent-conditional-unreal-agent-2": 1,
    "v131-independent-conditional-unreal-agent-3": 1,
    "v131-independent-conditional-unreal-agent-5": 1,
    "v131-independent-relational-agent-not-possessor-4": 1,
    "v131-independent-institutional-third-agent-2": 1,
    "v131-independent-institutional-third-agent-3": 1,
    "v131-independent-reported-third-agent-5": 1,
    "v131-independent-negated-avoidance-active-engagement-3": 1,
    "v131-independent-negated-avoidance-active-engagement-1": 1,
    "v131-independent-negated-avoidance-active-engagement-5": 1,
    "v131-independent-purpose-voluntary-avoidance-4": 1,
    "v131-independent-repeated-review-no-change-4": 1,
    "v131-independent-repeated-seek-sufficient-2": 1,
    "v131-independent-repeated-seek-sufficient-3": 1,
    "v131-independent-repeated-seek-sufficient-5": 1
  }
}
```

All selected cases retain provenance `HUMAN_AUTHORED_SEMANTIC_BRIEF`; deliberate stress variants were not eligible. Pair-level evidence is stored in `V8_3_131_CANDIDATE_BANK_AUDIT.json`.
