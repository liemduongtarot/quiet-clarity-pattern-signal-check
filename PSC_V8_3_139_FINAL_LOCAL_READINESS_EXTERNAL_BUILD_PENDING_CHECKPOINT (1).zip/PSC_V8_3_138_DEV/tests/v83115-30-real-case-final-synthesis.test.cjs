/* 15 real contexts plus 15 evidence-reversed counterparts, tested through final synthesis/state. */
/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm'),html=fs.readFileSync('public/candidate.html','utf8'),plan=JSON.parse(fs.readFileSync('tests/v83110-30-real-case-plan.json','utf8'));
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}},document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}},c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const signatures=plan.signatures,alias={perfectionism:'perfectionistic_overdrive',boundary_softening:'boundary_softening_under_interpersonal_pressure',ruminative_threat:'ruminative_threat_fusion',indecision:'indecision_overanalysis',over_responsibility:'over_responsibility_takeover',avoidance:'avoidance_of_discomfort',sunk_commitment:'sunk_commitment_inertia',attention_tunnel:'attention_tunnel_overinvestment',reactive_boundary:'reactive_boundary_escalation',uncertainty_control:'uncertainty_control_loop',premature_closure:'premature_closure_under_uncertainty'};
const results=[];
for(const p of plan.pairs){
 const route=signatures[p.mechanism],answers=Object.fromEntries('ABCDEFGH'.split('').map((F,i)=>[F,[F+route[i]]]));
 vm.runInContext(`S.area=${JSON.stringify(p.area)};S.sit=${JSON.stringify(p.primary_input)};S.clar=(uiClarityOptions()[0]||{}).id||'other';S.r=${JSON.stringify(answers)};S.i={rep:3,enact:3,interrupt:3,trend:3}`,c);
 const primary=vm.runInContext(`({syn:v2Synthesis(),res:QCResultV2.buildResult(v2Synthesis(),v2Frame(),S.i)})`,c),expected=alias[p.mechanism];
 const primaryPass=primary.syn.primary_mechanism!=='conflict'&&!!primary.syn.primary_mechanism&&['established_pattern','emerging_pattern'].includes(primary.res.state.signal_state)&&(primary.syn.primary_mechanism===expected||(primary.syn.components||[]).includes(expected)||(primary.syn.secondary_manifestations||[]).includes(expected));
 const adaptive=Object.fromEntries('ABCDEFGH'.split('').map(F=>[F,[F+'9']]));
 vm.runInContext(`S.area=${JSON.stringify(p.area)};S.sit=${JSON.stringify(p.inverse_input)};S.clar='adaptive:no-signal';S.r=${JSON.stringify(adaptive)};S.i={rep:0,enact:0,interrupt:0,trend:0}`,c);
 const inverse=vm.runInContext(`({syn:v2Synthesis(),res:QCResultV2.buildResult(v2Synthesis(),v2Frame(),S.i)})`,c),inversePass=inverse.res.state.signal_state==='adaptive';
 results.push({id:p.id,direction:'primary',mechanism:p.mechanism,resolved:primary.syn.primary_mechanism,state:primary.res.state.signal_state,pass:primaryPass},{id:p.id,direction:'inverse',mechanism:p.mechanism,resolved:inverse.syn.primary_mechanism,state:inverse.res.state.signal_state,pass:inversePass});
}
const passed=results.filter(x=>x.pass).length;
console.log(JSON.stringify({version:'V8.3.115',lockedAfterRun:true,total:results.length,passed,failed:results.length-passed,results},null,2));
if(passed!==results.length)process.exit(1);
