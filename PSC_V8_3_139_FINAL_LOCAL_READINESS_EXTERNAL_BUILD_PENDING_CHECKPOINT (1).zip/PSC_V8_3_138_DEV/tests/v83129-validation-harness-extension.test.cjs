const test=require('node:test'),assert=require('node:assert/strict');
const h=require('../scripts/v83129-validation-harness.cjs');
const semantic=overrides=>({public_route:'input:self-lived',internal_reality_status:'current',
  actor_type:'self',ownership:'self',predicate_class:'review',object_semantic_class:'evidence',
  expected_family_set:['slow'],polarity:'positive',negation_status:'none',
  cessation_status:'none',evidence_sufficiency:'sufficient',evidence_change:'stable',
  boundedness:'unbounded',repetition:'repeated',constraint_status:'none',
  question_intent:'none',temporal_structure:'single_phase',sequence_shape:'repetition',
  clause_count:1,clause_relations:['single'],language_surface:'en',...overrides});
const item=(id,raw,overrides={})=>({candidate_id:id,raw_input:raw,semantic:semantic(overrides),
  targets:{route:'input:self-lived',families:['slow'],sequence:false},
  template_origin:`brief-${id}`,generation_provenance:'TEST'});
test('V129 fingerprint includes object intent and relation facts',()=>{const fp=h.fingerprintOf(item('X1','I reviewed the record.'));for(const key of ['object_semantic_class','question_intent','clause_relations'])assert.ok(key in fp.fields);});
test('V129 fingerprint refuses a missing object class',()=>{const x=item('X1','I reviewed the record.');delete x.semantic.object_semantic_class;assert.throws(()=>h.materialize(x),/object_semantic_class/);});
test('V129 audit rejects identifier-only variants',()=>{const a=h.audit([item('X1','Dr Smith reviewed the record.'),item('X2','Dr Jones reviewed the record.')]);assert.ok(a.hard_duplicate_count>0);});
test('V129 fingerprint separates object semantic classes',()=>{const a=h.fingerprintOf(item('X1','I reviewed evidence.')).hash,b=h.fingerprintOf(item('X2','I reviewed a film.',{object_semantic_class:'entertainment'})).hash;assert.notEqual(a,b);});
