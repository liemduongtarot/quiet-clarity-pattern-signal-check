/* eslint-disable @typescript-eslint/no-require-imports */
const fs = require('fs');
const vm = require('vm');

const source = process.argv[2] || 'public/candidate.html';
const html = fs.readFileSync(source, 'utf8');
const plan = JSON.parse(fs.readFileSync('tests/v83110-30-real-case-plan.json', 'utf8'));
let js = html.match(/<script>([\s\S]*)<\/script>/i)[1]
  .replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/, '');
const el = { innerHTML: '', style: {}, dataset: {}, classList: { add() {}, remove() {} } };
const document = {
  body: { dataset: {}, setAttribute() {}, removeAttribute() {} },
  documentElement: { style: { setProperty() {} } },
  getElementById() { return el; },
  querySelectorAll() { return []; },
  createElement() { return { ...el, click() {} }; },
};
const c = { console, document, window: null, globalThis: null, navigator: {}, Blob() {}, URL: { createObjectURL() { return ''; }, revokeObjectURL() {} }, setTimeout, clearTimeout };
c.window = c;
c.globalThis = c;
c.scrollTo = () => {};
c.addEventListener = () => {};
vm.createContext(c);
new vm.Script(js).runInContext(c);

const expected = {
  '01': /tiêu chuẩn|chất lượng|sửa thêm/i,
  '02': /ba mẹ|công việc|công nhận/i,
  '03': /tiền|ngân sách|số dư|an toàn/i,
  '04': /liên lạc|chủ động|tương hỗ/i,
  '05': /trách nhiệm|nhận hết|phân chia/i,
  '06': /từ chối|giới hạn|thất vọng/i,
  '07': /quản lý|khối lượng việc|trao đổi/i,
  '08': /lòng tin|phản bội|dữ kiện/i,
  '09': /đầu tư|dự án|nguồn lực/i,
  '10': /ưu tiên|chú ý|nguồn lực/i,
  '11': /giới hạn|gia đình|bùng nổ/i,
  '12': /tài chính|bất định|rủi ro/i,
  '13': /mối quan hệ|kết luận|dữ kiện/i,
  '14': /hai công việc|đánh đổi|lựa chọn/i,
  '15': /tổn thương|người bạn|cuộc nói chuyện/i,
};
const generic = 'Điểm khó nhất với tôi nằm ở phản ứng mình thường làm ngay khi tình huống xuất hiện.';

const rows = [];
for (const pair of plan.pairs) {
  for (const inverse of [false, true]) {
    const input = inverse ? pair.inverse_input : pair.primary_input;
    vm.runInContext(`S.area=${JSON.stringify(pair.area)};S.sit=${JSON.stringify(input)};S.clar='';`, c);
    const invalid = vm.runInContext('bad(S.sit)', c);
    const options = invalid ? [] : vm.runInContext('uiClarityOptions()', c);
    const text = options.map(x => x.text).join(' ');
    const hasAdaptive = options.some(x => x.id === 'adaptive:no-signal' || /adaptive/.test(x.id));
    const pass = !invalid && options.length === 5 && expected[pair.id].test(text) && !text.startsWith(generic) && (!inverse || hasAdaptive);
    rows.push({ id: pair.id, inverse, input, invalid, pass, options });
  }
}

const validationProbe = 'Tôi thường chờ người kia nhắn trước và phân tích từng dấu hiệu quan tâm vì chưa dám quyết định mình có nên chủ động hay dừng lại.';
const validationPass = vm.runInContext(`bad(${JSON.stringify(validationProbe)})`, c) === null;
const passed = rows.filter(x => x.pass).length;
console.log(JSON.stringify({ source, total: rows.length, passed, failed: rows.length - passed, validationPass, rows }, null, 2));
if (passed !== rows.length || !validationPass) process.exit(1);
