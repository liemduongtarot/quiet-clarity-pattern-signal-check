const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'); const vm = require('node:vm');
function loadCore(){const sandbox={};vm.createContext(sandbox);for(const s of ['psc-v3.js','psc-v4.js','psc-v83121-r1-reconstructed.js','psc-v83122-operator-aware.js','psc-v83123-family-preservation.js','psc-v83124-operator-context.js','psc-v83125-semantic-routing.js','psc-v83126-public-route-canonicalization.js','psc-v83127-review-intent-authority.js','psc-v83129-canonical-shadow.js','psc-v83130-representation-coverage.js','psc-v83131-proposition-consolidation.js','psc-v83132-relation-graph.js','psc-v83133-canonical-role-binding.js','psc-v83135-scoped-operator.js','psc-v83138-semantic-convergence.js','psc-v83139-semantic-convergence.js'])vm.runInContext(fs.readFileSync('public/'+s,'utf8'),sandbox);return sandbox.QCSemanticCoreV10;}
const unaccent = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
const mixedAccent = (value) => value.split(/(\s+)/).map((part, index) => index % 4 === 0 ? unaccent(part) : part).join('');
const core=loadCore();

const patterns = [
  ['slow', 'Mỗi khi yêu cầu chưa rõ, tôi kiểm tra thêm và trì hoãn bắt đầu.', 'When requirements are unclear, I keep checking and delay getting started.'],
  ['slow', 'Tôi hỏi thêm nhiều người để được xác nhận rồi vẫn chuẩn bị thêm.', 'I ask several people for reassurance and still prepare further.'],
  ['fast', 'Khi phấn khích, tôi quyết ngay và nhận quá nhiều việc.', 'When excited, I decide immediately and take on too much.'],
  ['fast', 'Khi áp lực tăng, tôi hành động ngay và cam kết trước khi đủ điều kiện.', 'When pressure rises, I act immediately and commit before the conditions are sufficient.'],
  ['freeze', 'Tôi biết cần xử lý nhưng bị đứng lại và không bắt đầu được.', 'I know it needs dealing with, but I become stuck and cannot begin.'],
  ['freeze', 'Tôi không chọn được bước đầu tiên dù đã có vài lựa chọn hợp lý.', 'I cannot choose the first step despite having reasonable options.'],
  ['ignore', 'Tôi chuyển sang việc khác và giữ mình bận để né phần khó chịu.', 'I move to something else and keep busy to avoid the uncomfortable part.'],
  ['ignore', 'Tôi không mở phản hồi và làm như vấn đề không quan trọng.', 'I do not open the response and behave as though the issue does not matter.'],
  ['slow', 'Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.', 'I check for a long time and then eventually decide immediately because the deadline is close.'],
  ['freeze', 'Tôi đứng lại rồi sau đó chuyển sang né và không trả lời.', 'I become stuck and then avoid it and do not reply.'],
  ['freeze', 'Tôi chưa bắt đầu vì đang chờ phê duyệt và chưa có quyền quyết định.', 'I have not started because I am waiting for approval and do not have authority to decide.'],
  ['adaptive', 'Tôi kiểm tra vừa đủ, dừng khi đủ thông tin và điều chỉnh khi có dữ kiện mới.', 'I check enough, stop when I have enough information and adjust when new evidence appears.'],
];

const contexts = [
  ['Điều này đã xảy ra nhiều lần gần đây.', 'This has happened repeatedly recently.'],
  ['Nó ảnh hưởng rõ tới thời gian của tôi.', 'It clearly affects my time.'],
  ['Tôi nhận ra nó nhưng vẫn thường làm theo.', 'I notice it but still usually follow it.'],
  ['Chuyện này rõ hơn khi tôi mệt.', 'This is clearer when I am tired.'],
  ['Một khả năng xấu chiếm nhiều sự chú ý.', 'A negative possibility takes much of my attention.'],
  ['Tôi vẫn phân biệt được dữ kiện với điều mình sợ.', 'I can still distinguish evidence from what I fear.'],
  ['Nó ảnh hưởng cách tôi giao tiếp.', 'It affects how I communicate.'],
  ['Tôi có kỹ năng nhưng không phải lúc nào cũng có thời gian.', 'I have the skill but do not always have time.'],
  ['Không ai trực tiếp ép tôi chọn.', 'No one directly forces me to choose.'],
  ['Có cả cảm xúc và quyết định thực tế liên quan.', 'Both emotion and a practical decision are involved.'],
  ['Hậu quả rõ nhất là phần việc chưa hoàn tất.', 'The clearest consequence is that the task remains unfinished.'],
  ['Mức phản ứng thay đổi theo bối cảnh.', 'The strength changes with context.'],
  ['Tôi vẫn ngắt được phản ứng trong một số lần.', 'I can still interrupt the response sometimes.'],
  ['So với trước đây, phản ứng chưa đổi nhiều.', 'Compared with before, it has not changed much.'],
  ['Đây là một tình huống thật đang xảy ra.', 'This is a real situation happening now.'],
  ['Chuyện có một số ràng buộc thực tế.', 'The situation includes practical constraints.'],
  ['Tôi chưa biết đây là thói quen hay phản ứng nhất thời.', 'I do not know whether this is a habit or temporary.'],
  ['Nó có thể nhẹ đi khi yêu cầu rõ hơn.', 'It may ease when requirements become clearer.'],
  ['Tôi không muốn hệ thống giả định động cơ.', 'I do not want the system to assume a motive.'],
  ['Phản ứng này đi vào một quyết định cụ thể.', 'This response affects a specific decision.'],
  ['Tôi thấy nó quay lại ở nhiều hoàn cảnh tương tự.', 'I see it return in similar circumstances.'],
  ['Tôi thường thấy nhẹ đi ngay sau phản ứng.', 'I often feel immediate relief after the response.'],
  ['Sau đó vấn đề thực tế vẫn còn.', 'The practical issue remains afterwards.'],
  ['Tôi đang kiểm tra phản ứng của chính mình.', 'I am examining my own response.'],
  ['Tình huống liên quan tới nguồn lực thực tế.', 'The situation concerns practical resources.'],
];

const domains = ['work', 'business', 'money', 'romantic', 'family', 'friends', 'home', 'daily', 'wellbeing', 'direction', 'repeating', 'other'];

test('600 compositional real situations preserve response and language contracts', () => {
  let total = 0;
  const failures = [];
  patterns.forEach((pattern, patternIndex) => contexts.forEach((context, contextIndex) => {
    for (const variant of [0, 1]) {
      const domain = domains[(patternIndex + contextIndex + variant) % domains.length];
      const vi = `${pattern[1]} ${context[0]} ${variant ? 'Tôi đang nhìn cả hành vi lẫn điều kiện thực tế.' : ''}`;
      const en = `${pattern[2]} ${context[1]} ${variant ? 'I am considering both behaviour and the practical conditions.' : ''}`;
      const frames = [core.analyze(vi, domain), core.analyze(unaccent(vi), domain), core.analyze(mixedAccent(vi), domain), core.analyze(en, domain)];
      const expected = pattern[0];
      const primary = frames.map((frame) => frame.families[0] || 'unknown');
      const pass = expected === 'adaptive' ? primary.every((family) => family === 'adaptive') : primary.every((family) => family === expected);
      if (!pass) failures.push({ patternIndex, contextIndex, variant, expected, primary });
      total += 1;
    }
  }));
  assert.equal(total, 600);
  assert.deepEqual(failures, []);
});
