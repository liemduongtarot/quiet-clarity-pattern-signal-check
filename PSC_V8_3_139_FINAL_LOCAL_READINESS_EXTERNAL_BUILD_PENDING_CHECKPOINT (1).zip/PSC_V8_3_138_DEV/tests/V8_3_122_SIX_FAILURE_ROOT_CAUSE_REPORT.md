# V8.3.122 six-failure root-cause report

All six original prompts/contracts are unavailable; rows use surviving failure-family evidence and separately labelled replacement fixtures. No replacement is represented as original historical evidence.

| ID | Normalized proposition | Predicate/operator | Subject/source/scope | Temporal/negation/evidence | Historical expected vs failure | Leakage path | Architectural repair |
|---|---|---|---|---|---|---|---|
| PCH-A03 | self cannot decide despite sufficiency | `unable-to-decide` | self/direct | current; inability; sufficient | freeze; unaccented inability missed | surface tokens failed before predicate routing | fold surface, attach inability to decision predicate, then guard external impossibility |
| PCH-A04 | self repeatedly leaves item unengaged | `leave-unopened`/repetition | self/direct | repeated; not negated | ignore; compound predicate missed | auxiliary/phrasal construction never reached mechanism | normalize verb+object-state composition before family routing |
| PCH-A08 | director attributes third-party checking | attribution + `repeated-checking` | colleague; source=director; claim scope only | repeated; attributed | third-party/no self family; attribution scope lost | source noun or claim subject flattened | grammar captures arbitrary source phrase and preserves claim subject separately |
| PCH-A18 | leave unread → return to unchanged evidence → quick decision | `leave-unread`, `revisit-evidence`, `act-before-needed-evidence` | self/direct | three ordered phases | ignore→slow→fast; revisit/order lost | unordered family collection | temporal clause segmentation plus phase relations and return-to operator |
| PCH-A23 | NOT(avoid) plus one justified review | `bounded-review`; `NOT(avoid)` | self/direct | bounded; negated avoidance; missing detail | adaptive/no ignore; avoidance leaked or review became slow | nearby negative token applied after family activation | scoped negation before predicate activation; independent family evidence retained |
| PCH-A30 | “theo lời X” governs a third-party claim | attribution operator | third-party subject; source=X | attributed | third-party/no self family; Vietnamese scope lost | possessive `tôi` mistaken for self subject | `theo lời` grammar scopes claim and distinguishes possessor from behavioral subject |

Operator order is locked as reality → ownership → attribution → clause → negation → temporal → constraint → sufficiency → predicate → modifier → frequency → family → sequence → current evidence → classification.
