const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const source=fs.readFileSync(require.resolve('../scripts/v83134-validation-harness.cjs'),'utf8');
const required=[
 ['M01 case completeness','CASE_LEVEL_EVIDENCE_INCOMPLETE'],['M02 execution counter','execution_count_before!==0'],
 ['M03 rerun ledger','FIRST_RUN_INTEGRITY_VIOLATION'],['M04 source comparison',"['source','config','schema']"],
 ['M05 config comparison','config'],['M06 schema comparison','schema'],['M07 summary distrust','AGGREGATE_CASE_MISMATCH'],
 ['M08 manifest distrust','MANIFEST_CANNOT_OVERRIDE_UNDERLYING_EVIDENCE'],['M09 metadata excluded','FINGERPRINT_FIELDS'],
 ['M10 template origin excluded','normalizeTemplateRoot'],['M11 hidden template detector','hidden_template_skeleton_hash'],
 ['M12 diversity cannot bypass','top_three_share']
];
for(const[name,needle]of required)test(`${name} killed`,()=>assert(source.includes(needle)));
