const test = require('node:test');
const assert = require('node:assert/strict');
const harness = require('../scripts/v83131-validation-harness.cjs');

const semantic = (overrides = {}) => ({
  public_route: 'review', internal_reality_status: 'current', actor_type: 'self', ownership: 'self',
  predicate_class: 'evidence_review', object_semantic_class: 'evidence', expected_family_set: ['slow'], polarity: 'positive',
  negation_status: 'none', cessation_status: 'none', evidence_sufficiency: 'insufficient',
  evidence_change: 'stable', boundedness: 'bounded', repetition: 'single', constraint_status: 'none',
  temporal_structure: 'single_phase', sequence_shape: 'atomic', question_intent: 'what_to_do',
  clause_count: 1, clause_relations: ['single'], language_surface: 'en', ...overrides
});

const makeCase = (id, input, overrides = {}, extra = {}) => ({
  candidate_id: id, raw_input: input, targets: { route: 'review', families: ['slow'], sequence: false },
  semantic: semantic(overrides), ...extra
});

test('fingerprint requires every authoritative field', () => {
  const item = makeCase('T-1', 'I will review one record.');
  delete item.semantic.ownership;
  assert.throws(() => harness.materialize(item), /missing fingerprint fields: ownership/);
});

test('normalization detects punctuation and case duplicates', () => {
  const result = harness.audit([makeCase('T-1', 'Review ONE record!'), makeCase('T-2', 'review one record')]);
  assert(result.pairs.some(pair => pair.kind === 'NORMALIZED_DUPLICATE'));
  assert.equal(result.pass, false);
});

test('identifier stripping detects name-substitution duplicates', () => {
  const result = harness.audit([makeCase('T-1', 'Mr Smith will review one record.'), makeCase('T-2', 'Mr Jones will review one record.')]);
  assert(result.pairs.some(pair => pair.kind === 'IDENTIFIER_STRIPPED_DUPLICATE'));
});

test('fingerprint duplicate is independent of lexical surface', () => {
  const result = harness.audit([makeCase('T-1', 'Inspect the ledger.'), makeCase('T-2', 'Look through the evidence.')]);
  assert(result.pairs.some(pair => pair.kind === 'FINGERPRINT_DUPLICATE'));
});

test('lexical near duplicate threshold cannot be weakened', () => {
  assert.throws(() => harness.audit([], [], { nearThreshold: 0.81 }), /may not exceed/);
});

test('unreviewed near pair blocks acceptance', () => {
  const audit = { flagged_pairs: [{ kind: 'LEXICAL_NEAR_DUPLICATE', decision: 'UNREVIEWED', rationale: '' }] };
  assert.equal(harness.validatePairReview(audit).pass, false);
});

test('review decision needs explicit distinctness rationale', () => {
  const audit = { flagged_pairs: [{ kind: 'STRUCTURAL_OPERATOR_NEAR_DUPLICATE', decision: 'ACCEPT_DISTINCT', rationale: '' }] };
  assert.equal(harness.validatePairReview(audit).pass, false);
});

test('template-origin collision is visible', () => {
  const result = harness.audit([
    makeCase('T-1', 'First surface.', {}, { template_origin: 'template-7' }),
    makeCase('T-2', 'Second surface.', { language_surface: 'vi' }, { template_origin: 'template-7' })
  ]);
  assert(result.pairs.some(pair => pair.kind === 'TEMPLATE_ORIGIN_COLLISION'));
});

test('prior-corpus duplicates are classified separately', () => {
  const result = harness.audit([makeCase('NEW-1', 'A distinct claim.')], [makeCase('OLD-1', 'A distinct claim.')]);
  assert(result.pairs.some(pair => pair.kind === 'PRIOR_RAW_DUPLICATE'));
});

test('pair evidence preserves both raw forms, fingerprints, metric and decision', () => {
  const result = harness.audit([makeCase('T-1', 'Review one record!'), makeCase('T-2', 'review one record')]);
  const pair = result.pairs[0];
  for (const field of ['left_raw', 'right_raw', 'left_normalized', 'right_normalized', 'left_identifier_stripped', 'right_identifier_stripped', 'left_fingerprint', 'right_fingerprint', 'metric', 'decision', 'rationale']) assert(field in pair);
});

test('owner audit refuses incomplete pool and nonzero execution count', () => {
  const pass = { pass: true };
  const result = harness.preRunOwnerAudit({ harness_tests: pass, harness_mutations: pass, duplicate_audit: pass,
    contamination_audit: pass, pair_review: pass, diversity_audit: pass, pool: [], gold: [], execution_count: 1,
    locked_before_execution: false, hashes: {} });
  assert.equal(result.pass, false);
  assert(result.blockers.length >= 4);
});

test('pre-generation owner audit authorizes only a proven harness with no pool present', () => {
  const pass = { pass: true };
  assert.equal(harness.preGenerationOwnerAudit({ fingerprint_schema: pass, fixture_duplicate_audit: pass,
    fixture_contamination_audit: pass, harness_tests: pass, harness_mutations: pass,
    sealed_pool_exists: false, runtime_drift: false }).pass, true);
  assert.equal(harness.preGenerationOwnerAudit({ fingerprint_schema: pass, fixture_duplicate_audit: pass,
    fixture_contamination_audit: pass, harness_tests: pass, harness_mutations: pass,
    sealed_pool_exists: true, runtime_drift: false }).pass, false);
});

test('canonical fingerprint and hash are key-order stable', () => {
  const a = harness.fingerprintOf(makeCase('T-1', 'One.'));
  const b = harness.fingerprintOf(makeCase('T-2', 'Two.', Object.fromEntries(Object.entries(semantic()).reverse())));
  assert.equal(a.canonical, b.canonical);
  assert.equal(a.hash, b.hash);
});

test('diversity counts no-family and composite family outcomes as complete sets', () => {
  const none = makeCase('T-1', 'One.', { expected_family_set: [] });
  const composite = makeCase('T-2', 'Two.', { expected_family_set: ['slow', 'fast'], polarity: 'negative' });
  const report = harness.distribution([none, composite]);
  assert.equal(report.distribution.expected_family_set.NO_FAMILY, 1);
  assert.equal(report.distribution.expected_family_set['fast+slow'], 1);
});
