/* V8.3.116 boundary semantics: keep state/emotion separate from response family. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const standalone = fs.readFileSync('public/psc-v3.js', 'utf8').trim();
const html = fs.readFileSync('public/candidate.html', 'utf8');
const start = html.indexOf('(function(global){');
const endToken = "})(typeof globalThis!=='undefined'?globalThis:this);";
const end = html.indexOf(endToken, start) + endToken.length;
const inlined = html.slice(start, end).trim();
const sandbox = {};
vm.createContext(sandbox);
vm.runInContext(standalone, sandbox);
const core = sandbox.QCSemanticCoreV3;

test('candidate inline semantic core exactly matches the tested standalone source', () => {
  assert.equal(inlined, standalone);
});

test('emotion and state do not silently become response speed', () => {
  const cases = [
    ['Tôi buồn về chuyện gia đình này.', 'sad'],
    ['Tôi vui vì dự án đang tiến triển.', 'joy'],
    ['Tôi rất phấn khích về cơ hội mới.', 'excited'],
    ['Tôi đang quá tải trong công việc.', null],
    ['I feel sad about this family situation.', 'sad'],
    ['I feel excited about the new opportunity.', 'excited'],
    ['I feel overwhelmed at work.', null],
  ];
  for (const [raw, emotion] of cases) {
    const frame = core.analyze(raw, 'work');
    assert.equal(frame.response_known, false, raw);
    assert.equal(frame.needs_response_clarification, true, raw);
    assert.deepEqual([...frame.families], [], raw);
    if (emotion) assert.equal(frame.emotion[0].id, emotion, raw);
    const choices = core.clarificationOptions(frame);
    assert.equal(choices.length, 7, raw);
    assert.equal(choices.some((choice) => choice.id === 'v3:slow'), true, raw);
    assert.equal(choices.some((choice) => choice.id === 'v3:fast'), true, raw);
    assert.equal(choices.some((choice) => choice.id === 'v3:freeze'), true, raw);
    assert.equal(choices.some((choice) => choice.id === 'v3:ignore'), true, raw);
  }
});

test('opposed response families stay distinct and sequences retain both families', () => {
  const slow = core.analyze('Tôi cứ kiểm tra thêm và trì hoãn bắt đầu.', 'work');
  const fast = core.analyze('Tôi quyết ngay và nhận quá nhiều việc cùng lúc.', 'work');
  const freeze = core.analyze('Tôi bị đứng lại và không biết bắt đầu từ đâu.', 'work');
  const ignore = core.analyze('Tôi chuyển sang việc khác để né phần khó chịu.', 'work');
  const sequence = core.analyze('Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.', 'work');
  assert.deepEqual([...slow.families], ['slow']);
  assert.deepEqual([...fast.families], ['fast']);
  assert.deepEqual([...freeze.families], ['freeze']);
  assert.deepEqual([...ignore.families], ['ignore']);
  assert.equal(sequence.sequence, true);
  assert.equal(sequence.oscillation, true);
  assert.deepEqual(new Set(sequence.families), new Set(['slow', 'fast']));
});

test('external constraints, adaptive responses and weak current evidence do not become established patterns', () => {
  const constrained = core.analyze('Tôi không bắt đầu vì đang chờ phê duyệt và chưa có quyền quyết định.', 'work');
  assert.equal(core.evaluate(constrained, {
    family: 'freeze', clarification: 'v3:freeze', answers: {}, reinforcement: null,
    repetition: -1, enactment: -1, interruptibility: -1, trend: -1,
  }).classification, 'external_or_capacity_constraint');

  const adaptive = core.analyze('Toi xem lai vua du, dung khi da du thong tin va dieu chinh khi co du kien moi.', 'work');
  assert.equal(adaptive.language, 'vi');
  assert.equal(core.evaluate(adaptive, { family: 'adaptive', clarification: 'v3:adaptive' }).classification, 'adaptive');

  const slow = core.analyze('I keep checking and delay getting started.', 'work');
  assert.equal(core.evaluate(slow, {
    family: 'slow', clarification: 'v3:slow', answers: { A: ['v3:A:slow:1'] },
    reinforcement: null, repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
  }).classification, 'situational_or_unreinforced');
  assert.equal(core.evaluate(slow, {
    family: 'slow', clarification: 'v3:slow', answers: { E: ['v3:E:slow:1'] },
    reinforcement: 'v3:E:slow:1', repetition: -1, enactment: -1, interruptibility: -1, trend: -1,
  }).classification, 'current_status_insufficient');
});
