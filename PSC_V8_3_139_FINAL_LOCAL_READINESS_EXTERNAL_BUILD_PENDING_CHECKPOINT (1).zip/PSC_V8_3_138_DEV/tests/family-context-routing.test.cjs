/* eslint-disable @typescript-eslint/no-require-imports */
const fs = require('fs');
const vm = require('vm');

const source = process.argv[2] || 'public/candidate.html';
const html = fs.readFileSync(source, 'utf8');
let js = html.match(/<script>([\s\S]*)<\/script>/i)[1]
  .replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/, '');
const el = { innerHTML: '', style: {}, dataset: {}, classList: { add() {}, remove() {} } };
const document = {
  body: { dataset: {}, setAttribute() {}, removeAttribute() {} },
  getElementById() { return el; },
  querySelectorAll() { return []; },
  createElement() { return { ...el, click() {} }; },
};
const c = { console, document, window: null, globalThis: null, navigator: {}, Blob() {}, URL: { createObjectURL() { return ''; }, revokeObjectURL() {} }, setTimeout, clearTimeout };
c.window = c;
c.globalThis = c;
c.scrollTo = () => {};
c.addEventListener = () => {};
vm.createContext(c);
new vm.Script(js).runInContext(c);

const positives = [
  'Tôi thường khó chịu khi ba mẹ ko hiểu công việc mình đang làm.',
  'Tôi khó chịu vì ba mẹ không hiểu công việc của tôi.',
  'Bố mẹ chưa hiểu nghề tôi đang theo đuổi.',
  'Cha mẹ không hiểu hướng đi công việc của tôi.',
  'Gia đình không hiểu business tôi đang làm.',
  'Người nhà hiểu sai dự án tôi đang làm.',
  'Ba mẹ không công nhận công việc của tôi.',
  'Bố mẹ không ủng hộ nghề tôi đã chọn.',
  'Gia đình đánh giá hướng đi nghề nghiệp của tôi.',
  'Tôi bực khi người nhà chẳng hiểu việc mình làm.',
  'Ba mẹ ko hiểu dự án này của tôi.',
  'Cha mẹ chưa hiểu business của tôi.'
];

const mustMention = /ba mẹ|công việc|hướng đi|chia sẻ/;
const genericLead = 'Điểm khó nhất với tôi nằm ở phản ứng mình thường làm ngay khi tình huống xuất hiện.';
const results = positives.map(input => {
  vm.runInContext(`S.area='family';S.sit=${JSON.stringify(input)};S.clar='';`, c);
  const options = vm.runInContext('uiClarityOptions()', c);
  const text = options.map(x => x.text).join(' ');
  return { input, pass: options.length === 5 && mustMention.test(text) && !text.includes(genericLead), options };
});

const passed = results.filter(x => x.pass).length;
console.log(JSON.stringify({ source, total: results.length, passed, failed: results.length - passed, results }, null, 2));
if (passed !== results.length) process.exit(1);
