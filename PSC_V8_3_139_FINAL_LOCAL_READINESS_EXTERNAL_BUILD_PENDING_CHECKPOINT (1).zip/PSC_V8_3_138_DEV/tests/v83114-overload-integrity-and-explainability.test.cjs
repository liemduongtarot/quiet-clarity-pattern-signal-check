/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm'),html=fs.readFileSync('public/candidate.html','utf8');
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}},document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}},c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const input='Dạo gần đây công việc của tôi thay đổi liên tục nên tôi thường cảm thấy quá tải, nhưng tôi chưa rõ cảm giác đó đang khiến mình phản ứng như thế nào.';
vm.runInContext(`S.area='work';S.sit=${JSON.stringify(input)};S.clar='hyp:avoidance';`,c);
const options=vm.runInContext(`Object.fromEntries(['A','B','C','D','E','F','G','H'].map(F=>[F,questionOptions(F).map(tp)]))`,c),flat=Object.values(options).flat().join(' ');
const optionIntegrity=!flat.includes('cảm giác công việc hoặc kết quả vẫn chưa đủ để dừng')&&!flat.includes('trong chuyện này')&&options.A[6].includes('cảm giác quá tải')&&options.A[9].includes('quá tải')&&options.E[6].includes('cảm giác quá tải');
vm.runInContext(`S.r={A:['A1'],B:['B1'],C:['C1'],D:['D1'],E:['E1'],F:['F1'],G:['G1'],H:['H1']}`,c);
const conflict=vm.runInContext('v2Synthesis()',c),conflictBody=vm.runInContext('conflictResultBody(v2Synthesis())',c),explainable=conflict.primary_mechanism==='conflict'&&conflictBody.includes('VÌ SAO CHƯA THỂ GỌI TÊN MỘT PATTERN')&&conflictBody.includes('quá tải')&&conflictBody.includes('công việc')&&(conflict.candidates||[]).some(x=>conflictBody.toLowerCase().includes(x.label.toLowerCase()));
vm.runInContext(`S.r={A:['A1'],B:['B9'],C:['C9'],D:['D1'],E:['E3'],F:['F9'],G:['G9'],H:['H9']}`,c);
const coherent=vm.runInContext('v2Synthesis()',c),coherentAvoidance=coherent.primary_mechanism==='avoidance_of_discomfort';
const causalComposition=conflict.composite===true&&conflict.primary_mechanism==='composite:ruminative_threat_fusion+avoidance_of_discomfort'&&conflict.mechanism_statement.includes('trì hoãn');
const checks={optionIntegrity,allFirstFormsCausalLoop:causalComposition,causalLoopIsExplainable:conflict.mechanism_statement.includes('khả năng xấu'),coherentAvoidance};const passed=Object.values(checks).filter(Boolean).length,total=Object.keys(checks).length;
console.log(JSON.stringify({version:'V8.3.114',total,passed,failed:total-passed,checks,conflictCandidates:(conflict.candidates||[]).map(x=>x.label),coherentMechanism:coherent.mechanism_statement},null,2));if(passed!==total)process.exit(1);
