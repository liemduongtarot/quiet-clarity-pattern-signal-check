# V8.3.110 — 30 Real-Case Discovery Audit

Status: DISCOVERY COMPLETE; V8.3.110 NOT ACCEPTED

## Scope

- 15 primary real-life cases, simple through multi-layer.
- 15 paired evidence-inverted cases preserving the same life contexts.
- Every counted execution used the rendered UI and advanced through the questionnaire to a real result screen.
- A browser-control timeout was not counted; case 05 was rerun from the beginning and completed.

## Primary cases

| ID | Topic | Expected route | Full-flow verdict | Finding |
|---|---|---|---|---|
| 01 | Work report | Perfectionism | PASS | Relevant clarification; clear pattern; work consequence. |
| 02 | Family/work misunderstanding | Recognition/boundary pressure | PASS | Dedicated family–work clarification and relevant result. |
| 03 | Money insecurity and insomnia | Ruminative threat | FAIL | Final pattern was correct, but clarification fell back to generic diagnostic copy. |
| 04 | Waiting for contact | Indecision/wait-contact | FAIL | Valid situation was rejected as a request for the tool to choose for the user. |
| 05 | Taking over employee work | Over-responsibility | PASS | Relevant clarification and work-linked consequence. |
| 06 | Saying yes to a friend | Boundary softening | FAIL | Clarification drifted to generic work/effort escalation instead of refusal, disappointment and interpersonal limits. |
| 07 | Avoiding workload conversation | Avoidance | FAIL | Final mechanism was correct, but clarification described generic indecision and did not preserve manager/workload confrontation. |
| 08 | Betrayal history and checking | Ruminative threat | PASS | Checking/trust context and final mechanism aligned. |
| 09 | Continued investment | Sunk commitment | PASS | Money/investment context preserved. |
| 10 | Urgent project narrowing attention | Attention tunnel | PASS | Specific clarification and work consequence. |
| 11 | Family pressure then outburst | Reactive boundary escalation | PASS | Relevant clarification and consequence. |
| 12 | Financial checking and backup plans | Uncertainty control | PASS | Specific clarification and money context. |
| 13 | Forcing relationship clarity | Premature closure | PASS | Relevant uncertainty/closure clarification and result. |
| 14 | Comparing two jobs after enough evidence | Indecision | FAIL | Final pattern was correct, but clarification remained generic. |
| 15 | Avoiding a difficult conversation with a friend | Avoidance | FAIL | Final mechanism was correct, but clarification described generic decision delay rather than hurt/confrontation. |

Primary full-flow result: 9 PASS / 6 FAIL.

## Inverted cases — first discovery run

- All 15 reached `KHÔNG THẤY PROBLEM SIGNAL RÕ` after adaptive Q1–Q8 evidence.
- This proves the final classifier did not force a problem signal from situation keywords alone.
- It does **not** yet prove the whole inverted flow, because the discovery runner selected clarification option 1 in both directions.
- Several inverted inputs still produced clarification sets whose leading options described the old maladaptive response; some sets were fully generic.
- Therefore no inverted case from this first discovery run is promoted to final acceptance evidence.

## Valid defects to fix by rule class

1. Validation false positive: a self-focused wait-contact/indecision situation containing “nên ... hay dừng lại” is misread as asking the tool to choose.
2. Missing contextual clarification coverage: money threat/insomnia, friend refusal pressure, workload confrontation, two-job indecision and friend hurt/confrontation.
3. Negation/transition handling in clarification: explicit adaptive statements such as “không còn”, “thay vì”, “tôi đã nói rõ”, “tôi dừng khi không còn phù hợp” must not be presented as if the old maladaptive response is current.
4. Test protocol correction: inverted cases must select the context-preserving adaptive/no-problem clarification option before Q1–Q8.

## Change-control consequence

- V8.3.110 remains a failed review candidate.
- No RC freeze or owner-approval request is permitted.
- After class-level fixes, the exact revised source must rerun all 30 cases from the beginning plus the previous regression suites.
