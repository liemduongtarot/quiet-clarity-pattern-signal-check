const assert = require('node:assert/strict');
const fs = require('node:fs');
const test = require('node:test');
const vm = require('node:vm');

process.env.PSC_V83135 = '1';
const { loadCore } = require('./v83117-helper.cjs');

const FAILED_BROWSER_CASE = 'Dù tin nhắn đặt lịch không còn thay đổi, tôi vẫn xem đi xem lại trước khi bắt đầu. Tôi không bao giờ muốn hệ thống giả định động cơ của tôi.';

function loadUiAuthority() {
  const sandbox = {};
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync('public/psc-v83137-ui-gate-authority.js', 'utf8'), sandbox);
  return sandbox.PSCUIAuthorityV83137;
}

test('V135-C008 retired Browser E2E failure is canonical continue with no UI gate', () => {
  const core = loadCore();
  const ui = loadUiAuthority();
  const frame = core.analyze(FAILED_BROWSER_CASE);
  const decision = ui.resolveSituationGate(core, FAILED_BROWSER_CASE, 'other');

  assert.equal(frame.input_route.id, 'input:self-lived');
  assert.equal(frame.input_route.action, 'continue');
  assert.equal(frame.operator_occurrences[0].operator_status, 'NEGATED_OPERATOR');
  assert.equal(frame.operator_occurrences[0].complement_type, 'NOMINAL_OBJECT');
  assert.equal(frame.operator_occurrences[0].scope_type, 'NONE');
  assert.equal(decision.authority, 'canonical-route');
  assert.equal(decision.gate, null);
});

test('legacy copy refinements cannot override canonical route authority', () => {
  const core = loadCore();
  const ui = loadUiAuthority();
  const selfInput = 'Tôi cứ kiểm tra lại email nhiều lần dù không có thông tin mới.';

  for (const legacyGate of ['empty', 'vague', 'timing', 'prediction', 'choice', 'other']) {
    const decision = ui.resolveSituationGate(core, selfInput, legacyGate);
    assert.equal(decision.route.action, 'continue');
    assert.equal(decision.gate, null);
  }
});

test('canonical redirect routes retain specific user-facing gate copy', () => {
  const core = loadCore();
  const ui = loadUiAuthority();

  assert.equal(ui.resolveSituationGate(core, 'Khi nào tôi mới có tiền?', 'timing').gate, 'timing');
  assert.equal(ui.resolveSituationGate(core, 'Tôi có nên nghỉ việc không?', 'choice').gate, 'choice');
  assert.equal(ui.resolveSituationGate(core, 'Giả sử tôi cứ kiểm tra lại email nhiều lần.', null).gate, 'hypothetical');
  assert.equal(ui.resolveSituationGate(core, 'Bạn tôi liên tục kiểm tra email.', null).gate, 'other');
});

test('candidate loads V137 after V135 and delegates situation gating once', () => {
  const html = fs.readFileSync('public/candidate.html', 'utf8');
  const parentIndex = html.indexOf('psc-v83135-scoped-operator.js');
  const repairIndex = html.indexOf('psc-v83137-ui-gate-authority.js');

  assert.ok(parentIndex >= 0);
  assert.ok(repairIndex > parentIndex);
  assert.match(html, /QCSemanticCoreV4=globalThis\.QCSemanticCoreV8/);
  assert.match(html, /PSCUIAuthorityV83137\.resolveSituationGate\(QCSemanticCoreV4,S\.sit,bad\(S\.sit\)\)/);
  assert.doesNotMatch(html, /let route=QCSemanticCoreV4\.inputRoute\(S\.sit\),k=bad\(S\.sit\)/);
});
