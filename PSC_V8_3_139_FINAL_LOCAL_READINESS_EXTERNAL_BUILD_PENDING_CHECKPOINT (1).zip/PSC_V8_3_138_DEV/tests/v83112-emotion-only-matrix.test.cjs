/* eslint-disable @typescript-eslint/no-require-imports */
const fs = require('fs');
const vm = require('vm');

const source = process.argv[2] || 'public/candidate.html';
const html = fs.readFileSync(source, 'utf8');
let js = html.match(/<script>([\s\S]*)<\/script>/i)[1]
  .replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/, '');
const el = { innerHTML: '', style: {}, dataset: {}, classList: { add() {}, remove() {} } };
const document = { body: { dataset: {}, setAttribute() {}, removeAttribute() {} }, documentElement: { style: { setProperty() {} } }, getElementById() { return el; }, querySelectorAll() { return []; }, createElement() { return { ...el, click() {} }; } };
const c = { console, document, window: null, globalThis: null, navigator: {}, Blob() {}, URL: { createObjectURL() { return ''; }, revokeObjectURL() {} }, setTimeout, clearTimeout };
c.window = c; c.globalThis = c; c.scrollTo = () => {}; c.addEventListener = () => {};
vm.createContext(c); new vm.Script(js).runInContext(c);

const domains = [
  ['work','công việc không suôn sẻ','công việc'],
  ['business','business không tiến triển','business'],
  ['money','tiền bạc không suôn sẻ','tiền bạc'],
  ['romantic','mối quan hệ tình cảm không ổn','mối quan hệ tình cảm'],
  ['friends','quan hệ bạn bè không ổn','quan hệ bạn bè'],
  ['family','chuyện gia đình không ổn','gia đình'],
  ['home','chuyện nhà ở không thuận lợi','chuyện nhà ở'],
  ['direction','hướng đi không rõ ràng','hướng đi']
];
const emotions = [
  ['bất lực','bất lực'],['vô vọng','vô vọng'],['lo lắng','lo lắng'],['khó chịu','khó chịu'],
  ['thất vọng','thất vọng'],['chán nản','chán nản'],['bối rối','bối rối'],['quá tải','quá tải']
];
const ascii = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D');
const fixtures = [];
for (const [area,event,domainText] of domains) for (const [emotion,label] of emotions) {
  const input = `Tôi thường cảm thấy ${emotion} khi ${event}.`;
  fixtures.push({area,input,label,domainText,variant:'accented'});
  fixtures.push({area,input:ascii(input),label,domainText,variant:'ascii'});
}

const generic='Điểm khó nhất với tôi nằm ở phản ứng mình thường làm ngay khi tình huống xuất hiện.';
const results=fixtures.map(f=>{
  vm.runInContext(`S.area=${JSON.stringify(f.area)};S.sit=${JSON.stringify(f.input)};S.clar='';`,c);
  const invalid=vm.runInContext('bad(S.sit)',c),options=invalid?[]:vm.runInContext('uiClarityOptions()',c),text=options.map(x=>x.text).join(' ');
  const labelAscii=ascii(f.label),domainAscii=ascii(f.domainText),textAscii=ascii(text);
  const pass=!invalid&&options.length===5&&textAscii.includes(labelAscii)&&textAscii.includes(domainAscii)&&!text.startsWith(generic)&&options.some(x=>x.id==='adaptive:no-signal');
  return{...f,invalid,pass,options};
});
const passed=results.filter(x=>x.pass).length;
console.log(JSON.stringify({source,total:results.length,passed,failed:results.length-passed,results},null,2));
if(passed!==results.length)process.exit(1);
