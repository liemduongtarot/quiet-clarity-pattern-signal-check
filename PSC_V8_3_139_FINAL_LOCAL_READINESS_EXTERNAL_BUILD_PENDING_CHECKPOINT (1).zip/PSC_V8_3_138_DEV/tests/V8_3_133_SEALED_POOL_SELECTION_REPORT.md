# V8.3.133 Sealed Pool Selection Report

Status: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.

- Candidates generated: 120
- Candidates rejected/not selected: 60
- Final selected: 60
- Historical/adversarial/contrast/convergence items compared: 2646
- Runtime executions: 0

## Rejection distribution

```json
{
  "PRIOR_LEXICAL_NEAR_DUPLICATE": 1,
  "LEXICAL_NEAR_DUPLICATE": 1,
  "DIVERSITY_SELECTION_SURPLUS": 58
}
```

## Coverage distribution

```json
{
  "public_route": {
    "input:third-party-only": 24,
    "input:self-lived": 36
  },
  "internal_reality_status": {
    "current": 60
  },
  "actor_type": {
    "third_party": 24,
    "self": 36
  },
  "ownership": {
    "third_party": 24,
    "self": 36
  },
  "predicate_class": {
    "review": 48,
    "constraint": 12
  },
  "object_semantic_class": {
    "evidence": 48,
    "requirement": 12
  },
  "expected_family_set": {
    "NO_FAMILY": 36,
    "slow": 24
  },
  "polarity": {
    "positive": 60
  },
  "negation_status": {
    "none": 60
  },
  "cessation_status": {
    "none": 60
  },
  "evidence_sufficiency": {
    "unknown": 36,
    "sufficient": 24
  },
  "evidence_change": {
    "stable": 60
  },
  "boundedness": {
    "bounded": 36,
    "unbounded": 24
  },
  "repetition": {
    "single": 36,
    "repeated": 24
  },
  "constraint_status": {
    "none": 48,
    "external": 12
  },
  "question_intent": {
    "none": 60
  },
  "temporal_structure": {
    "single_phase": 60
  },
  "sequence_shape": {
    "atomic": 24,
    "constraint_only": 12,
    "repetition": 24
  },
  "clause_count": {
    "1": 60
  },
  "clause_relations": {
    "subject-head-role:variant-1": 1,
    "subject-head-role:variant-5": 1,
    "passive-affected-owner:variant-1": 1,
    "predicate-iterative-morphology:variant-1": 1,
    "predicate-iterative-morphology:variant-6": 1,
    "subject-head-role:variant-2": 1,
    "subject-head-role:variant-6": 1,
    "passive-affected-owner:variant-2": 1,
    "predicate-iterative-morphology:variant-2": 1,
    "predicate-iterative-morphology:variant-10": 1,
    "subject-head-role:variant-3": 1,
    "subject-head-role:variant-10": 1,
    "passive-affected-owner:variant-3": 1,
    "predicate-iterative-morphology:variant-3": 1,
    "predicate-iterative-morphology:variant-11": 1,
    "subject-head-role:variant-4": 1,
    "subject-head-role:variant-11": 1,
    "passive-affected-owner:variant-4": 1,
    "predicate-iterative-morphology:variant-4": 1,
    "predicate-iterative-morphology:variant-12": 1,
    "subject-head-role:variant-7": 1,
    "subject-head-role:variant-12": 1,
    "passive-affected-owner:variant-5": 1,
    "predicate-iterative-morphology:variant-7": 1,
    "predicate-iterative-morphology:variant-15": 1,
    "subject-head-role:variant-8": 1,
    "subject-head-role:variant-15": 1,
    "passive-affected-owner:variant-6": 1,
    "predicate-iterative-morphology:variant-8": 1,
    "predicate-iterative-morphology:variant-17": 1,
    "subject-head-role:variant-9": 1,
    "subject-head-role:variant-17": 1,
    "passive-affected-owner:variant-7": 1,
    "predicate-iterative-morphology:variant-9": 1,
    "predicate-iterative-morphology:variant-18": 1,
    "subject-head-role:variant-13": 1,
    "subject-head-role:variant-18": 1,
    "passive-affected-owner:variant-9": 1,
    "predicate-iterative-morphology:variant-13": 1,
    "predicate-iterative-morphology:variant-20": 1,
    "subject-head-role:variant-14": 1,
    "subject-head-role:variant-20": 1,
    "passive-affected-owner:variant-10": 1,
    "predicate-iterative-morphology:variant-14": 1,
    "predicate-iterative-morphology:variant-21": 1,
    "subject-head-role:variant-16": 1,
    "subject-head-role:variant-23": 1,
    "passive-affected-owner:variant-11": 1,
    "predicate-iterative-morphology:variant-16": 1,
    "predicate-iterative-morphology:variant-22": 1,
    "subject-head-role:variant-19": 1,
    "subject-head-role:variant-24": 1,
    "passive-affected-owner:variant-12": 1,
    "predicate-iterative-morphology:variant-19": 1,
    "predicate-iterative-morphology:variant-23": 1,
    "subject-head-role:variant-21": 1,
    "subject-head-role:variant-25": 1,
    "passive-affected-owner:variant-13": 1,
    "predicate-iterative-morphology:variant-26": 1,
    "predicate-iterative-morphology:variant-24": 1
  },
  "language_surface": {
    "en": 36,
    "vi-mixed": 24
  },
  "template_origin": {
    "v133-subject-head-role-1": 1,
    "v133-subject-head-role-5": 1,
    "v133-passive-affected-owner-1": 1,
    "v133-predicate-iterative-morphology-1": 1,
    "v133-predicate-iterative-morphology-6": 1,
    "v133-subject-head-role-2": 1,
    "v133-subject-head-role-6": 1,
    "v133-passive-affected-owner-2": 1,
    "v133-predicate-iterative-morphology-2": 1,
    "v133-predicate-iterative-morphology-10": 1,
    "v133-subject-head-role-3": 1,
    "v133-subject-head-role-10": 1,
    "v133-passive-affected-owner-3": 1,
    "v133-predicate-iterative-morphology-3": 1,
    "v133-predicate-iterative-morphology-11": 1,
    "v133-subject-head-role-4": 1,
    "v133-subject-head-role-11": 1,
    "v133-passive-affected-owner-4": 1,
    "v133-predicate-iterative-morphology-4": 1,
    "v133-predicate-iterative-morphology-12": 1,
    "v133-subject-head-role-7": 1,
    "v133-subject-head-role-12": 1,
    "v133-passive-affected-owner-5": 1,
    "v133-predicate-iterative-morphology-7": 1,
    "v133-predicate-iterative-morphology-15": 1,
    "v133-subject-head-role-8": 1,
    "v133-subject-head-role-15": 1,
    "v133-passive-affected-owner-6": 1,
    "v133-predicate-iterative-morphology-8": 1,
    "v133-predicate-iterative-morphology-17": 1,
    "v133-subject-head-role-9": 1,
    "v133-subject-head-role-17": 1,
    "v133-passive-affected-owner-7": 1,
    "v133-predicate-iterative-morphology-9": 1,
    "v133-predicate-iterative-morphology-18": 1,
    "v133-subject-head-role-13": 1,
    "v133-subject-head-role-18": 1,
    "v133-passive-affected-owner-9": 1,
    "v133-predicate-iterative-morphology-13": 1,
    "v133-predicate-iterative-morphology-20": 1,
    "v133-subject-head-role-14": 1,
    "v133-subject-head-role-20": 1,
    "v133-passive-affected-owner-10": 1,
    "v133-predicate-iterative-morphology-14": 1,
    "v133-predicate-iterative-morphology-21": 1,
    "v133-subject-head-role-16": 1,
    "v133-subject-head-role-23": 1,
    "v133-passive-affected-owner-11": 1,
    "v133-predicate-iterative-morphology-16": 1,
    "v133-predicate-iterative-morphology-22": 1,
    "v133-subject-head-role-19": 1,
    "v133-subject-head-role-24": 1,
    "v133-passive-affected-owner-12": 1,
    "v133-predicate-iterative-morphology-19": 1,
    "v133-predicate-iterative-morphology-23": 1,
    "v133-subject-head-role-21": 1,
    "v133-subject-head-role-25": 1,
    "v133-passive-affected-owner-13": 1,
    "v133-predicate-iterative-morphology-26": 1,
    "v133-predicate-iterative-morphology-24": 1
  }
}
```

All selected cases retain provenance `HUMAN_AUTHORED_SEMANTIC_BRIEF`; deliberate stress variants were not eligible. Pair-level evidence is stored in `V8_3_133_CANDIDATE_BANK_AUDIT.json`.
