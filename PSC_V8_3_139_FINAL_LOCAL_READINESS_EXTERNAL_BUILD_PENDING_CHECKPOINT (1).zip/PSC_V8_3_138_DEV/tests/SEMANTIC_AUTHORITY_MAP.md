# Semantic Authority Map — V8.3.127 Runtime Used by V8.3.128

Current architecture is a wrapper stack. Each version captures `parent`, calls `parent.analyze(raw)` and/or `parent.semanticNormalize(raw)`, then frequently reparses `raw`. The final `semantic_representation` is therefore an accumulation of partially overwritten and appended representations, not one immutable canonical state.

| Fact | Nominal producer(s) | Downstream consumers | Downstream recomputes? | Duplicate authority | Risk |
|---|---|---|---|---|---|
| actor | V121 ownership; V122 attribution/phase subject; V123 actor; V124 `third`; V125 `routeFacts` | family suppression, route, V126 canonical route | Yes | YES | Open-class subjects become self/default; authorities can disagree |
| ownership | V121 ownership; V124 proposition ownership; V125 route assertion | eligibility, suppression, V126 route | Yes | YES | Third-party evidence can activate self family or route |
| reality | V123 hypothetical; V124 `reality()`; V125 nonreal route facts | suppression, V124 route, V126 canonical route | Yes | YES | Non-real frame can be lost when only one phrase list misses |
| polarity | V123 proposition default + negated ignore; V124 candidate governance | family eligibility | Yes | YES | Predicate-scoped negation is reduced to regex proximity |
| negation | V121 phase; V122 routePredicate; V123 extract; V124 candidates; V125 negatedAvoid | suppression and family filters | Yes | YES | A negated predicate may be removed by one layer but reintroduced by another |
| cessation | V121 phase; V122; V123; V124 | proposition suppression, sequence | Yes | YES | Current/historical status can be flattened or applied to whole clause |
| predicate | V121 predicate rows; V122 routePredicate; V123 extract; V124 candidates; V125 primary/review; V127 reviewFacts | family candidacy and output | Yes | YES | Largest observed failure source; inconsistent verb/object coverage |
| evidence sufficiency | V121, V122 global context, V123 phase state, V124 candidates, V125 reviewFacts, V127 reviewFacts | slow/adaptive qualification | Yes | YES | Same text can have separate sufficiency decisions |
| evidence change | V121, V122, V123, V124, V125, V127 | adaptive qualification | Yes | YES | Later authoritative review can replace parent family based on another parse |
| boundedness | V121, V122, V123, V124, V125, V127 | slow/adaptive qualification | Yes | YES | Count/duration/completion do not share one scope or vocabulary |
| frequency | V121, V122, V123, V124, V125, V127 | slow candidacy, sequence | Yes | YES | Numeric and natural frequency forms are inconsistently represented |
| question intent | V127 `intentFrame`; legacy/base `inputRoute` | V127 routeFor, V126 canonical route | Generic route remains competing fallback | YES | Clear questions can fall through to self-lived |
| family eligibility | V123 active propositions; V124 govern; V125 qualification/primary; V127 review authority | final families, blocked route filtering | Yes | YES | Later filters/additions can bypass earlier eligibility rationale |
| sequence phase | V121 split; V122 segment; V123 refine; V124 split; V125 sequenceFamilies | final sequence in every analyze wrapper | Yes | YES | Phase survives only if a current layer recognizes connector and active predicate |
| public route | base/V121/V122 inputRoute; V124 routeOf; V125 route override; V126 canonicalPublicRoute; V127 routeFor | final blocking/evaluation | Yes | YES | Route is repeatedly canonicalized from non-canonical or partial state |

## Duplicate-authority finding

All 15 audited semantic facts have duplicate or competing production paths. Question intent is closest to a named final authority, but it still competes with inherited generic routing when its surface grammar returns false. `canonicalPublicRoute` canonicalizes enum values; it does not make the underlying actor/reality/intent facts canonical.
