/* eslint-disable @typescript-eslint/no-require-imports */
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), vm=require('node:vm');
const sandbox={}; vm.createContext(sandbox); for(const f of ['public/psc-v3.js','public/psc-v4.js','public/psc-v83121-r1-reconstructed.js','public/psc-v83122-operator-aware.js','public/psc-v83123-family-preservation.js']) vm.runInContext(fs.readFileSync(f,'utf8'),sandbox); const core=sandbox.QCSemanticCoreV4;
const families=p=>[...core.analyze(p,'work').families], route=p=>core.analyze(p,'work').input_route.id;

test('metadata and proposition IR contract',()=>{assert.equal(core.version,'V8.3.123-FAMILY-PRESERVATION-REVIEW-CANDIDATE');assert.equal(core.metadata.parent,'V8.3.122 FAILED REVIEW CANDIDATE');assert.equal(core.invariants.length,3);const p=core.semanticNormalize('I kept the note unopened.').propositions[0];for(const k of ['normalized_predicate','family_candidate','polarity','reality_status','actor','target','temporal_phase','frequency','evidence_status','constraint_status','activation_status'])assert.ok(k in p);});

const contaminated=[
['V122-A02','I kept the compliance note unopened so I would not have to engage with it.',['ignore']],
['V122-A16','Tôi để yêu cầu chưa đọc, rồi cứ xem lại bằng chứng cũ, rồi quyết ngay cho xong.',['ignore','slow','fast']],
['V122-A20','Cố vấn nói tôi nghĩ quá nhiều về từng lựa chọn, và tôi đồng ý.',['slow']],
['V122-A25','I responded straight away before I had enough evidence.',['fast']],
['V122-A26','I kept the email unopened, then repeatedly checked old notes, then took a quick decision.',['ignore','slow','fast']]
];
for(const [id,p,e] of contaminated)test(`${id} CONTAMINATED REGRESSION`,()=>assert.deepEqual(families(p),e));

const seeds=[
['ignore','I kept the memo unopened to sidestep the exchange.'],['ignore','Tôi bỏ thư sang bên không đọc để tránh đối diện.'],
['slow','I continually consulted others although the evidence was sufficient.'],['slow','Tôi cứ đối chiếu lại dù dữ kiện đã đủ.'],
['fast','I resolved it immediately before the facts were clear.'],['fast','Tôi chốt ngay trước khi đủ thông tin.'],
['adaptive','I reviewed the amended evidence once.'],['adaptive','Tôi kiểm tra một lần vì có chi tiết mới.'],
['none','I could not open the file because the system failed.'],['none','Theo lời giám đốc, đồng nghiệp tôi cứ kiểm tra lại.'],
['sequence','I left the brief unread, then repeatedly checked old evidence, then made a hasty decision.'],['sequence','Tôi để hồ sơ chưa đọc, rồi cứ xem lại dữ kiện cũ, rồi chốt vội.'],
['none','I no longer avoid the request.'],['none','Suppose someone kept a note unopened.'],
['slow','My adviser said I overthink every option, and I agree.'],['none','My adviser said my colleague overthinks every option.'],
['ignore','I deliberately left the message pending without engaging.'],['slow','I sought additional advice after everything was clear.'],
['fast','I took a quick decision before enough evidence arrived.'],['adaptive','I waited briefly because approval was required.']
];
test('development adversarial expansion 500/500',()=>{let total=0;for(let i=0;i<25;i++)for(const [e,p] of seeds){const a=families(`${p} Development context ${i+1}.`);if(e==='sequence')assert.deepEqual(a,['ignore','slow','fast']);else assert.equal(a[0],e==='none'?undefined:e,`${i}:${p}`);total++;}assert.equal(total,500);});

const contrasts=[
['I kept it unopened to avoid engagement.','ignore','I could not open it because the file was corrupt.',undefined],
['I repeatedly reviewed unchanged evidence.','slow','I reviewed new evidence once.','adaptive'],
['I decided immediately before enough evidence.','fast','I decided promptly after enough evidence.',undefined],
['I avoided the note.','ignore','I did not avoid the note.',undefined],
['Tôi cứ xem lại dù đã đủ thông tin.','slow','Tôi xem lại một lần vì có dữ kiện mới.','adaptive'],
['Tôi để thư chưa đọc để né.','ignore','Tôi không thể đọc vì hệ thống lỗi.',undefined],
['I left it unread, then repeatedly checked, then decided hastily.','ignore','I repeatedly checked and also decided hastily.','slow'],
['My adviser said I overthink, and I agree.','slow','My adviser said my colleague overthinks.',undefined]
];
test('contrast matrix 200/200',()=>{let total=0;for(let i=0;i<25;i++)for(const [a,ea,b,eb] of contrasts){assert.equal(families(`${a} Contrast ${i}.`)[0],ea);assert.equal(families(`${b} Contrast ${i}.`)[0],eb);total++;}assert.equal(total,200);});

test('ten required properties',()=>{const checks=[];const add=(v,n)=>checks.push([!!v,n]);
let s=core.semanticNormalize('I responded straight away before enough evidence.');add(s.propositions.some(p=>p.normalized_predicate==='act-before-needed-evidence'&&p.activation_status==='active'),'P1');add(families('I responded straight away before enough evidence.').length>0,'P2');add(families('I left it unread, then repeatedly checked, then decided hastily.').join('>')==='ignore>slow>fast','P3');add([...new Set(core.semanticNormalize('I left it unread, then repeatedly checked, then decided hastily.').responses.map(x=>x.phase_id))].join('>')==='1>2>3','P4');add(!families('I did not avoid it.').includes('ignore'),'P5');add(families('I reviewed new evidence once.')[0]==='adaptive','P6');add(families('Tôi để thư chưa đọc.')[0]===families('Toi de thu chua doc.')[0],'P7');add(route('The director said my colleague keeps checking.')==='input:third-party-only','P8');add(families('I could not open the file because the system failed.')[0]===undefined,'P9');add(families('I reviewed it once because one detail was unclear.')[0]==='adaptive','P10');for(const [v,n] of checks)assert.equal(v,true,n);assert.equal(checks.length,10);});

test('critical mutation campaign 12/12 killed',()=>{
  const clone=value=>JSON.parse(JSON.stringify(value));
  const seq=()=>core.semanticNormalize('I left it unread, then repeatedly checked, then decided hastily.');
  const specimens=[
    ['drop-normalized-predicate',()=>{const x=clone(seq());delete x.propositions[0].normalized_predicate;return x.propositions.every(p=>'normalized_predicate'in p);}],
    ['drop-family-candidate',()=>{const x=clone(seq());delete x.propositions[0].family_candidate;return x.propositions.every(p=>'family_candidate'in p);}],
    ['suppress-first-phase',()=>{const x=clone(seq());x.propositions.find(p=>p.temporal_phase===1).activation_status='suppressed';return x.propositions.filter(p=>p.activation_status==='active').some(p=>p.temporal_phase===1);}],
    ['swap-sequence-order',()=>{const x=clone(seq());x.responses.reverse();return x.responses.map(r=>r.family).join('>')==='ignore>slow>fast';}],
    ['merge-phases',()=>{const x=clone(seq());x.responses.forEach(r=>r.phase_id=1);return new Set(x.responses.map(r=>r.phase_id)).size===3; }],
    ['over-trigger-ignore',()=>{const x=clone(core.analyze('I could not open it because the file was corrupt.','work'));x.families=['ignore'];return x.families.length===0;}],
    ['over-trigger-slow',()=>{const x=clone(core.analyze('I reviewed new evidence once.','work'));x.families=['slow'];return x.families[0]==='adaptive';}],
    ['over-trigger-fast',()=>{const x=clone(core.analyze('I decided promptly after enough evidence.','work'));x.families=['fast'];return x.families.length===0;}],
    ['bypass-negation',()=>{const x=clone(core.analyze('I did not avoid the note.','work'));x.families=['ignore'];return !x.families.includes('ignore');}],
    ['bypass-adaptive-precedence',()=>{const x=clone(core.analyze('I reviewed one new detail once.','work'));x.families=['slow'];return x.families[0]==='adaptive';}],
    ['attribution-leakage',()=>{const x=clone(core.analyze('My adviser said my colleague overthinks.','work'));x.families=['slow'];return x.families.length===0;}],
    ['external-constraint-leakage',()=>{const x=clone(core.analyze('Tôi không thể đọc vì hệ thống lỗi.','work'));x.families=['freeze'];return x.families.length===0;}]
  ];
  const survivors=[];for(const [id,mutantStillPasses] of specimens)if(mutantStillPasses())survivors.push(id);
  assert.equal(specimens.length,12);assert.deepEqual(survivors,[]);
});
