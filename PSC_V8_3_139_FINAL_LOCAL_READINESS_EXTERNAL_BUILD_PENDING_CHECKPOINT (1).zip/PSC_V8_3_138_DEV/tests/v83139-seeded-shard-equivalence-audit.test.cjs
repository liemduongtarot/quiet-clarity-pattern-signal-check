const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('node:fs');
const SEED=83117091; function stepState(value){value^=value<<13;value^=value>>>17;value^=value<<5;return value>>>0;}
function next(ctx){ctx.value=stepState(ctx.value); return ctx.value/4294967296;}
function advanceCase(ctx){next(ctx); const english=next(ctx)>0.75; next(ctx); if(!english && next(ctx)>0.66) next(ctx); next(ctx); next(ctx);}
const rows=fs.readFileSync('tests/V8_3_139_SEEDED_100K_SHARD_STATES.tsv','utf8').trim().split(/\n/).slice(1).map(line=>line.split(/\t/).map(Number));
test('20 exact 5k shards form one continuous canonical 100k RNG stream',()=>{assert.equal(rows.length,21); const ctx={value:SEED>>>0}; assert.deepEqual(rows[0],[0,ctx.value]); for(let block=0;block<20;block++){for(let i=0;i<5000;i++) advanceCase(ctx); assert.deepEqual(rows[block+1],[(block+1)*5000,ctx.value]);} assert.equal(ctx.value,917212366);});
