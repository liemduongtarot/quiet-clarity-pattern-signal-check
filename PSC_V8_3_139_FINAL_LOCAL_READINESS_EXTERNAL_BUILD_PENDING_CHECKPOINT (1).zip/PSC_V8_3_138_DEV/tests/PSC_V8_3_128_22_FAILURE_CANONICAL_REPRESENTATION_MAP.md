# V8.3.128 — 22-Failure Canonical Representation Map

These sealed first-run failures are architecture probes only. No case was rerun and no exact-case rule is proposed. “Current” summarizes preserved output plus static first-divergence analysis; it is not a newly captured trace.

| Case | Canonical representation that should exist | Current architecture produced | Canonical field(s) preventing failure |
|---|---|---|---|
| V128-A01 | `P1(actor=archivist/third-party, predicate=compare, object=maps, reality=fictional)` with `BEFORE` temporal modifier | reality defaults actual; self-lived route | proposition-scoped `reality_status=fictional`, actor graph, `public_route_contribution` |
| V128-A03 | hypothetical frame scopes medic/postpone/appointment proposition | frame unrecognized; actual/self-lived | frame operator → `reality_status=hypothetical` and scoped proposition IDs |
| V128-A05 | example/fictional frame scopes third-party inability proposition | third-party actual route | `example_status=example`, `reality_status=fictional`, scoped operator |
| V128-A06 | supervisor is explicit third-party actor; withdrawal is separate evidence/constraint proposition with `AFTER` | actor unresolved/default self | `actor.actor_type`, `ownership`, proposition relation graph |
| V128-A08 | accountant third-party; avoidance predicate negative | actor defaults self | actor graph plus predicate-scoped `negation_scope` |
| V128-A09 | editor third-party; bounded review of changed citation evidence | self route and slow family | actor/ownership identity; boundedness; evidence change; family suppression |
| V128-A11 | `examine(assumption)` changed/bounded then `stop` after experiment end | predicate absent; sequence lost | compositional predicate/object class; cessation and THEN relation IDs |
| V128-A12 | bounded `compare(measurement, baseline)` with fresh evidence | no family proposition | predicate class comparison; evidence-change; boundedness |
| V128-A14 | evidence-change proposition BEFORE bounded `verify(calibration)` | verification proposition absent | predicate verification + object class evidence + AFTER relation |
| V128-A15 | bounded `inspect(exception)` with new evidence and deadline | object not reviewable | open object semantic class, predicate review, constraint/boundedness |
| V128-A17 | sufficient unchanged evidence BUT repeated `request-confirmation` | information-seeking missing | predicate composition (ask + confirmation), repetition, sufficiency |
| V128-A18 | repeated `rehearse(explanation)` after resolution/sufficiency | preparation predicate missing | preparation/rehearsal predicate class; evidence sufficiency |
| V128-A19 | `reopen(calculation)` repeated count=3 with unchanged/no-new evidence | predicate/frequency missing | review predicate, frequency `{kind:counted,count:3}`, evidence unchanged |
| V128-A20 | sufficient documented answer ALTHOUGH repeated comparison of same totals | comparison missing | comparison predicate; repetition; evidence sufficiency; ALTHOUGH relation |
| V128-A21 | deliberate avoidance expressed as archive(email, state=unread) BECAUSE avoid(address complaint) | avoidance missing | result-state composition, purpose relation, avoidance predicate |
| V128-A22 | `switch(task)` AND deliberate `leave(warning, unopened)` as two propositions | ignore family survives but phase relation absent | clause/proposition IDs and `AND` relation; sequence projection |
| V128-A24 | explanation-complete BEFORE inability/stuck proposition | freeze family survives but sequence absent | `AFTER` relation connecting proposition IDs |
| V128-A25 | accept explanation immediately while evidence insufficient | fast predicate missing | decision predicate; evidence insufficiency; temporal/bounded operator |
| V128-A26 | extended review THEN deadline constraint THEN rushed choice | only slow family; fast and sequence lost | three proposition IDs, THEN edges, decision/fast qualification |
| V128-A27 | question intent prediction targeting insurer issue-response proposition | generic self-lived route | `speech_act=question`, `question_intent=prediction`, target proposition |
| V128-A28 | modal future question targeting committee reverse-decision proposition | generic self-lived route | modal operator + `question_intent=prediction`, third-party actor |
| V128-A30 | wh-choice question targeting collective-self adopt-plan decision | generic self-lived route | `actor_type=collective-self`, `question_intent=decision-request` |

## Architectural coverage

- Reality/frame fields prevent 3 failures.
- Actor/ownership graph prevents 3.
- Compositional predicate/object/evidence state prevents 11.
- Proposition relation graph prevents 2 direct segmentation failures and preserves sequence in additional mixed cases.
- Canonical speech-act/intent prevents 3.

The map intentionally specifies semantic structures and fields, not phrases or regex additions.
