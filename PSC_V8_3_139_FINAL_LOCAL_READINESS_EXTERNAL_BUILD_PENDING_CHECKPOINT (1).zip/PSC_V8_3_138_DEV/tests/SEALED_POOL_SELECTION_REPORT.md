# V8.3.134 sealed pool selection report

Candidate bank: 189. Selected: 60. Rejected: 129.

Rejections were selection-capacity exclusions after duplicate, contamination, fingerprint and hidden-template audit; no rejected case was executed. Final roots: 27; largest root: 3; top-three share: 15.0%.

Final rationale: two cases from every taxonomy root plus one additional case from six roots, preserving multi-axis breadth without allowing a small root group to dominate.
