# V8.3.134 archive audit report

Status: **PASS**

- ZIP integrity: PASS
- Internal SHA256: PASS
- Required-file audit: PASS
- Archive: PSC_V8_3_134_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip
- SHA256: `7e9714383bd005b2b9337ba13a945fcc187c81f3db8666b5673fed4a27550bdd`
- External local download: NOT YET CONFIRMED
