const assert = require('node:assert/strict');
const fs = require('node:fs');
const test = require('node:test');
const vm = require('node:vm');

process.env.PSC_V83135 = '1';
const { loadCore, mixedAccent } = require('./v83117-helper.cjs');

function loadUiAuthority() {
  const sandbox = {};
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync('public/psc-v83137-ui-gate-authority.js', 'utf8'), sandbox);
  return sandbox.PSCUIAuthorityV83137;
}

test('UI helper does not replace or wrap the frozen runtime authority', () => {
  const before = fs.readFileSync('public/psc-v83135-scoped-operator.js');
  const core = loadCore();
  const ui = loadUiAuthority();
  const after = fs.readFileSync('public/psc-v83135-scoped-operator.js');

  assert.equal(core.version, 'V8.3.135-SCOPED-OPERATOR');
  assert.equal(ui.metadata.runtime_semantics_changed, false);
  assert.equal(ui.metadata.parser_schema_changed, false);
  assert.equal(ui.metadata.expected_contracts_changed, false);
  assert.deepEqual(before, after);
});

test('canonical route controls every gate decision across fresh UI probes', () => {
  const core = loadCore();
  const ui = loadUiAuthority();
  const starts = ['Tôi cứ', 'Tôi vẫn', 'Mình thường', 'Tôi liên tục'];
  const behaviors = ['kiểm tra lại email', 'xem lại tài liệu', 'đối chiếu bản nháp', 'đọc đi đọc lại ghi chú'];
  const contexts = ['dù không có thông tin mới', 'dù nội dung không đổi', 'dù mọi dữ kiện vẫn như cũ'];
  const policies = [
    'Tôi không muốn hệ thống giả định động cơ của tôi.',
    'Đừng để công cụ suy đoán ý định của tôi.',
    'Hệ thống không được coi cảm xúc là nguyên nhân.'
  ];

  let probeCount = 0;
  for (const start of starts) {
    for (const behavior of behaviors) {
      for (const context of contexts) {
        for (const policy of policies) {
          const input = `${start} ${behavior} nhiều lần ${context}. ${policy}`;
          for (const variant of [input, mixedAccent(input)]) {
            const route = core.inputRoute(variant);
            const decision = ui.resolveSituationGate(core, variant, 'other');
            assert.equal(route.id, 'input:self-lived', variant);
            assert.equal(route.action, 'continue', variant);
            assert.equal(decision.route.id, route.id, variant);
            assert.equal(decision.gate, null, variant);
            probeCount += 1;
          }
        }
      }
    }
  }

  assert.equal(probeCount, 288);
});

test('redirect and clarify routes remain governed by unchanged canonical runtime', () => {
  const core = loadCore();
  const ui = loadUiAuthority();
  const rows = [
    ['Khi nào tôi mới có tiền?', 'timing', 'input:prediction', 'timing'],
    ['Tôi có nên nghỉ việc không?', 'choice', 'input:decision-request', 'choice'],
    ['Giả sử tôi cứ kiểm tra lại email nhiều lần.', null, 'input:hypothetical-or-example', 'hypothetical'],
    ['Bạn tôi liên tục kiểm tra email.', null, 'input:third-party-only', 'other']
  ];

  for (const [input, legacyGate, routeId, gate] of rows) {
    const routeBefore = core.inputRoute(input);
    const decision = ui.resolveSituationGate(core, input, legacyGate);
    const routeAfter = core.inputRoute(input);

    assert.equal(routeBefore.id, routeId, input);
    assert.equal(decision.route.id, routeId, input);
    assert.equal(decision.gate, gate, input);
    assert.deepEqual(JSON.parse(JSON.stringify(routeAfter)), JSON.parse(JSON.stringify(routeBefore)), input);
  }
});

