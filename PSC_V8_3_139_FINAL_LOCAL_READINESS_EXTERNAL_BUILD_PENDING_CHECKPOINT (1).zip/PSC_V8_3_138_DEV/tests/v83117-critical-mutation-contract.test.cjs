const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { loadCore } = require('./v83117-helper.cjs');
const core = loadCore();
const lock = JSON.parse(fs.readFileSync('tests/V8_3_117_CRITICAL_MUTATIONS_LOCK.json', 'utf8'));

// Runtime mutation operators alter the public semantic boundary. The oracle is
// deliberately independent: it asserts governance contracts, never display text.
const mutations = {
  emotion_becomes_response_family: (api) => ({ ...api, analyze: () => ({ families: ['slow'], response_known: true }) }),
  state_becomes_response_family: (api) => ({ ...api, analyze: () => ({ families: ['freeze'], response_known: true }) }),
  third_party_behaviour_attributed_to_user: (api) => ({ ...api, inputRoute: () => ({ action: 'continue' }) }),
  hypothetical_example_treated_as_lived_event: (api) => ({ ...api, inputRoute: () => ({ action: 'continue' }) }),
  prediction_allowed_into_questionnaire: (api) => ({ ...api, inputRoute: () => ({ action: 'continue' }) }),
  safety_route_allowed_into_questionnaire: (api) => ({ ...api, inputRoute: () => ({ action: 'continue' }) }),
  external_constraint_alone_creates_pattern: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  reinforcement_gate_removed: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  current_evidence_gate_removed: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  single_occurrence_creates_established_pattern: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  inactive_pattern_marked_active: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  adaptive_majority_creates_pattern: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  slow_bank_exposes_fast_response: (api) => ({ ...api, questionRecoveryOptions: () => [{ semantic_id: 'response:recovery:rapid-action' }] }),
  family_correction_does_not_reset_downstream: (api) => ({ ...api, applyFamilyCorrection: (state) => ({ ...state, family: 'fast' }) }),
  topic_change_alters_response_family: (api) => ({ ...api, changeTopic: (state) => ({ ...state, topic_id: 'money', families: ['fast'] }) }),
  language_surface_changes_semantic_contract: (api) => ({ ...api, contract: (_frame, evidence) => ({ classification: evidence.surface === 'en' ? 'established_pattern' : 'situational_reaction' }) }),
  other_route_dead_end: (api) => ({ ...api, otherTopicOptions: () => [] }),
  unknown_response_forced_into_pattern: (api) => ({ ...api, evaluate: () => ({ classification: 'established_pattern' }) }),
  non_applicable_answer_scored_as_maladaptive: (api) => ({ ...api, scoreAnswer: () => 1 }),
  result_consequence_uses_wrong_topic: (api) => ({ ...api, consequenceFor: () => 'topic:money' }),
};

const frame = core.analyze('Tôi thường kiểm tra nhiều lần rồi mới gửi.', 'work');

function independentOracleRejects(id, api) {
  switch (id) {
    case 'emotion_becomes_response_family': return api.analyze('Tôi buồn.', 'work').response_known !== false;
    case 'state_becomes_response_family': return api.analyze('Tôi mệt.', 'work').response_known !== false;
    case 'third_party_behaviour_attributed_to_user': return api.inputRoute('My boss always avoids difficult conversations.').action === 'continue';
    case 'hypothetical_example_treated_as_lived_event': return api.inputRoute('Suppose someone checks ten times before sending.').action === 'continue';
    case 'prediction_allowed_into_questionnaire': return api.inputRoute('When will she come back to me?').action === 'continue';
    case 'safety_route_allowed_into_questionnaire': return api.inputRoute('I am not safe and I am being threatened.').action === 'continue';
    case 'external_constraint_alone_creates_pattern': return api.evaluate(frame, { externalConstraintOnly: true }).classification === 'established_pattern';
    case 'reinforcement_gate_removed': return api.evaluate(frame, { reinforcementUnknown: true }).classification === 'established_pattern';
    case 'current_evidence_gate_removed': return api.evaluate(frame, { currentEvidenceUnknown: true }).classification === 'established_pattern';
    case 'single_occurrence_creates_established_pattern': return api.evaluate(frame, { singleOccurrence: true }).classification === 'established_pattern';
    case 'inactive_pattern_marked_active': return api.evaluate(frame, { inactiveNow: true }).classification === 'established_pattern';
    case 'adaptive_majority_creates_pattern': return api.evaluate(frame, { adaptiveMajority: true }).classification === 'established_pattern';
    case 'slow_bank_exposes_fast_response': return api.questionRecoveryOptions(frame, 'A').some((x) => /rapid-action/.test(x.semantic_id));
    case 'family_correction_does_not_reset_downstream': {
      const next = api.applyFamilyCorrection({ family: 'slow', answers: { A: 'x', B: 'y' }, current: [3, 3, 3, 3] });
      return next.answers !== undefined || next.current !== undefined;
    }
    case 'topic_change_alters_response_family': return api.changeTopic({ topic_id: 'work', families: ['slow'] }).families[0] !== 'slow';
    case 'language_surface_changes_semantic_contract': return api.contract(frame, { surface: 'en' }).classification !== api.contract(frame, { surface: 'vi' }).classification;
    case 'other_route_dead_end': return api.otherTopicOptions('vi').length === 0;
    case 'unknown_response_forced_into_pattern': return api.evaluate(frame, { responseUnknown: true }).classification === 'established_pattern';
    case 'non_applicable_answer_scored_as_maladaptive': return api.scoreAnswer({ position: 'non-applicable' }) !== 0;
    case 'result_consequence_uses_wrong_topic': return api.consequenceFor('topic:work') !== 'topic:work';
    default: return false;
  }
}

test('critical mutation list is frozen before execution and matches the engine registry', () => {
  assert.equal(lock.locked_before_mutation_run, true);
  assert.deepEqual([...core.criticalMutations], lock.mutations);
  assert.deepEqual(Object.keys(mutations), lock.mutations);
});

test('runtime semantic mutation score is 100% for the 20 locked critical operators', () => {
  const killed = lock.mutations.filter((id) => independentOracleRejects(id, mutations[id](core)));
  assert.deepEqual(killed, lock.mutations);
  assert.equal(killed.length / lock.mutations.length, 1);
});
