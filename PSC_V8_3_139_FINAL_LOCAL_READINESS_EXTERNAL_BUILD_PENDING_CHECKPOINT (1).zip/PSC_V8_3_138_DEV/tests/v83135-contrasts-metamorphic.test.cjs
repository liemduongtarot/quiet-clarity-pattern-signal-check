const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83135='1';
const {loadCore,unaccent,mixedAccent}=require('./v83117-helper.cjs');
const core=loadCore();

test('contrast: use versus mention changes scope, not by phrase identity',()=>{
  const pairs=[
    ['Giả định rằng tôi nghỉ việc, tôi sẽ trì hoãn.','Tôi không muốn hệ thống giả định động cơ.'],
    ['Assume that I leave, then I would delay.','Do not assume my motive.'],
    ['Tưởng tượng tôi rời đi, tôi sẽ chờ.','Đừng tưởng tượng nguyên nhân của tôi.']
  ];
  for(const [use,mention] of pairs){
    const a=core.analyze(use).operator_occurrences[0],b=core.analyze(mention).operator_occurrences[0];
    assert.ok(a.governed_proposition_ids.length>0,use);
    assert.equal(b.governed_proposition_ids.length,0,mention);
  }
});

test('metamorphic: accent transforms preserve occurrence role and family',()=>{
  const source='Mỗi khi yêu cầu chưa rõ, tôi kiểm tra thêm và trì hoãn bắt đầu. Tôi không muốn hệ thống giả định động cơ.';
  const results=[source,unaccent(source),mixedAccent(source)].map(x=>core.analyze(x));
  for(const result of results){
    assert.ok(result.families.includes('slow'));
    assert.equal(result.operator_occurrences[0].scope_type,'NONE');
    assert.equal(result.canonical_semantic_state.frames.length,0);
  }
});

test('metamorphic: adding a lexical mention does not globalize local behavior',()=>{
  const base=core.analyze('I repeatedly check when requirements are unclear.');
  for(const suffix of [' Do not assume my motive.',' The word "assume" describes an inference policy.']){
    const changed=core.analyze(`I repeatedly check when requirements are unclear.${suffix}`);
    assert.deepEqual([...changed.families],[...base.families]);
    assert.notEqual(changed.input_route.id,'input:hypothetical-or-example');
  }
});
