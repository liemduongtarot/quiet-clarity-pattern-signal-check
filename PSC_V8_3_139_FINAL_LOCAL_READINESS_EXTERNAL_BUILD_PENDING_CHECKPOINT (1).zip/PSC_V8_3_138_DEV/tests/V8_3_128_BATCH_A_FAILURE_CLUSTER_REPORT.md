# V8.3.128 Batch A Failure Cluster Report

The 22 failures form **five root-cause clusters**. Clustering is by first semantic divergence, not wording or final output.

| Cluster | Count | Case IDs | Shared semantic structure | First divergence | Why current architecture fails | Old heuristic / duplicate authority | Canonical state lost or recomputed | Severity |
|---|---:|---|---|---|---|---|---|---|
| C1 — non-real frame representation | 3 | A01, A03, A05 | Explicitly fictional or thought-experiment proposition outside the small frame-marker list | E reality status | Reality is inferred from closed phrase regexes (`suppose`, `imagine`, etc.), not composed from frame + fictional modifiers | Yes: reality is separately inferred in V122, V123, V124, V125 and consumed again in V126 | No correct canonical non-real state is produced; later route canonicalization recomputes from partial states | SYSTEMIC |
| C2 — open-class actor/ownership | 3 | A06, A08, A09 | Third-party grammatical subject expressed by ordinary role noun, not hard-coded relationship phrase | D actor/ownership | Actor is a role-name whitelist; unspecified/default is allowed to become self-lived | Yes: ownership/actor are independently inferred by V121, V122 attribution, V123 actor, V124 `third`, and V125 `routeFacts` | Actor is repeatedly recomputed; no stable subject identity survives end-to-end | SYSTEMIC |
| C3 — predicate/object ontology boundary | 11 | A11, A12, A14, A15, A17, A18, A19, A20, A21, A25, A26 | Semantically valid review/comparison/verification/consultation/rehearsal/avoidance/fast-action expressed outside narrow verb-object regex pairs | C/G proposition extraction or predicate normalization | Predicate recognition is surface-rule coverage. V127 adds another review head/object parser instead of consuming one canonical proposition | Yes: at least V121, V122, V123, V124, V125 and V127 independently recognize predicates/families | Some parent candidates can be replaced, filtered, or supplemented by later raw-text reparse; missing predicates never enter a canonical IR | SYSTEMIC |
| C4 — clause/phase construction | 2 | A22, A24 | Two valid semantic phases connected by ordinary coordination or `after` relation | B clause segmentation | Active segmenters recognize different, incomplete connector sets; temporal detection and segmentation are separate | Yes: V121 split, V122 segment, V123 refine, V124 split and V125 sequence regex are independent | Family may survive while phase structure disappears; sequence is recomputed repeatedly | CROSS-LAYER |
| C5 — question-intent grammar | 3 | A27, A28, A30 | Clear prediction or decision question with non-canonical English word order | J intent classification | V127 intent authority is still a regex over a small set of surface forms; when it misses, inherited generic route survives | Yes: generic parent input routing competes with V127 question intent and V126 canonical route priority | Intent is not a canonical proposition attribute consumed by routing; route can default to self-lived | SYSTEMIC |

## Distribution

- E reality status: 3
- D actor/ownership: 3
- C proposition extraction: 2
- G predicate normalization: 9
- B clause segmentation: 2
- J intent classification: 3

## Failure-type distribution

- TYPE 1 — REPRESENTATION FAILURE: **22**
- TYPE 2 — STATE PROPAGATION FAILURE: **0 proven as first divergence**
- TYPE 3 — COMPETING AUTHORITY FAILURE: **0 proven as first divergence**

This distribution does not mean propagation and competing-authority risks are absent. They are systemic architectural findings. It means the frozen evidence and static code identify an earlier representation failure for every failed case; downstream problems must not be promoted to root cause merely because the pipeline is duplicated.

## Largest shared gap

The largest direct cluster is C3 (11/22): there is no stable open predicate/object representation before family logic. The larger cross-cluster gap is that reality, actor, clause, predicate, intent, family and sequence are all inferred by multiple wrapper layers from raw text. Consequently a local lexeme patch would add coverage to one authority without making it the authority.
