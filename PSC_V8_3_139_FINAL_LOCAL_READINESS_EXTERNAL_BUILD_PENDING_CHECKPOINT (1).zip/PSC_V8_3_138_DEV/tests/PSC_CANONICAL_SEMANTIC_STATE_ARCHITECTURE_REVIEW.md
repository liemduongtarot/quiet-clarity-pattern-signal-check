# PSC Canonical Semantic State Architecture Review

## Decision scope

This is an owner/architecture design artifact based on frozen V8.3.128 evidence and static source inspection. V8.3.128 remains immutable. No runtime source, config, schema used by the candidate, expected contract, sealed evidence, or corpus was modified or executed.

## Architecture decision

Adopt one graph-shaped canonical semantic state between normalized input and all behavioral decisions:

`raw → surface normalization → clause/proposition graph → scoped semantic resolvers → sealed canonical state → family / sequence / route consumers → serializer`

The model is graph-shaped rather than a flat record because operators and relations have proposition scope. Clauses contain one or more propositions; propositions reference stable actors, predicates, objects and facts; typed edges express `THEN`, `BEFORE`, `AFTER`, `WHILE`, `BECAUSE`, `ALTHOUGH`, coordination, condition, quotation and attribution. Sequence is projected from proposition IDs and edges—not reconstructed from family order.

## Canonical model

The proposed JSON Schema is `PSC_CANONICAL_SEMANTIC_SCHEMA_PROPOSAL.json`. It includes all owner-required fields and splits concepts that otherwise conflate:

- `actor` is an entity object; `actor_type`, grammatical person and ownership are distinct.
- `reality_status`, hypothetical/example status, quotation and attribution are proposition-scoped.
- negation and cessation are operators with explicit proposition targets.
- predicate lemma/class and object/object-semantic-class are separate and compositional.
- evidence sufficiency, evidence change, boundedness, frequency and repetition are separate facts.
- temporal position and typed relation edges preserve actual order/causality.
- question intent belongs to a canonical intent object targeting proposition IDs.
- family candidacy, eligibility and suppression are downstream decisions with cited proposition/rule.
- route is one deterministic projection with cited canonical sources.

Unknown is a first-class enum. It must never silently default to self, actual, positive, eligible or self-lived.

## Clause/operator design

The clause graph builder recognizes syntax and connectors in English, Vietnamese and mixed surfaces: and/but/because/although/before/after/then/while/if, suppose/example frames, according-to/reported/quoted forms and their Vietnamese equivalents. A connector produces an edge or scoped operator attachment. Global regex matches may supply lexical features only; they cannot assign proposition-wide scope.

For example, `P1 THEN P2`, `P1 BEFORE P2`, `P1 AFTER P2`, `P1 WHILE P2`, and `P1 BECAUSE P2` store stable proposition IDs. Attribution connects a source actor to the attributed proposition; it does not overwrite the proposition’s grammatical actor.

## Predicate/object priority

Predicate and object construction is the first implementation priority because it accounts for 11/22 direct failures. Normalization is compositional:

1. identify proposition predicate head, auxiliaries, particles and result states;
2. resolve arguments and object semantic class independently of a closed object phrase list;
3. combine predicate + object class + scoped operators into a canonical predicate class;
4. let evidence and family rules consume that state.

Lexical dictionaries remain aids for lemma/class proposals. They cannot directly emit a family or route. This supports `examined assumption`, `compared measurement`, `verified calibration`, `ask … confirm`, `rehearsing explanation`, `archived … unread`, and unseen equivalents through composition rather than exact phrases.

## Actor, reality and intent

- Actor resolution uses grammatical subject/entity/coreference and attribution graphs, not relationship-role whitelists. It distinguishes self, collective self, third party, generic and unknown.
- Reality is proposition-level and operator-scoped: actual, hypothetical, counterfactual, fictional, example, reported-actual or unknown. Embedded actual propositions may coexist with non-real ones without global flattening.
- Intent combines speech act, interrogative structure, modal/wh targets and proposition graph. Public prediction/decision routes derive from this object, not surface word order.

## Single semantic authority

`PSC_SEMANTIC_AUTHORITY_MIGRATION_MAP.md` assigns exactly one producer to every fact. Consumers receive read-only projections and may not infer meaning from raw text. Every fact has provenance: producer, source span, rule/operator, status, and previous/new values when refined. This makes first divergence directly auditable.

## Legacy stack conclusion

V121–V127 are seven interacting wrappers, not a canonical pipeline. Six raw-reparse semantic meaning; V126 recomputes route from overlapping partial representations. All 15 audited facts have duplicate authorities. The goal is architecture contraction, not a new wrapper around the stack.

The retirement plan migrates reusable rules/tests to named authorities, replaces family-preservation fallbacks with invariants, rewrites V126 as a pure canonical-state route resolver, and removes the compatibility parser from the decision path. Target: one canonical construction pipeline plus three pure consumers. Compatibility remains only as a shadow oracle during migration.

## Migration and shadow mode

Migration is staged, not a big-bang rewrite:

1. create schema/trace scaffolding in a future authorized working copy;
2. construct canonical state in shadow mode while legacy output remains user-facing;
3. transfer representation authorities one fact group at a time;
4. transfer derived evidence/intent/sequence authorities;
5. switch family and route to canonical-only inputs after owner-reviewed parity/differences;
6. retire duplicate inference and finally the legacy fallback.

Shadow records contain legacy result, canonical state, canonical-derived result, field/output differences and invariant violations. Existing development regressions may be used. Frozen sealed Batch A is not rerun or tuned against.

## Invariants

The detailed contract is `PSC_CANONICAL_INVARIANT_SPEC.md`. It defines all required invariants, producers, consumers, illegal transitions, runtime assertions and tests. In implementation mode, an invariant breach must fail closed to clarification; shadow mode records it without altering behavior.

## Validation strategy

- **Level 1 — representation (primary):** raw input → exact canonical graph/state. Test operator scope, actor/coreference, reality frames, predicate/object composition, evidence, intent and relations. Use bilingual and mixed minimal contrasts.
- **Level 2 — transformation/invariant:** canonical state → qualification, sequence and route. Test decision tables independently from wording; mutation tests introduce illegal fact rewrites, raw reparses, orphan families, dropped edges and competing routes.
- **Level 3 — end to end:** retain historical regression, properties, mutations, build and Browser E2E after migration convergence. New sealed validation is created only after authorized development convergence and pre-run governance.

Root-cause detection should occur mainly at Levels 1 and 2. Test volume must not substitute for representation certainty.

## 22-failure representation check

`PSC_V8_3_128_22_FAILURE_CANONICAL_REPRESENTATION_MAP.md` maps each failed case to the canonical state that should exist and the fields that prevent its failure. The distribution remains: reality 3, actor 3, predicate/object 11, clause/relation 2, intent 3. No exact-case rule is proposed.

## Complexity and expected risk

- Current authority shape: 7 semantic wrappers; duplicate authority for 15/15 audited facts.
- Proposed shape: 1 staged canonical builder with registered fact owners; 3 state-only consumers.
- Target removals: 15 duplicate fact authorities; six downstream raw reparsers; family-preservation and generic semantic fallback heuristics.
- Primary risk: behavior drift when disentangling legacy interactions.
- Secondary risks: bilingual clause ambiguity, coreference uncertainty, operator-scope ambiguity, schema over-expansion, and shadow parity being mistaken for semantic correctness.
- Controls: explicit unknowns, per-fact provenance, fail-closed invariants, incremental authority transfer, owner-classified shadow differences, and Level-1/2 mutation gates before E2E or sealed validation.

## Governance state

- V8.3.128: immutable failed review candidate.
- Batch A: preserved first-run only; no rerun.
- Batch B: not run.
- V8.3.129 runtime: not created or modified.
- New holdout/corpus expansion: not performed.
- Step 111: prohibited.
- Production lock/deploy: prohibited.

## Verdict

**ARCHITECTURE READY FOR V8.3.129 CANONICAL-STATE IMPLEMENTATION**

This verdict approves the architecture design only. It does not authorize implementation, production action, sealed-pool creation, or modification of V8.3.128.
