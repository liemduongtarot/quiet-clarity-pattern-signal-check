# V8.3.131 Forensic Level Split and Design Report

Status: **FORENSIC DESIGN COMPLETE — SOURCE MODIFICATION NOT STARTED**

Parent authority: `V8.3.130 FAILED REVIEW CANDIDATE`  
Parent freeze commit: `d9d09d43cd23e64ab21e6bef3e3fd2a95eff257e`  
Evidence authority: V8.3.130 Batch A first run, run ID `V83130-A-ca9250fd-de8c-4244-bfb0-e7eb449fad5a`  
Governance: V8.3.130 remains immutable; Batch A was not rerun; Batch B was not run; expected contracts were not changed.

## Executive finding

All 14 failures are **LEVEL-1 REPRESENTATION FAILURES**. None is a demonstrated Level-2 consumer/qualification failure, and none requires classification as BOTH.

The direct canonical-state diagnostic proves the existing V8.3.130 consumer behavior:

| Canonical consumer input | Expected | Actual | Result |
|---|---:|---:|---:|
| positive actual self `avoid-engagement` | ignore | ignore | PASS |
| `review` + repeated + unchanged | slow | slow | PASS |
| `seek-input` + repeated + sufficient | slow | slow | PASS |
| `premature-close` | fast | fast | PASS |
| `review` + bounded + changed | adaptive | adaptive | PASS |

Therefore, cases C035 and C040 do not establish Level-2 defects. C035 sends the consumer an incorrectly negated predicate; C040 loses repetition before the consumer. The consumer correctly acts on the incorrect/incomplete Level-1 state it receives.

## Complete Level-1 / Level-2 split

The `consumer actual` column describes the family decision made from the state actually delivered by Level 1. `Eligible` means the expected canonical state would be accepted by the current consumer.

| Case | Expected canonical state | Actual canonical state | Consumer expected | Consumer actual | First divergence | Split |
|---|---|---|---|---|---|---|
| V130-C002 | reality=fictional/example; actor=other/generic; polarity positive for contained action | reality=actual; actor=self from substring `minh`; ownership=self; whole clause negative | hypothetical route; no family | self-lived; no candidate, NEGATED | token/span normalization, then reality frame | LEVEL-1 |
| V130-C012 | subject/agent=third-party cousin; relation_to_self=cousin; ownership=third-party | actor=self from embedded possessor `tôi`; ownership=self | third-party-only route | self-lived | subject/agent extraction | LEVEL-1 |
| V130-C013 | subject/agent=third-party friend; relation_to_self=friend; ownership=third-party | actor=self from embedded possessor `toi`; ownership=self | third-party-only route | self-lived | subject/agent extraction | LEVEL-1 |
| V130-C015 | subject/agent=third-party acquaintance; relation_to_self=acquaintance; ownership=third-party | actor=self from embedded possessor `mình`; ownership=self | third-party-only route | self-lived | subject/agent extraction | LEVEL-1 |
| V130-C031 | self action plus displacement/non-engagement relation; predicate=avoid-engagement; positive | two AND propositions; both predicates unknown | ignore, eligible | no candidate | proposition/relation extraction | LEVEL-1 |
| V130-C032 | PURPOSE(move/put-away, avoid seeing); governing predicate=avoid-engagement; positive | PURPOSE edge exists, but both predicates unknown; purpose matcher loses connector meaning | ignore, eligible | no candidate | purpose composition | LEVEL-1 |
| V130-C035 | predicate=avoid-engagement; avoidance itself positive; embedded `not face` is purpose/content scope | predicate=avoid-engagement but polarity=negative and negation_scope=p1 | ignore, eligible | no candidate; NEGATED suppression | negation scope | LEVEL-1 |
| V130-C037 | predicate=review; repetition=repeated; settled/unchanged evidence; unbounded | predicate unknown; repetition repeated; evidence state unknown | slow, eligible | no candidate | predicate/object representation | LEVEL-1 |
| V130-C038 | predicate=review; repetition=repeated; evidence_change=unchanged | predicate/repetition correct; evidence_change=changed | slow, eligible | no candidate because changed blocks repeated-review rule | evidence-change polarity | LEVEL-1 |
| V130-C040 | p2 actor=self; predicate=seek-input; repetition=repeated; sufficient + unchanged propagated from p1 | p2 predicate=seek-input, sufficient, unchanged, but repetition=not-repeated | slow, eligible | no candidate | repetition/quantifier representation | LEVEL-1 |
| V130-C046 | P1 consequential sign; P2 review annex; relation WITHOUT; derived premature-close | flattened single proposition; predicate=review; no WITHOUT relation | fast, eligible | no candidate | proposition segmentation/relation extraction | LEVEL-1 |
| V130-C047 | P1 consequential commit; P2 review conditions; BEFORE; derived premature-close | BEFORE exists; P1 predicate unknown because action gate is clause-local and action ontology excludes this relation path | fast, eligible | no candidate | action ontology + relation composition | LEVEL-1 |
| V130-C048 | P1 accept option; P2 review calculation; WITHOUT/not-yet relation; positive premature action | flattened proposition; predicate unknown; whole proposition negative | fast, eligible | no candidate; NEGATED | proposition segmentation and negation scope | LEVEL-1 |
| V130-C062 | review + changed evidence + bounded single pass | review + changed correct; boundedness=unknown | adaptive, eligible | no candidate | boundedness representation | LEVEL-1 |

Distribution:

- LEVEL-1 REPRESENTATION FAILURE: **14**
- LEVEL-2 CONSUMER/QUALIFICATION FAILURE: **0**
- BOTH: **0**

## Root-cause clusters

| Cluster | Cases | Count | Shared first divergence | Architectural finding |
|---|---|---:|---|---|
| A — reality frame and lexical ambiguity | C002 | 1 | token/span normalization | Substring pronoun detection and incomplete Vietnamese reality frames jointly corrupt actor, reality and polarity. |
| B — relational third-party subject | C012, C013, C015 | 3 | subject/agent extraction | Possessor is treated as behavior actor because subject and relation roles are not represented separately. |
| C — intentional non-engagement | C031, C032, C035 | 3 | proposition/relation or negation scope | Avoidance is not consistently derived from action + purpose/result; embedded negation can negate the derived behavior incorrectly. |
| D — repeated review / slow | C037, C038, C040 | 3 | predicate, evidence polarity or repetition | Review semantics are split across lexical detection, evidence reduction and quantification; negated change has wrong precedence. |
| E — premature action / fast | C046, C047, C048 | 3 | proposition relation and action ontology | Prematurity is still partly clause-local/lexical rather than derived from consequential action BEFORE/WITHOUT required review. |
| F — bounded changed review | C062 | 1 | boundedness | `one pass/one round` is not a first-class boundedness form independent of duration. |

Largest shared architectural gap: **relation-aware proposition construction is incomplete**. The runtime has a canonical state object and single consumer authority, but Level 1 still flattens or incompletely composes semantic roles, scoped operators and relations. This is a representation-model coverage problem, not evidence of competing downstream authority.

## Current architecture truth

### What is already sound

- Canonical state is passed to family, route and sequence consumers.
- Consumers do not reparse raw input.
- Direct Level-2 contracts pass for all five target families.
- Public route derives from canonical reality/actor/intent state.
- The 15-fact producer declaration remains single-authority in V8.3.130.

### What is incomplete

- Actor is a flat resolved object, not a subject/relation graph with AGENT, SUBJECT, POSSESSOR, OBJECT_OWNER and REPORTED_ACTOR roles.
- Relations support several typed edges, but `WITHOUT` is absent and clause connectors can be lost before semantic composition.
- Negation is proposition-wide in cases where it should attach to a subordinate purpose/review proposition.
- Consequential action and required review are not consistently separate propositions.
- Quantifier and evidence reducers use lexical priority rather than scoped semantic operators.
- Reality-frame scope is document-wide only for a limited phrase inventory and is vulnerable to substring actor matches.

## Required V8.3.131 design

### Subject/relation graph

Add explicit canonical roles without creating a second semantic authority:

- `subject_actor_id`
- `agent_actor_id`
- `possessor_actor_id`
- `object_owner_actor_id`
- `reported_actor_id`
- `entity_relation_to_self`

Invariant: `RELATION_TO_SELF_DOES_NOT_IMPLY_SELF_ACTOR`.

Actor resolution must use token/span-aware subject extraction. The tokens `mình/minh/tôi/toi` count as self only when they occupy a pronoun role, never as substrings inside `minh họa/minh hoa` or as possessors embedded inside a third-party subject noun phrase.

### Reality frames

Resolve a frame before actor-based routing, attach the frame to all contained propositions, and cover fictional illustration / imaginary scenario / hypothetical illustration semantics. Reality resolution must not depend solely on literal `giả sử` or `ví dụ`.

### Typed proposition relations

Preserve these relations as canonical graph edges:

- PURPOSE
- BEFORE
- WITHOUT
- CAUSE
- CONTRAST
- CONDITION

Action + PURPOSE(non-exposure/non-response/non-engagement) derives `avoid-engagement`. Consequential action BEFORE/WITHOUT relevant review derives `premature-close`. Neither derivation may depend on the exact sealed phrases.

### Scoped operators

- Negation attaches to its target proposition/predicate, not automatically to the whole sentence.
- `NEGATED_CHANGE_CANNOT_MAP_TO_CHANGED`.
- Formal evidence states remain mutually exclusive: CHANGED, UNCHANGED, NO_NEW_EVIDENCE, UNKNOWN.
- Boundedness is independent of duration and repetition; one pass/round/check is bounded.

### Consumer layer

No functional redesign is currently justified. Preserve the existing consumer contracts, then create direct Level-2 tests so later parser changes cannot conceal a consumer regression.

## Test obligations before any sealed validation

1. Replay the 14 exact V8.3.130 cases only as **CONTAMINATED HISTORICAL REGRESSIONS**.
2. Fresh Level-1 cases for subject roles, pronoun span ambiguity, reality scope, PURPOSE avoidance, repeated review, negated change, BEFORE/WITHOUT prematurity and bounded single-pass review.
3. Direct Level-2 canonical-state cases for ignore, both slow rules, fast and adaptive.
4. Metamorphic variation across relation noun, possessor, frame, purpose, review/action verb, clause order, boundedness, language and accents.
5. Kill all 13 specified critical mutations.
6. Add invariants:
   - `RELATION_TO_SELF_DOES_NOT_IMPLY_SELF_ACTOR`
   - `NO_SUBSTRING_PRONOUN_INFERENCE`
   - `NEGATED_CHANGE_CANNOT_MAP_TO_CHANGED`
   - `PURPOSE_RELATION_PRESERVED`
   - `BEFORE_WITHOUT_RELATION_PRESERVED`
   - `NEGATION_SCOPE_PRESERVED`
7. Re-run the 15-fact authority audit and confirm no legacy fallback, raw-text downstream reparse or duplicate semantic producer.

## Decision gate

Recommended classification: **V8.3.131 SHOULD BE CANONICAL LEVEL-1 REPRESENTATION CONSOLIDATION**.

This is broader than a local phrase repair because six clusters cross actor roles, scoped operators and proposition relations. It does **not** justify replacing the canonical consumer architecture: the consumer layer passed every direct target contract. The correct scope is to consolidate Level-1 graph construction while preserving the V8.3.129/130 single-semantic-authority model.

## Governance verdict

- Source patched: **NO**
- V8.3.130 overwritten: **NO**
- Batch A rerun: **NO**
- Batch B run: **NO**
- Expected contracts changed: **NO**
- Production deployment/lock: **NO**
- Step 111: **NOT EXECUTED**

**FORENSIC DESIGN GATE PASS — AWAITING EXPLICIT AUTHORIZATION TO MODIFY V8.3.131 SOURCE**
