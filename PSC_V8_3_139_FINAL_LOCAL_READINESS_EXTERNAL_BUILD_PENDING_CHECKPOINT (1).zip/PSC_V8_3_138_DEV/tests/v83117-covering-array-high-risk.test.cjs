const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore } = require('./v83117-helper.cjs');
const core = loadCore();
const frame = core.analyze('Tôi thường kiểm tra nhiều lần rồi mới gửi.', 'work');

test('explicit pairwise coverage spans every pair across route, family, question and surface', () => {
  const factors = {
    topic: [...core.topicOptions('vi').filter((x) => x.topic_id !== 'other').map((x) => x.topic_id), ...core.otherTopicOptions('vi').map((x) => x.topic_id)],
    family: [...core.families],
    question: [...core.questions],
    surface: [...core.languages],
  };
  const names = Object.keys(factors);
  for (let left = 0; left < names.length; left += 1) for (let right = left + 1; right < names.length; right += 1) {
    const expected = factors[names[left]].length * factors[names[right]].length;
    const observed = new Set();
    for (const a of factors[names[left]]) for (const b of factors[names[right]]) observed.add(`${a}|${b}`);
    assert.equal(observed.size, expected, `${names[left]} x ${names[right]}`);
  }
});

test('high-risk three-way gate exhausts reinforcement x current evidence x lifecycle status', () => {
  let total = 0;
  for (const reinforcement of ['known', 'unknown']) for (const current of ['known', 'unknown']) for (const lifecycle of ['repeated-active', 'single', 'inactive']) {
    const result = core.evaluate(frame, {
      reinforcementUnknown: reinforcement === 'unknown',
      currentEvidenceUnknown: current === 'unknown',
      singleOccurrence: lifecycle === 'single',
      inactiveNow: lifecycle === 'inactive',
    });
    // Current-status insufficiency is the terminal status gate when both gates are unknown.
    if (current === 'unknown') assert.equal(result.classification, 'current_status_insufficient');
    else if (reinforcement === 'unknown') assert.equal(result.classification, 'situational_or_unreinforced');
    else if (lifecycle === 'single') assert.notEqual(result.classification, 'established_pattern');
    else if (lifecycle === 'inactive') assert.equal(result.classification, 'residual_or_old');
    total += 1;
  }
  assert.equal(total, 12);
});
