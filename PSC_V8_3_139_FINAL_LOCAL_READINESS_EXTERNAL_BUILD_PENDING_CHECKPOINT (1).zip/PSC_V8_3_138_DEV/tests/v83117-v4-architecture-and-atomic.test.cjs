const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, unaccent, mixedAccent } = require('./v83117-helper.cjs');
const core = loadCore();

const copies = {
  slow: ['Tôi cứ kiểm tra thêm và trì hoãn bắt đầu.', 'I keep checking and delay getting started.'],
  fast: ['Tôi quyết ngay và nhận quá nhiều việc cùng lúc.', 'I decide immediately and take on too much at once.'],
  freeze: ['Tôi muốn xử lý nhưng bị đứng lại và không bắt đầu được.', 'I want to deal with it but become stuck and cannot begin.'],
  ignore: ['Tôi chuyển sang việc khác để né phần đang khó chịu.', 'I move to something else to avoid the uncomfortable part.'],
  adaptive: ['Tôi kiểm tra vừa đủ, dừng khi đủ thông tin và điều chỉnh khi có dữ kiện mới.', 'I check enough, stop when I have enough information and adjust when new evidence appears.'],
};

test('schema exposes 23 topic routes and every Other route is reachable', () => {
  assert.equal(core.topicOptions('vi').length, 12);
  assert.equal(core.otherTopicOptions('vi').length, 12);
  assert.equal(core.schema.topicRoutes, 23);
  assert.equal(new Set(core.otherTopicOptions('vi').map((row) => row.id)).size, 12);
});

test('exhaustive atomic grid covers topic x family x question x 19 endpoints x four surfaces', () => {
  const topicRoutes = core.topicOptions('vi').filter((row) => row.topic_id !== 'other').map((row) => [row.topic_id, null])
    .concat(core.otherTopicOptions('vi').map((row) => ['other', row.topic_id]));
  const surfaces = [
    ['vi', (value) => value],
    ['vi-unaccented', unaccent],
    ['vi-mixed-diacritics', mixedAccent],
    ['en', (value) => value],
  ];
  let cells = 0;
  const failures = [];
  for (const [domain, subtopic] of topicRoutes) for (const family of core.families) for (const [surface, transform] of surfaces) {
    const raw = transform(surface === 'en' ? copies[family][1] : copies[family][0]);
    const frame = core.analyze(raw, domain, subtopic);
    for (const question of core.questions) {
      const direct = core.options(frame, question, `v3:${family}`);
      const recovery = core.questionRecoveryOptions(frame, question, `v3:${family}`);
      if (direct.length !== 10 || recovery.length !== 10 || direct[9].other !== true) failures.push({ domain, subtopic, family, surface, question });
      for (let index = 0; index < 9; index += 1) {
        cells += 1;
        if (!direct[index].id || !direct[index].semantic_id) failures.push({ type: 'direct', domain, family, question, index });
      }
      for (const option of recovery) {
        cells += 1;
        if (!option.id || !option.semantic_id || !option.position) failures.push({ type: 'recovery', domain, family, question, option });
      }
    }
  }
  assert.equal(cells, 23 * 5 * 4 * 8 * 19);
  assert.equal(cells, 69920);
  assert.deepEqual(failures, []);
});

test('clarification and current-evidence endpoints are semantic-ID complete', () => {
  let clarificationCells = 0;
  let currentCells = 0;
  for (const topic of core.otherTopicOptions('vi')) {
    const frame = core.analyze('Tôi buồn nhưng chưa rõ mình phản ứng thế nào.', 'other', topic.topic_id);
    const recovery = core.clarificationRecoveryOptions(frame);
    clarificationCells += recovery.length;
    assert.equal(recovery.length, 8);
    assert.equal(recovery.every((row) => row.id && row.semantic_id), true);
    const current = core.currentEvidenceOptions('vi');
    for (const rows of Object.values(current)) {
      currentCells += rows.length;
      assert.equal(rows.length, 5);
      assert.equal(rows.some((row) => row.unknown), true);
    }
  }
  assert.equal(clarificationCells, 96);
  assert.equal(currentCells, 240);
});
