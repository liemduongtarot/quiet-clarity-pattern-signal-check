/* Locked after source freeze. These exact phrasings were not used to implement the router. */
/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm');
const source=process.argv[2]||'public/candidate.html',html=fs.readFileSync(source,'utf8');
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}};
const document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}};
const c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const domains=[
 ['work','công việc cứ chệch khỏi điều tôi dự tính','công việc'],['business','việc kinh doanh chưa tìm được nhịp ổn định','business'],
 ['money','các khoản tiền ra vào liên tục lệch kế hoạch','tiền bạc'],['romantic','mối quan hệ tình cảm cứ đứng ở một chỗ','mối quan hệ tình cảm'],
 ['friends','kết nối với bạn bè gần đây trở nên khó xử','quan hệ bạn bè'],['family','sinh hoạt trong nhà liên tục có chuyện không thuận','gia đình'],
 ['home','nơi ở hiện tại phát sinh nhiều điều ngoài dự kiến','chuyện nhà ở'],['daily','nhịp sống mỗi ngày cứ rối lên','đời sống hằng ngày'],
 ['wellbeing','sức lực của tôi lên xuống thất thường','trạng thái hằng ngày'],['direction','con đường phía trước vẫn chưa thành hình','hướng đi']
];
const emotions=[['bất lực','bất lực'],['bối rối','bối rối'],['thất vọng','thất vọng']];
const ascii=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D');
const cases=[];for(const [area,event,domain] of domains)for(const [emotion,label] of emotions){const input=`Có những lúc tôi thấy ${emotion} vì ${event}.`;cases.push({area,input,domain,label,variant:'accented'},{area,input:ascii(input),domain,label,variant:'ascii'});}
const results=cases.map(f=>{vm.runInContext(`S.area=${JSON.stringify(f.area)};S.sit=${JSON.stringify(f.input)};S.clar='';`,c);const invalid=vm.runInContext('bad(S.sit)',c),options=invalid?[]:vm.runInContext('uiClarityOptions()',c),text=options.map(x=>x.text).join(' '),flat=ascii(text);return{...f,invalid,pass:!invalid&&options.length===5&&flat.includes(ascii(f.domain))&&flat.includes(ascii(f.label))&&!text.startsWith('Điểm khó nhất với tôi nằm ở phản ứng')&&options.some(x=>x.id==='adaptive:no-signal'),ids:options.map(x=>x.id)}});
const passed=results.filter(x=>x.pass).length;console.log(JSON.stringify({locked:true,source,total:results.length,passed,failed:results.length-passed,results},null,2));if(passed!==results.length)process.exit(1);
