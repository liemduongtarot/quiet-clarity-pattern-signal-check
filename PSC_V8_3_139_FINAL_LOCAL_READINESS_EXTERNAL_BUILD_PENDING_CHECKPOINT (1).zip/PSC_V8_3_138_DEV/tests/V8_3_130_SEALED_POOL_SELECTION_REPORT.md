# V8.3.130 Sealed Pool Selection Report

Status: FINAL 60 SELECTED — NOT SEALED, NOT EXECUTED.

- Candidates generated: 100
- Candidates rejected/not selected: 40
- Final selected: 60
- Historical/adversarial/contrast/convergence items compared: 1040
- Runtime executions: 0

## Rejection distribution

```json
{
  "DIVERSITY_SELECTION_SURPLUS": 40
}
```

## Coverage distribution

```json
{
  "public_route": {
    "input:hypothetical-or-example": 8,
    "input:third-party-only": 8,
    "input:self-lived": 32,
    "input:decision-request": 4,
    "input:prediction": 4,
    "input:clarification-required": 4
  },
  "internal_reality_status": {
    "hypothetical": 8,
    "current": 40,
    "future": 8,
    "unknown": 4
  },
  "actor_type": {
    "third_party": 20,
    "self": 36,
    "unknown": 4
  },
  "ownership": {
    "third_party": 20,
    "self": 36,
    "unknown": 4
  },
  "predicate_class": {
    "review": 27,
    "constraint": 5,
    "avoidance": 8,
    "decision": 4,
    "inability": 4,
    "decision_request": 4,
    "prediction": 4,
    "unknown": 4
  },
  "object_semantic_class": {
    "evidence": 27,
    "requirement": 5,
    "communication": 5,
    "decision_option": 12,
    "event": 4,
    "unknown": 4,
    "task": 3
  },
  "expected_family_set": {
    "NO_FAMILY": 36,
    "ignore": 5,
    "slow": 7,
    "fast": 4,
    "freeze": 4,
    "adaptive": 4
  },
  "polarity": {
    "positive": 53,
    "unknown": 4,
    "negative": 3
  },
  "negation_status": {
    "none": 53,
    "unknown": 4,
    "explicit": 3
  },
  "cessation_status": {
    "none": 56,
    "unknown": 4
  },
  "evidence_sufficiency": {
    "unknown": 41,
    "sufficient": 11,
    "insufficient": 8
  },
  "evidence_change": {
    "stable": 52,
    "increased": 4,
    "unknown": 4
  },
  "boundedness": {
    "bounded": 41,
    "unbounded": 15,
    "unknown": 4
  },
  "repetition": {
    "single": 49,
    "repeated": 7,
    "unknown": 4
  },
  "constraint_status": {
    "none": 47,
    "external": 5,
    "external_process": 4,
    "unknown": 4
  },
  "question_intent": {
    "none": 48,
    "decision_request": 4,
    "prediction": 4,
    "unknown": 4
  },
  "temporal_structure": {
    "single_phase": 56,
    "unknown": 4
  },
  "sequence_shape": {
    "atomic": 40,
    "constraint_only": 5,
    "repetition": 7,
    "bounded_review": 4,
    "unknown": 4
  },
  "clause_count": {
    "1": 60
  },
  "clause_relations": {
    "reality-example-review:1": 1,
    "reality-example-review:2": 1,
    "reality-example-review:3": 1,
    "reality-example-review:5": 1,
    "relational-third-review:1": 1,
    "relational-third-review:2": 1,
    "relational-third-review:3": 1,
    "relational-third-review:5": 1,
    "external-wait:1": 1,
    "external-wait:2": 1,
    "external-wait:3": 1,
    "external-wait:5": 1,
    "avoid-displacement:1": 1,
    "avoid-displacement:2": 1,
    "avoid-displacement:3": 1,
    "avoid-displacement:5": 1,
    "slow-stable-review:1": 1,
    "slow-stable-review:2": 1,
    "slow-stable-review:3": 1,
    "slow-stable-review:5": 1,
    "fast-unreviewed-action:1": 1,
    "fast-unreviewed-action:2": 1,
    "fast-unreviewed-action:3": 1,
    "fast-unreviewed-action:5": 1,
    "freeze-internal:1": 1,
    "freeze-internal:2": 1,
    "freeze-internal:3": 1,
    "freeze-internal:5": 1,
    "adaptive-changed-bounded:1": 1,
    "adaptive-changed-bounded:2": 1,
    "adaptive-changed-bounded:3": 1,
    "adaptive-changed-bounded:5": 1,
    "decision-request:1": 1,
    "decision-request:2": 1,
    "decision-request:3": 1,
    "decision-request:5": 1,
    "prediction-request:1": 1,
    "prediction-request:2": 1,
    "prediction-request:3": 1,
    "prediction-request:5": 1,
    "clarification:1": 1,
    "clarification:2": 1,
    "clarification:3": 1,
    "clarification:5": 1,
    "reality-example-review:4": 1,
    "conditional-unreal:2": 1,
    "conditional-unreal:3": 1,
    "conditional-unreal:5": 1,
    "relational-third-review:4": 1,
    "role-third-action:2": 1,
    "role-third-action:3": 1,
    "role-third-action:5": 1,
    "external-wait:4": 1,
    "negated-avoidance:2": 1,
    "negated-avoidance:3": 1,
    "negated-avoidance:5": 1,
    "avoid-displacement:4": 1,
    "slow-stable-review:4": 1,
    "slow-reassurance:2": 1,
    "slow-reassurance:3": 1
  },
  "language_surface": {
    "en": 16,
    "vi": 15,
    "vi-unaccented": 15,
    "vi-mixed": 14
  },
  "template_origin": {
    "independent-construction-reality-example-review-1": 1,
    "independent-construction-reality-example-review-2": 1,
    "independent-construction-reality-example-review-3": 1,
    "independent-construction-reality-example-review-5": 1,
    "independent-construction-relational-third-review-1": 1,
    "independent-construction-relational-third-review-2": 1,
    "independent-construction-relational-third-review-3": 1,
    "independent-construction-relational-third-review-5": 1,
    "independent-construction-external-wait-1": 1,
    "independent-construction-external-wait-2": 1,
    "independent-construction-external-wait-3": 1,
    "independent-construction-external-wait-5": 1,
    "independent-construction-avoid-displacement-1": 1,
    "independent-construction-avoid-displacement-2": 1,
    "independent-construction-avoid-displacement-3": 1,
    "independent-construction-avoid-displacement-5": 1,
    "independent-construction-slow-stable-review-1": 1,
    "independent-construction-slow-stable-review-2": 1,
    "independent-construction-slow-stable-review-3": 1,
    "independent-construction-slow-stable-review-5": 1,
    "independent-construction-fast-unreviewed-action-1": 1,
    "independent-construction-fast-unreviewed-action-2": 1,
    "independent-construction-fast-unreviewed-action-3": 1,
    "independent-construction-fast-unreviewed-action-5": 1,
    "independent-construction-freeze-internal-1": 1,
    "independent-construction-freeze-internal-2": 1,
    "independent-construction-freeze-internal-3": 1,
    "independent-construction-freeze-internal-5": 1,
    "independent-construction-adaptive-changed-bounded-1": 1,
    "independent-construction-adaptive-changed-bounded-2": 1,
    "independent-construction-adaptive-changed-bounded-3": 1,
    "independent-construction-adaptive-changed-bounded-5": 1,
    "independent-construction-decision-request-1": 1,
    "independent-construction-decision-request-2": 1,
    "independent-construction-decision-request-3": 1,
    "independent-construction-decision-request-5": 1,
    "independent-construction-prediction-request-1": 1,
    "independent-construction-prediction-request-2": 1,
    "independent-construction-prediction-request-3": 1,
    "independent-construction-prediction-request-5": 1,
    "independent-construction-clarification-1": 1,
    "independent-construction-clarification-2": 1,
    "independent-construction-clarification-3": 1,
    "independent-construction-clarification-5": 1,
    "independent-construction-reality-example-review-4": 1,
    "independent-construction-conditional-unreal-2": 1,
    "independent-construction-conditional-unreal-3": 1,
    "independent-construction-conditional-unreal-5": 1,
    "independent-construction-relational-third-review-4": 1,
    "independent-construction-role-third-action-2": 1,
    "independent-construction-role-third-action-3": 1,
    "independent-construction-role-third-action-5": 1,
    "independent-construction-external-wait-4": 1,
    "independent-construction-negated-avoidance-2": 1,
    "independent-construction-negated-avoidance-3": 1,
    "independent-construction-negated-avoidance-5": 1,
    "independent-construction-avoid-displacement-4": 1,
    "independent-construction-slow-stable-review-4": 1,
    "independent-construction-slow-reassurance-2": 1,
    "independent-construction-slow-reassurance-3": 1
  }
}
```

All selected cases retain provenance `HUMAN_AUTHORED_SEMANTIC_BRIEF`; deliberate stress variants were not eligible. Pair-level evidence is stored in `V8_3_130_CANDIDATE_BANK_AUDIT.json`.
