# V8.3.132 Archive Audit Report

Status: **PASS**

- ZIP integrity: PASS
- Internal SHA256 manifest: PASS
- Required-file audit: PASS
- Archive: PSC_V8_3_132_FAILED_REVIEW_CANDIDATE_FULL_ARCHIVE.zip
- SHA256: `a42f35f4812ca5f668dea886c0af9b4deb45f11f9540929e1775aea0713c6a8c`
- External local download: NOT YET CONFIRMED
