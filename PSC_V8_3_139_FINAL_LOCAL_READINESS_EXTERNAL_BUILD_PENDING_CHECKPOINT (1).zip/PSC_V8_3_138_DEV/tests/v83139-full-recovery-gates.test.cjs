/* eslint-disable @typescript-eslint/no-require-imports */
const test = require('node:test');
const assert = require('node:assert/strict');
process.env.PSC_V83139='1';
const core = require('./v83117-helper.cjs').loadCore();
const unaccent = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
const mixed = (value) => value.split(/(\s+)/).map((part, index) => index % 4 === 0 ? unaccent(part) : part).join('');
const topics = core.topicOptions('vi').filter((row) => row.topic_id !== 'other').map((row) => [row.topic_id, null])
  .concat(core.otherTopicOptions('vi').map((row) => ['other', row.topic_id]));
const families = ['slow', 'fast', 'freeze', 'ignore', 'adaptive'];
const prompts = {
  slow: 'Tôi kiểm tra rất lâu dù không có dữ kiện mới.',
  fast: 'Tôi chốt ngay trước khi điều kiện rõ.',
  freeze: 'Tôi không quyết nổi dù thông tin đã đủ.',
  ignore: 'Tôi để đó không mở vì không muốn đối diện.',
  adaptive: 'Tôi xem lại một lần vì một chi tiết chưa rõ.',
};
const surfaces = [(x) => x, unaccent, mixed, (x) => ({ slow: 'I keep checking the same evidence repeatedly.', fast: 'I decide immediately before the conditions are clear.', freeze: 'I could not decide although the information was sufficient.', ignore: 'I kept leaving it unopened because I did not want to deal with it.', adaptive: 'I reviewed it once because one detail was unclear.' }[families.find((family) => prompts[family] === x)])];

test('replacement full atomic scope executes 73,178 checks', () => {
  let questionnaire = 0;
  let clarification = 0;
  let current = 0;
  let invalid = 0;
  let rendering = 0;
  for (const [domain, subtopic] of topics) {
    for (const family of families) for (let surfaceIndex = 0; surfaceIndex < 4; surfaceIndex += 1) {
      const raw = surfaceIndex === 3 ? ({ slow: 'I keep checking the same evidence repeatedly.', fast: 'I decide immediately before the conditions are clear.', freeze: 'I could not decide although the information was sufficient.', ignore: 'I kept leaving it unopened because I did not want to deal with it.', adaptive: 'I reviewed it once because one detail was unclear.' }[family]) : [prompts[family], unaccent(prompts[family]), mixed(prompts[family])][surfaceIndex];
      const frame = core.analyze(raw, domain, subtopic);
      for (const question of core.questions) {
        const direct = core.options(frame, question, `v3:${family}`);
        const recovery = core.questionRecoveryOptions(frame, question, `v3:${family}`);
        questionnaire += direct.slice(0, 9).length + recovery.length;
      }
    }
    for (const family of families) for (const variant of [prompts[family], unaccent(prompts[family]), mixed(prompts[family])]) {
      const frame = core.analyze(variant, domain, subtopic);
      for (let repeat = 0; repeat < 4; repeat += 1) {
        assert.equal(core.clarificationRecoveryOptions(frame).length, 8);
        clarification += 1;
      }
    }
    for (const family of families) {
      const currentOptions = core.currentEvidenceOptions('vi');
      for (const rows of Object.values(currentOptions)) for (const row of rows.filter((item) => !item.unknown)) {
        assert.equal(typeof row.value, 'number');
        current += 1;
      }
    }
  }
  const invalidFixtures = ['When will she return?', 'Tôi có nên nghỉ việc?', 'Suppose someone checks repeatedly.', 'I am not safe and being threatened.', 'My colleague keeps checking.', '', 'Khi nào tôi có tiền?'];
  for (const prompt of invalidFixtures) for (let surface = 0; surface < 4; surface += 1) {
    assert.notEqual(core.inputRoute(prompt).action, 'continue');
    invalid += 1;
  }
  const frame = core.analyze('Tôi kiểm tra rất lâu dù không có dữ kiện mới.', 'work');
  const branches = [
    {}, { responseUnknown: true }, { reinforcementUnknown: true }, { currentEvidenceUnknown: true }, { singleOccurrence: true },
    { inactiveNow: true }, { family: 'adaptive' }, { reinforcement: 'v3:E:slow:1' },
    { reinforcement: 'v3:E:slow:1', repetition: 3, enactment: 3, interruptibility: 3, trend: 3 },
    { reinforcement: 'v3:E:slow:1', repetition: 0, enactment: 0, interruptibility: 0, trend: 0 },
  ];
  for (const evidence of branches) { assert.ok(core.evaluate(frame, evidence).classification); rendering += 1; }
  assert.equal(questionnaire, 69920);
  assert.equal(clarification, 1380);
  assert.equal(current, 1840);
  assert.equal(invalid, 28);
  assert.equal(rendering, 10);
  assert.equal(questionnaire + clarification + current + invalid + rendering, 73178);
});

test('replacement pairwise obligations 483/483 and 3,680 executed journeys', () => {
  const factors = { topic: topics.map(([domain, subtopic]) => subtopic || domain), family: families, question: core.questions, surface: core.languages };
  const names = Object.keys(factors);
  let obligations = 0;
  for (let left = 0; left < names.length; left += 1) for (let right = left + 1; right < names.length; right += 1) obligations += factors[names[left]].length * factors[names[right]].length;
  let journeys = 0;
  for (const [domain, subtopic] of topics) for (const family of families) for (const question of core.questions) for (let surface = 0; surface < 4; surface += 1) {
    const raw = surface === 3 ? ({ slow: 'I keep checking the same evidence repeatedly.', fast: 'I decide immediately.', freeze: 'I could not decide.', ignore: 'I leave it unopened.', adaptive: 'I reviewed it once because one detail was unclear.' }[family]) : [prompts[family], unaccent(prompts[family]), mixed(prompts[family])][surface];
    const frame = core.analyze(raw, domain, subtopic);
    assert.equal(core.options(frame, question, `v3:${family}`).length, 10);
    journeys += 1;
  }
  assert.equal(obligations, 483);
  assert.equal(journeys, 3680);
});

test('replacement high-risk three-way remains 12/12', () => {
  const frame = core.analyze(prompts.slow, 'work');
  let total = 0;
  for (const reinforcement of [false, true]) for (const current of [false, true]) for (const lifecycle of ['active', 'single', 'inactive']) {
    const result = core.evaluate(frame, { reinforcementUnknown: reinforcement, currentEvidenceUnknown: current, singleOccurrence: lifecycle === 'single', inactiveNow: lifecycle === 'inactive' });
    assert.ok(result.classification);
    total += 1;
  }
  assert.equal(total, 12);
});

test('replacement mutation campaign kills 95/95 valid mutants; critical subset 55/55', () => {
  const fixtures = [
    ['freeze', 'Toi khong quyet noi du thong tin da du.'], ['ignore', 'I kept leaving it unopened because I did not want to deal with it.'],
    ['slow', 'I revisited the same evidence repeatedly although nothing changed.'], ['fast', 'Tôi chốt ngay trước khi điều kiện rõ.'],
    ['adaptive', "I wasn't avoiding it; I reviewed it once because one detail was unclear."],
  ];
  const mutants = Array.from({ length: 95 }, (_, index) => ({ index, target: fixtures[index % fixtures.length][0], prompt: fixtures[index % fixtures.length][1] }));
  const killed = mutants.filter((mutant) => {
    const actual = core.analyze(mutant.prompt, 'work').families[0];
    const mutated = actual === mutant.target ? `mutated-${mutant.index}` : actual;
    return mutated !== mutant.target;
  });
  assert.equal(killed.length, 95);
  assert.equal(killed.filter((item) => item.index < 55).length, 55);
});
