# V8.3.133 Archive Audit Report

Status: **PASS**

- ZIP integrity: PASS
- Internal SHA256 manifest: PASS
- Required-file audit: PASS
- Archive: PSC_V8_3_133_READY_FOR_MANUAL_STEP_111_REVIEW_FULL_ARCHIVE.zip
- SHA256: `292b2fc418e3baa9e2fbdb120acbc30bac192416c77e9e574e5f774a95123045`
- External local download: NOT YET CONFIRMED
