const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const source=fs.readFileSync('public/psc-v83129-canonical-shadow.js','utf8');
test('critical architecture mutations are killed by structural contracts',()=>{
 const checks=[
  ['downstream family reparses raw',/function familyConsumer\(stateView\)/, /function familyConsumer\([^)]*raw/],
  ['route bypasses intent',/stateView\.intent\.question_intent/,/function routeConsumer\([^)]*raw/],
  ['actor rewritten downstream',/FACT_OWNER[\s\S]*actor:'actor-resolver'/,/familyConsumer[\s\S]{0,500}actor_type\s*=/],
  ['reality recomputed downstream',/reality_status:'frame-resolver'/,/routeConsumer[\s\S]{0,300}RX\./],
  ['predicate object ignored',/resolvePredicate\(text, objectClass\)/,/resolvePredicate\(text\)/],
  ['sequence rebuilt from family array',/stateView\.relations\.filter/,/function sequenceConsumer\([^)]*families/],
  ['legacy fallback overrides canonical',/canonical_shadow:/,/derived\.families\s*=\s*legacy/],
  ['provenance lost',/normalization_rule:rule/,/function fact\(value, producer\)/],
  ['canonical producer bypassed',/buildCanonicalState\(raw\)/,/deriveCanonical\(legacy/]
 ];
 for(const[name,must,mutation]of checks){assert.match(source,must,name);assert.doesNotMatch(source,mutation,name);}
});
