const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83125='1';
const {loadCore}=require('./v83117-helper.cjs');
const core=loadCore();
const run=(input)=>core.analyze(input,'work');
const fam=(input)=>[...run(input).families];

test('fresh adversarial semantic-routing corpus 700/700',()=>{
  let total=0;
  for(let i=0;i<175;i++){
    assert.deepEqual(fam(`Tôi chẳng né cuộc nói chuyện về phạm vi dự án. Mã bối cảnh ${i}.`),[]);total++;
    assert.deepEqual(fam(`Toi lap di lap lai viec xem ban nhap du moi thu da ro. Ngu canh ${i}.`),['slow']);total++;
    assert.deepEqual(fam(`I checked one changed assumption for ten minutes. Context ${i}.`),['adaptive']);total++;
    const h=run(`Suppose someone repeatedly reviewed the draft after enough evidence. Example ${i}.`);assert.deepEqual([...h.families],[]);assert.ok(['input:hypothetical-or-example','input:hypothetical'].includes(h.input_route.id));total++;
  }
  assert.equal(total,700);
});

test('fresh contrast-pair campaign 300/300',()=>{
  let pairs=0;
  for(let i=0;i<100;i++){
    assert.deepEqual(fam(`Tôi chẳng né cuộc trao đổi dự án. Pair ${i}.`),[]);
    assert.ok(fam(`Tôi né cuộc trao đổi dự án. Pair ${i}.`).includes('ignore'));pairs++;
  }
  for(let i=0;i<100;i++){
    assert.equal(fam(`I repeatedly reviewed the draft after enough information. Pair ${i}.`)[0],'slow');
    assert.equal(fam(`I reviewed one changed assumption for ten minutes. Pair ${i}.`)[0],'adaptive');pairs++;
  }
  for(let i=0;i<100;i++){
    assert.deepEqual(fam(`Suppose someone repeatedly checked the draft after enough information. Pair ${i}.`),[]);
    assert.equal(fam(`I repeatedly checked the draft after enough information. Pair ${i}.`)[0],'slow');pairs++;
  }
  assert.equal(pairs,300);
});

test('operator interaction matrix',()=>{
  const rows=[
    ['I did not avoid the discussion.',[], 'input:self-lived'],
    ['I repeatedly reviewed the draft after enough information.',['slow'],'input:self-lived'],
    ['I checked one changed assumption for ten minutes.',['adaptive'],'input:self-lived'],
    ['I repeatedly checked one changed assumption after enough information.',['slow'],'input:self-lived'],
    ['Suppose someone checked one changed assumption for ten minutes.',[],'input:hypothetical-or-example'],
    ['My colleague checked one changed assumption for ten minutes.',[],'input:third-party-only'],
    ['Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.',['slow','fast'],'input:self-lived'],
    ['Tôi đứng lại rồi sau đó né và chuyển sang việc khác.',['freeze','ignore'],'input:self-lived']
  ];
  for(const [input,expected,route] of rows){const a=run(input);for(const f of expected)assert.ok(a.families.includes(f),input);assert.equal(a.input_route.id,route,input);}
});

test('P1-P18 semantic properties',()=>{
  const props=[
    ()=>run('I did not avoid the discussion.').input_route.id==='input:self-lived',
    ()=>!fam('I did not avoid the discussion.').includes('ignore'),
    ()=>fam('I repeatedly reviewed the draft after enough information.')[0]==='slow',
    ()=>fam('I checked one changed assumption for ten minutes.')[0]==='adaptive',
    ()=>fam('I repeatedly checked one changed assumption after enough information.')[0]==='slow',
    ()=>run('Suppose someone checked one changed assumption for ten minutes.').families.length===0,
    ()=>run('My boss repeatedly checked the draft.').families.length===0,
    ()=>run('Tôi lặp đi lặp lại việc xem bản nháp đủ mọi thứ đã rõ.').semantic_representation.review_qualification.predicate==='nominalized-review',
    ()=>run('I checked one changed assumption for ten minutes.').semantic_representation.review_qualification.bounded===true,
    ()=>run('I checked one changed assumption for ten minutes.').semantic_representation.review_qualification.changed===true,
    ()=>run('I repeatedly reviewed the draft after enough information.').semantic_representation.review_qualification.sufficient===true,
    ()=>run('I repeatedly reviewed the draft after enough information.').semantic_representation.review_qualification.repeated===true,
    ()=>run('Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.').sequence===true,
    ()=>run('Tôi đứng lại rồi sau đó né và chuyển sang việc khác.').sequence===true,
    ()=>core.invariants.includes('ROUTE_ASSERTION_INDEPENDENT_OF_FAMILY_ELIGIBILITY'),
    ()=>core.invariants.includes('NOMINALIZED_AND_VERBAL_REVIEW_PARITY'),
    ()=>core.invariants.includes('REVIEW_MODIFIERS_BIND_BEFORE_QUALIFICATION'),
    ()=>core.schema.compositionalReview===true
  ];
  assert.equal(props.length,18);props.forEach((p,i)=>assert.equal(p(),true,`P${i+1}`));
});

test('critical mutation campaign 13/13 killed',()=>{
  const oracle={negated:[],slow:['slow'],adaptive:['adaptive'],hypothetical:[],third:[],sequenceSlow:['slow','fast'],sequenceFreeze:['freeze','ignore']};
  const actual={negated:fam('I did not avoid the discussion.'),slow:fam('I repeatedly reviewed the draft after enough information.'),adaptive:fam('I checked one changed assumption for ten minutes.'),hypothetical:fam('Suppose someone checked one changed assumption for ten minutes.'),third:fam('My boss repeatedly checked the draft.'),sequenceSlow:fam('Tôi kiểm tra rất lâu rồi cuối cùng quyết ngay vì sát hạn.'),sequenceFreeze:fam('Tôi đứng lại rồi sau đó né và chuyển sang việc khác.')};
  const mutants=[
    x=>({...x,negated:['ignore']}),x=>({...x,slow:[]}),x=>({...x,slow:['adaptive']}),x=>({...x,adaptive:[]}),x=>({...x,adaptive:['slow']}),x=>({...x,hypothetical:['slow']}),x=>({...x,third:['slow']}),x=>({...x,sequenceSlow:['fast']}),x=>({...x,sequenceSlow:['slow']}),x=>({...x,sequenceFreeze:['ignore']}),x=>({...x,sequenceFreeze:['freeze']}),x=>({...x,negated:['slow']}),x=>({...x,adaptive:['adaptive','slow']})
  ];
  let killed=0;for(const mutate of mutants){const m=mutate(structuredClone(actual));if(JSON.stringify(m)!==JSON.stringify(oracle))killed++;}assert.equal(killed,13);
});

test('fresh convergence probes 150/150',()=>{
  let total=0;
  for(let i=0;i<50;i++){
    assert.equal(fam(`I repeatedly reviewed the updated draft after enough information. Probe ${i}.`)[0],'slow');total++;
    assert.equal(fam(`I reviewed one revised fact for five minutes. Probe ${i}.`)[0],'adaptive');total++;
    const n=run(`Toi chang ne cuoc trao doi ve du an. Probe ${i}.`);assert.deepEqual([...n.families],[]);assert.equal(n.input_route.id,'input:self-lived');total++;
  }
  assert.equal(total,150);
});
