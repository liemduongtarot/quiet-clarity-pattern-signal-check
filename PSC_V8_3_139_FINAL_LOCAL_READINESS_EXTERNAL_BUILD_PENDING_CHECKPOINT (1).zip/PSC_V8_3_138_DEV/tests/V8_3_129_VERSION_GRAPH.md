# V8.3.129 Version Graph

`V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE`
→ V8.3.122
→ V8.3.123 FAILED RC
→ V8.3.124 FAILED RC
→ V8.3.125 FAILED RC
→ V8.3.126 FAILED RC
→ V8.3.127 READY FOR MANUAL STEP 111 REVIEW
→ V8.3.128 FAILED RC
→ **V8.3.129 FAILED REVIEW CANDIDATE**

V8.3.129 provenance remains downstream of the reconstructed recovery baseline. It is not original V8.3.121 source recovery and does not alter the permanent V8.3.121 provenance-loss record.
