process.env.PSC_V83139='1';
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore, unaccent, mixedAccent } = require('./v83117-helper.cjs');
const core = loadCore();

const SEED = 83117091;
function rng(seed) {
  let value = seed >>> 0;
  return () => {
    value ^= value << 13; value ^= value >>> 17; value ^= value << 5;
    return (value >>> 0) / 4294967296;
  };
}

const fixtures = [
  ['slow', 'Tôi kiểm tra thêm và trì hoãn bắt đầu.', 'I keep checking and delay getting started.'],
  ['fast', 'Tôi quyết ngay và nhận quá nhiều việc.', 'I decide immediately and take on too much.'],
  ['freeze', 'Tôi bị đứng lại và không biết bắt đầu từ đâu.', 'I become stuck and cannot see where to begin.'],
  ['ignore', 'Tôi chuyển sang việc khác để né phần khó chịu.', 'I move to something else to avoid the uncomfortable part.'],
  ['adaptive', 'Tôi kiểm tra vừa đủ, dừng khi đủ thông tin và điều chỉnh khi có dữ kiện mới.', 'I check enough, stop when I have enough information and adjust when new evidence appears.'],
];
const noiseVi = ['Chuyện này đang xảy ra.', 'Tôi đang nhìn phản ứng của mình.', 'Có cả cảm xúc và điều kiện thực tế.', 'Nó liên quan tới một quyết định cụ thể.'];
const noiseEn = ['This is happening now.', 'I am examining my own response.', 'Both emotion and practical conditions are involved.', 'It concerns a specific decision.'];

test('seeded property run preserves family, IDs and non-empty question contracts', () => {
  const random = rng(SEED);
  const domains = core.topicOptions('vi').filter((row) => row.topic_id !== 'other').map((row) => row.topic_id);
  let executions = 0;
  const failures = [];
  for (let index = 0; index < 100000; index += 1) {
    const fixture = fixtures[Math.floor(random() * fixtures.length)];
    const english = random() > 0.75;
    let raw = `${english ? fixture[2] : fixture[1]} ${english ? noiseEn[Math.floor(random() * noiseEn.length)] : noiseVi[Math.floor(random() * noiseVi.length)]}`;
    if (!english && random() > 0.66) raw = random() > 0.5 ? unaccent(raw) : mixedAccent(raw);
    const domain = domains[Math.floor(random() * domains.length)];
    const frame = core.analyze(raw, domain);
    const family = frame.families[0] || 'unknown';
    const question = core.questions[Math.floor(random() * core.questions.length)];
    const options = core.options(frame, question, `v3:${fixture[0]}`);
    const recovery = core.questionRecoveryOptions(frame, question, `v3:${fixture[0]}`);
    if (family !== fixture[0] || options.length !== 10 || recovery.length !== 10 || options.some((row) => !row.semantic_id) || recovery.some((row) => !row.semantic_id)) failures.push({ index, fixture: fixture[0], family, domain, question });
    executions += 1;
  }
  assert.equal(executions, 100000);
  assert.deepEqual(failures, []);
});

test('metamorphic surfaces use independently locked expected family contracts', () => {
  for (const [expected, vi, en] of fixtures) {
    const surfaces = [vi, unaccent(vi), mixedAccent(vi), en];
    const contracts = surfaces.map((raw) => core.contract(core.analyze(raw, 'work'), {
      family: expected, clarification: `v3:${expected}`, explicitResponseClarification: true,
      answers: { E: [`v3:E:${expected}:1`] }, reinforcement: `v3:E:${expected}:1`,
      repetition: 3, enactment: 3, interruptibility: 3, trend: 3,
    }));
    assert.equal(contracts.every((contract) => contract.families[0] === expected), true, expected);
    assert.equal(new Set(contracts.map((contract) => contract.classification)).size, 1, expected);
  }
});
