/* V8.3.115 causal-composition audit: ontology, direction, gating, result and non-composition. */
/* eslint-disable @typescript-eslint/no-require-imports */
const fs=require('fs'),vm=require('vm'),html=fs.readFileSync('public/candidate.html','utf8');
let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}},document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}},c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);
const run=x=>vm.runInContext(x,c),checks={};

run(`S.area='work';S.sit='Dạo gần đây công việc của tôi thay đổi liên tục nên tôi thường cảm thấy quá tải, nhưng tôi chưa rõ cảm giác đó đang khiến mình phản ứng như thế nào.';S.clar='hyp:avoidance';S.r={A:['A1'],B:['B1'],C:['C1'],D:['D1'],E:['E1'],F:['F1'],G:['G1'],H:['H1']};S.i={rep:3,enact:3,interrupt:3,trend:3}`);
const syn=run('v2Synthesis()'),result=run('QCResultV2.buildResult(v2Synthesis(),v2Frame(),S.i)');
checks.reportedCaseComposes=syn.composite===true&&syn.components.join('|')==='ruminative_threat_fusion|avoidance_of_discomfort';
checks.causalTarget=syn.mechanism_statement.includes('khả năng xấu')&&syn.mechanism_statement.includes('trì hoãn');
checks.currentEvidenceRoute=run(`(S.step=(v2Synthesis().primary_mechanism&&v2Synthesis().primary_mechanism!=='conflict')?'imp':'res')`)==='imp';
checks.completeEvidenceClassifies=result.state.signal_state==='established_pattern';
checks.compositeHasConsequence=!!result.consequence&&result.consequence.text.includes('vòng lo–né')&&result.consequence.text.includes('phần việc');

const relations=run('JSON.parse(JSON.stringify(QCRecognitionV2.MECHANISM_RELATIONS))');
checks.allModelsHaveRoles=run('QCRecognitionV2.MODELS.every(m=>QCRecognitionV2.MECHANISM_META[m.id]&&QCRecognitionV2.MECHANISM_META[m.id].role)');
checks.relationMapCovered=relations.length===13;
for(const [a,b] of relations){
 const code=(order)=>`QCRecognitionV2.composeCandidates(${JSON.stringify(order.map(id=>({id,label:id,supporting_records:['A1']})))},[{question_id:'E',option_id:'E1',functional_tags:['reinforce_relief']}])`;
 const forward=run(code([a,b])),reverse=run(code([b,a]));
 checks[`direction_${a}_${b}`]=!!forward&&!!reverse&&forward.primary_mechanism===reverse.primary_mechanism&&forward.mechanism_statement===reverse.mechanism_statement;
}
const unrelated=run(`QCRecognitionV2.resolveCandidates([{id:'sunk_commitment_inertia',label:'sunk',supporting_records:['D5']},{id:'reactive_boundary_escalation',label:'reactive',supporting_records:['A7']}],{},[{question_id:'E',option_id:'E1',functional_tags:['reinforce_relief']}])`);
checks.unrelatedStaysConflict=unrelated.primary_mechanism==='conflict'&&!unrelated.composite;
const noReinforcement=run(`QCRecognitionV2.composeCandidates([{id:'ruminative_threat_fusion',label:'threat',supporting_records:['C1']},{id:'avoidance_of_discomfort',label:'avoid',supporting_records:['A1']}],[{question_id:'E',option_id:'E9',functional_tags:['reinforcement_interruptible']}])`);
checks.noReinforcementNoComposite=noReinforcement===null;
run(`S.r={A:['A9'],B:['B9'],C:['C9'],D:['D9'],E:['E9'],F:['F9'],G:['G9'],H:['H9']};S.i={rep:0,enact:0,interrupt:0,trend:0}`);
const adaptive=run('QCResultV2.buildResult(v2Synthesis(),v2Frame(),S.i)');checks.adaptiveException=adaptive.state.signal_state==='adaptive';
const failures=Object.entries(checks).filter(([,v])=>!v),total=Object.keys(checks).length;
console.log(JSON.stringify({version:'V8.3.115',stepRange:'36-47',total,passed:total-failures.length,failed:failures.length,failures:failures.map(([k])=>k),reportedCase:{mechanism:syn.mechanism_statement,state:result.state_label,consequence:result.consequence&&result.consequence.text}},null,2));
if(failures.length)process.exit(1);
