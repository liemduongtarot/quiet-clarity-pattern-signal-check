const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83135='1';
const core=require('./v83117-helper.cjs').loadCore();

test('frozen consumers derive family from canonical state, not the raw operator lexeme',()=>{
  const base=core.buildCanonicalState('Mỗi khi yêu cầu chưa rõ, tôi kiểm tra thêm và trì hoãn bắt đầu.');
  const mention=core.buildCanonicalState('Mỗi khi yêu cầu chưa rõ, tôi kiểm tra thêm và trì hoãn bắt đầu. Tôi không muốn hệ thống giả định động cơ.');
  const a=core.deriveCanonical(base),b=core.deriveCanonical(mention);
  assert.deepEqual([...b.families],[...a.families]);
  assert.equal(b.route.id,a.route.id);
  assert.equal(b.sequence.sequence,a.sequence.sequence);
});

test('non-governing occurrence cannot alter established proposition eligibility',()=>{
  const state=core.buildCanonicalState('When requirements are unclear, I keep checking and delay getting started. Do not assume my motive.');
  const behavioral=state.propositions.find(p=>p.predicate==='review');
  assert.ok(behavioral);
  assert.equal(behavioral.reality_status,'actual');
  const derived=core.deriveCanonical(state);
  assert.ok(derived.families.includes('slow'));
  assert.ok(!behavioral.suppression_reason.includes('NON_REAL'));
});

test('operator authority is singular and consumers remain frozen',()=>{
  const state=core.buildCanonicalState('Không giả sử tôi nghỉ việc; tôi vẫn kiểm tra lại.');
  assert.deepEqual([...state.authority_writes.operator_status],['scoped-operator-resolver']);
  assert.deepEqual([...state.authority_writes.frame_scope],['scoped-operator-resolver']);
  assert.deepEqual([...state.authority_writes.reality_status],['scoped-operator-resolver']);
  assert.equal(core.metadata.consumers,'FROZEN_FROM_V8.3.133');
});

test('five established families survive unknown explanatory fields; insufficient behavior stays unclassified',()=>{
  const cases=[
    ['I repeatedly checked the unchanged evidence after enough information.',' Do not assume my motive.','slow'],
    ['I deliberately left the message unopened.',' Do not infer my motive.','ignore'],
    ['I accepted the option before reviewing the relevant details.',' Do not assume my intent.','fast'],
    ['Despite enough information I remained unable to choose.',' Do not imagine my cause.','freeze'],
    ['I checked one revised estimate for five minutes.',' Do not infer my explanation.','adaptive']
  ];
  for(const [behavior,meta,family] of cases){
    const state=core.buildCanonicalState(behavior+meta),derived=core.deriveCanonical(state);
    assert.ok(derived.families.includes(family),`${family}: ${JSON.stringify(derived.families)}`);
  }
  assert.deepEqual([...core.deriveCanonical(core.buildCanonicalState('I looked at the item once. Do not assume my motive.')).families],[]);
});
