# V8.3.135 forensic analysis — V8.3.134 real-case replay

## Finding

The stated “three unknown fields” do not exist. The test runs four language surfaces per case. Its array is `[Vietnamese accented, Vietnamese unaccented, Vietnamese mixed, English]`. The first three entries are a test-generated sentinel from `frame.families[0] || 'unknown'`; they are not runtime family candidates and never participate in primary ranking.

All three Vietnamese forms contain `giả định động cơ` / `gia dinh dong co`. V8.3.132 added `giả định|gia dinh` to the global hypothetical regex. The frame resolver interprets the metalinguistic sentence “do not assume a motive” as a hypothetical discourse operator and scopes `HYPOTHETICAL_SETUP` over the whole document. Every behavioral proposition becomes `reality_status=hypothetical`; family eligibility is then suppressed with `NON_REAL`, and routing becomes `input:hypothetical-or-example`. English “assume a motive” does not match that regex and retains the expected family.

## Classification

- Exact failures: 24/24 reproduced.
- First divergence: canonical representation / frame resolution — 24.
- Ranking failures: 0.
- Primary-selection failures: 0.
- Serializer failures: 0.
- Gold-contract failures: 0 for family extraction.
- Cluster count: 1 — `META-LINGUISTIC-HYPOTHETICAL-LEXEME-COLLISION`.

## Evidence and expected-contract audit

The behavioral clause supports the expected response family in all 24 cases, confirmed by the English surface and by the same behavioral content before the Vietnamese metalinguistic clause changes document reality. These are family-routing development contracts, not final Pattern Signal classifications. They do not by themselves provide the questionnaire's complete reinforcement plus current-active evidence, so they must not be cited as full pattern-classification proof. No expected contract is changed.

Per-case evidence status is therefore identical across the matrix:

- behavioral response: observed and sufficient for the family-extraction contract;
- frequency/response structure: present where required by the corresponding family fixture;
- reinforcement evidence: not observed as a completed questionnaire gate;
- current-active evidence: not observed as a completed questionnaire gate;
- expected family contract: `EXPECTED_SUPPORTED` for this development test;
- final Pattern Signal classification: not established by these inputs and not claimed by the test.

## Descriptive versus explanatory authority

Behavior, frequency, sequence and current activity are descriptive facts. Motive, private intent and unobserved cause are explanatory facts. PSC may preserve an established behavioral family while declining to infer motive. `NOT_INFERRED motive` must not become a hypothetical operator and must not erase observed behavior.

## Direct-state diagnostics

Direct canonical states with an established slow, ignore, fast, freeze or adaptive family and unknown/not-inferred explanatory attributes retain their respective family. A state with no qualifying behavioral predicate returns no family. This confirms that the frozen family consumer already follows the intended principle when canonical reality is correct.

## Proposed invariants (not implemented)

- `KNOWN_BEHAVIOR_OUTRANKS_UNKNOWN_EXPLANATION`
- `UNKNOWN_FIELD_IS_NOT_A_FAMILY`
- `NOT_INFERRED_MOTIVE_DOES_NOT_ERASE_OBSERVED_BEHAVIOR`
- `INSUFFICIENT_BEHAVIORAL_EVIDENCE_CAN_BLOCK_CLASSIFICATION`
- `UNKNOWN_EXPLANATORY_EVIDENCE_CANNOT_BLOCK_CLASSIFICATION_BY_ITSELF`
- `METALINGUISTIC_MENTION_DOES_NOT_OPEN_HYPOTHETICAL_FRAME`
- `FRAME_SCOPE_MUST_BE_LICENSED_BY_OPERATOR_USE_NOT_LEXEME_MENTION`

## Verdict

**ARCHITECTURE REVIEW REQUIRED BEFORE V8.3.135**

The defect is not primary ranking, family evidence, or gold. It is operator-use versus metalinguistic-mention disambiguation plus document-frame scope in canonical representation. No source, harness, gold, pool or execution artifact was modified.
