/* V8.3.116 V3 integration: live state -> family questions -> reinforcement -> current classification. */
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const html=fs.readFileSync('public/candidate.html','utf8');let js=html.match(/<script>([\s\S]*)<\/script>/i)[1].replace(/window\.addEventListener\('pagehide',[\s\S]*?\nrender\(\);\s*$/,'');
const el={innerHTML:'',style:{},dataset:{},classList:{add(){},remove(){}}},document={body:{dataset:{},setAttribute(){},removeAttribute(){}},documentElement:{style:{setProperty(){}}},getElementById(){return el},querySelectorAll(){return[]},createElement(){return{...el,click(){}}}},c={console,document,window:null,globalThis:null,navigator:{},Blob(){},URL:{createObjectURL(){return''},revokeObjectURL(){}},setTimeout,clearTimeout};c.window=c;c.globalThis=c;c.scrollTo=()=>{};c.addEventListener=()=>{};vm.createContext(c);new vm.Script(js).runInContext(c);const run=x=>vm.runInContext(x,c);
test('slow case never exposes fast response and reaches established result',()=>{
 run(`S.semanticV3=true;S.area='work';S.sit='Mỗi khi nhận nhiệm vụ mới mà yêu cầu chưa rõ, tôi sợ làm sai nên cứ kiểm tra thêm và trì hoãn bắt đầu.';S.clar='c1';S.r={A:['A1'],B:['B1'],C:['C1'],D:['D1'],E:['E1'],F:['F1'],G:['G1'],H:['H1']};S.i={rep:3,enact:3,interrupt:3,trend:3}`);
 const q1=run(`questionOptions('A')`),q5=run(`questionOptions('E')`),syn=run(`v2Synthesis()`);
 assert.equal(q1.length,10);assert.equal(q1.some(x=>/chốt ngay|quyết ngay|xử lý thật nhanh/.test(x)),false);assert.match(q1[2],/thu thập thông tin/);assert.match(q5[0],/giảm khó chịu/);assert.equal(syn.v3.classification,'established_pattern');assert.equal(syn.v3.family,'slow');assert.match(syn.v3.consequence,/tiếp tục bị đẩy lại/);
});
test('external constraint and adaptive evidence do not become patterns',()=>{
 run(`S.semanticV3=true;S.area='work';S.sit='Tôi không bắt đầu vì đang chờ phê duyệt và chưa có quyền quyết định.';S.clar='v3:freeze';S.r={A:['A8'],B:['B9'],C:['C9'],D:['D9'],E:['E9'],F:['F9'],G:['G9'],H:['H9']};S.i={rep:null,enact:null,interrupt:null,trend:null}`);
 assert.equal(run(`v2Synthesis().v3.classification`),'external_or_capacity_constraint');assert.equal(run(`v2Synthesis().primary_mechanism`),null);
 run(`S.sit='Toi xem lai vua du, dung khi da du thong tin va dieu chinh khi co du kien moi.';S.clar='v3:adaptive';S.r={A:['A9'],B:['B9'],C:['C9'],D:['D9'],E:['E9'],F:['F9'],G:['G9'],H:['H9']}`);
 assert.equal(run(`QCSemanticCoreV3.analyze(S.sit,'work').language`),'vi');assert.equal(run(`v2Synthesis().v3.classification`),'adaptive');
});
