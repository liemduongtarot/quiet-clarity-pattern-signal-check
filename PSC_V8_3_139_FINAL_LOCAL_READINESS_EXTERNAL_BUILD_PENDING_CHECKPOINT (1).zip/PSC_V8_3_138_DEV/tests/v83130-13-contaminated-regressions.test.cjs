const test=require('node:test'),assert=require('node:assert/strict');
process.env.PSC_V83130='1';const{loadCore}=require('./v83117-helper.cjs');const core=loadCore();
const cases=[
['V129-C003','Trong vi du khong co that, mot nhac cong thu lai ban thu am tuong tuong.','input:hypothetical-or-example',[],false],
['V129-C005','My neighbour reread the landlord’s notice once before filing it.','input:third-party-only',[],false],
['V129-C008','Bạn cùng nhà của tôi checked lịch giao hàng của anh ấy.','input:third-party-only',[],false],
['V129-C013','I could not submit the form because the government portal was offline.','input:self-lived',[],false],
['V129-C016','Tôi cannot hoàn tất bước đó vì giấy phép bắt buộc chưa được cấp.','input:self-lived',[],false],
['V129-C017','I muted the complaint thread so I would not have to read the latest reply.','input:self-lived',['ignore'],false],
['V129-C018','Tôi gấp thông báo lại và để nguyên vì không muốn xử lý nội dung bên trong.','input:self-lived',['ignore'],false],
['V129-C023','Khong co thong tin moi nhung toi cu mo lai cung mot ho so.','input:self-lived',['slow'],false],
['V129-C027','I accepted the first vendor quote before reading the supporting breakdown.','input:self-lived',['fast'],false],
['V129-C030','Tôi instantly chọn đề xuất đầu khi chưa đọc phần giải trình.','input:self-lived',['fast'],false],
['V129-C033','Toi dung yen du thong tin da du de dua ra quyet dinh.','input:self-lived',['freeze'],false],
['V129-C034','Dù hồ sơ complete, tôi vẫn bị khựng và không chọn được bước tiếp theo.','input:self-lived',['freeze'],false],
['V129-C036','Tôi chỉ đối chiếu số liệu vừa cập nhật trong mười phút rồi tiếp tục công việc.','input:self-lived',['adaptive'],false]
];
for(const[id,raw,route,families,sequence]of cases)test(`${id} contaminated historical regression`,()=>{const frame=core.analyze(raw,'work');assert.deepEqual({route:frame.input_route.id,families:[...frame.families],sequence:!!frame.sequence},{route,families,sequence});});
