const test=require('node:test'),assert=require('node:assert/strict');process.env.PSC_V83131='1';const core=require('./v83117-helper.cjs').loadCore();
const check=(raw,families,route='input:self-lived')=>{const a=core.analyze(raw,'work');assert.deepEqual([...a.families],families,raw);assert.equal(a.input_route.id,route,raw);assert.equal(a.canonical_shadow.invariant_violations.length,0,raw);};
test('480 focused compositional development cases',()=>{let n=0;for(let i=0;i<40;i++){
 check(`My cousin reviewed ledger ${i}.`,[],'input:third-party-only');n++;
 check(`Người quen của tôi xem sổ kho ${i}.`,[],'input:third-party-only');n++;
 check(`In an imaginary scenario, a keeper checked map ${i}.`,[],'input:hypothetical-or-example');n++;
 check(`Trong một chuyện minh họa không có thật, người giữ đèn xem bản đồ ${i}.`,[],'input:hypothetical-or-example');n++;
 check(`I muted notice ${i} so that I would not have to read it.`,['ignore']);n++;
 check(`Tôi cất thư ${i} để khỏi nhìn nội dung.`,['ignore']);n++;
 check(`I reviewed unchanged record ${i} multiple passes.`,['slow']);n++;
 check(`Tôi rà biên bản ${i} nhiều lượt không có thay đổi.`,['slow']);n++;
 check(`I signed order ${i} without examining the annex.`,['fast']);n++;
 check(`Tôi cam kết lịch ${i} trước khi xem điều kiện.`,['fast']);n++;
 check(`I reviewed corrected figure ${i} in one pass.`,['adaptive']);n++;
 check(`Tôi xem số liệu mới sửa ${i} trong một lượt.`,['adaptive']);n++;
}assert.equal(n,480);});
