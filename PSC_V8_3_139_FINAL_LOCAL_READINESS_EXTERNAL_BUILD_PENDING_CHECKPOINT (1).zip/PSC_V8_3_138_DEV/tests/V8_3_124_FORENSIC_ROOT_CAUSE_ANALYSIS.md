# V8.3.124 Forensic Root-Cause Analysis

Status: **ROOT CAUSE FROZEN BEFORE SOURCE CHANGE**

Parent authority: `V8.3.123 FAILED REVIEW CANDIDATE` at commit `1604a917c401ebc79edbb98019cca926d923b426`.

The V8.3.123 sealed Batch A evidence remains immutable. Batch A was not rerun, Batch B was not run, and no V8.3.123 expected contract was changed.

## Root-cause table

| Case | Surface / language | Clause structure | Canonical propositions | Predicate normalization | Negation / reality operator | Evidence / modifier state | Expected activation and route | V8.3.123 actual | Where the contract was lost | Failure class | Architectural repair required |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V123-A09 | English | Two coordinated propositions in one inherited phase: negated non-engagement; bounded review of updated evidence | P1 `avoid-engagement`, negative; P2 `proportionate-review`, positive | Both predicates normalize successfully | `never` must bind to `sidestepped` only; it must not negate P2 | P2 is bounded and supported by updated evidence | `adaptive`; `input:self-lived` | `adaptive → ignore`; self-lived | Predicate extraction recognizes `sidestep`, but the negation matcher does not use the same ontology and omits `sidestep`. P1 is emitted positive/active. Loss is at modifier/negation scope before family activation. | E: predicate/operator vocabulary divergence; clause-local scope not represented | Use one canonical predicate lexicon for extraction and polarity binding. Represent clause-local operators before activation. A negative P1 must be retained as suppressed evidence while positive P2 remains active. |
| V123-A13 | Vietnamese unaccented | One behavioral clause followed by terminal aspect/sequence token `rồi`: repeated additional consultation despite already sufficient evidence | P1 `seek-more-input`, positive, repeated, evidence sufficient | Parent correctly normalizes P1 to slow | No negation; `rồi` is not a new behavioral phase here | `đủ / mọi thứ đã rõ rồi` establishes sufficiency; repeated additional consultation is slow, not adaptive evidence gathering | `slow`; `input:self-lived` | `slow → adaptive`; self-lived | Phase refinement splits on terminal `roi`, leaving `... da ro`; the new layer recomputes evidence state from the truncated text and fails to inherit parent `sufficient`. It then emits `gather-missing-evidence`. Cross-layer merge keeps both conflicting candidates because no evidence-status precedence resolves them. | G/F: lossy segmentation plus evidence/adaptive precedence conflict | Preserve inherited operator/evidence annotations through phase refinement. Do not split terminal/aspectual `rồi` without a following proposition. Add same-proposition exclusivity: `sufficient + repeated seek` activates slow and explicitly suppresses adaptive `gather-missing-evidence`. |
| V123-A26 | English | Hypothetical frame governing a third-person behavioral proposition | P1 `repeated-checking`, hypothetical/non-self evidence | Predicate normalization succeeds | `suppose` scopes over the whole proposition; no behavioral family may activate | Evidence sufficiency unspecified; frequency repeated; reality is hypothetical | no family; `input:hypothetical-or-example` | `slow`; `input:hypothetical` | The routed canonical row is initially marked hypothetical and suppressed correctly. Family-preservation then sees parent `slow` missing and synthesizes `excessive-review` with a blank state object (`hypothetical:false`, self actor), reactivating the family. Final analyze blocks only third-party, not hypothetical. Separately, no route-contract normalization maps the engine's internal hypothetical route to the locked public contract ID. | D/H: fallback bypasses operator suppression; route taxonomy not canonicalized | Synthetic preservation must clone proposition operator context and may never create a real/self proposition from suppressed hypothetical evidence. Final routing must block all non-self/non-real frames. Introduce a stable public route contract mapping `hypothetical/example → input:hypothetical-or-example` without changing the locked expected contract. |

## Stage classification

| Case | A predicate missing | B family failed to activate | C sequence dropped | D wrong precedence/suppression | E modifier scope | F adaptive override | G segmentation | H other |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| V123-A09 | No | No | No | Yes | **Yes** | No | Clause boundary not represented | Canonical lexicon divergence |
| V123-A13 | No | No | No | **Yes** | No | **Yes** | **Yes** | Operator annotation not propagated |
| V123-A26 | No | No | No | **Yes** | No | No | No | **Fallback state fabrication + route taxonomy gap** |

## Shared architectural gap

All three failures are manifestations of **LOSSY OPERATOR-CONTEXT PROPAGATION ACROSS PROPOSITION SOURCES**.

V8.3.123 merges propositions from three authorities:

1. routed canonical predicates inherited from V8.3.122;
2. predicates extracted by the V8.3.123 grammar;
3. synthetic routed-family preservation fallbacks.

The merge key is effectively predicate/family presence. It does not first reconcile a single authoritative proposition context containing clause-local polarity, reality, actor, evidence sufficiency, frequency and constraint. Consequently:

- lexical normalization and negation binding can disagree;
- phase refinement can discard an operator token and recompute weaker state;
- mutually exclusive slow/adaptive candidates can remain active together;
- fallback synthesis can fabricate `real/self/unspecified` context and undo a valid suppression;
- internal input-route labels can leak past the locked public route contract.

This is an operator architecture defect, not an exact-phrase coverage problem.

## V8.3.124 repair contract

Before family activation, V8.3.124 must construct one operator-complete proposition record per clause and enforce:

1. **CANONICAL_LEXEME_OPERATOR_PARITY** — any lexeme that normalizes to a predicate is addressable by polarity/cessation scope through that same canonical mapping.
2. **OPERATOR_CONTEXT_MONOTONICITY** — inherited `hypothetical`, third-party, external, ceased, negative and evidence-status annotations cannot be weakened by refinement, merge or fallback.
3. **FALLBACK_MUST_NOT_FABRICATE_CONTEXT** — a preservation fallback must clone the source proposition context and suppression state; if no source proposition exists, it may not activate a family.
4. **SAME_PROPOSITION_FAMILY_EXCLUSIVITY** — mutually exclusive interpretations such as `seek-more-input` and `gather-missing-evidence` require an explicit evidence-grounded winner and documented suppression reason.
5. **TERMINAL_OPERATOR_IS_NOT_A_PHASE** — a sequence/aspect token creates a boundary only when a non-empty behavioral clause follows it.
6. **NON_REAL_OR_NON_SELF_FINAL_BLOCK** — hypothetical/example and third-party propositions cannot produce self-family responses.
7. **PUBLIC_ROUTE_CONTRACT_STABILITY** — internal route variants normalize to the locked external route taxonomy before contract comparison.

## Required regression obligations

The exact V123-A09, A13 and A26 definitions are now **CONTAMINATED REGRESSION**, never pristine holdout evidence. V8.3.124 must also add family-level replacements covering:

- negated synonyms across the full ignore ontology while an adjacent positive adaptive proposition survives;
- terminal Vietnamese `rồi` versus true `rồi + behavioral clause`, including accented, unaccented and mixed surfaces;
- sufficient-evidence consultation versus genuinely missing-evidence consultation;
- hypothetical, example and quoted non-self frames passing through routed-family preservation;
- route-contract normalization independent of behavioral-family suppression.

No source, parser, schema, expected contract or V8.3.123 sealed evidence was modified during this analysis.
