const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PSC_V83135='1';
const core=require('./v83117-helper.cjs').loadCore();

const one=(input)=>core.analyze(input);

test('Level 1: meta-linguistic assumption mention is not a reality frame',()=>{
  for(const input of [
    'Tôi kiểm tra thêm và trì hoãn bắt đầu. Tôi không muốn hệ thống giả định động cơ.',
    'Toi kiem tra them va tri hoan bat dau. Toi khong muon he thong gia dinh dong co.',
    'I keep checking and delay starting. Do not let the system assume my motive.'
  ]){
    const result=one(input),op=result.operator_occurrences[0];
    assert.ok(op);
    assert.ok(['NEGATED_OPERATOR','PROHIBITED_OPERATOR','LEXICAL_MENTION'].includes(op.operator_status));
    assert.equal(op.complement_type,'NOMINAL_OBJECT');
    assert.equal(op.scope_type,'NONE');
    assert.equal(result.canonical_semantic_state.frames.length,0);
    assert.ok(result.canonical_semantic_state.propositions.every(p=>p.reality_status==='actual'));
  }
});

test('Level 1: active hypothetical, example, conditional, quote and report have bounded scope',()=>{
  const hypothetical=one('Giả sử tôi nghỉ việc, tôi sẽ trì hoãn quyết định.');
  assert.equal(hypothetical.operator_occurrences[0].operator_status,'ACTIVE_OPERATOR');
  assert.equal(hypothetical.operator_occurrences[0].scope_type,'LOCAL');
  assert.ok(hypothetical.canonical_semantic_state.propositions.some(p=>p.reality_status==='hypothetical'));
  const example=one('Trong ví dụ không có thật, một bác sĩ chọn phương án A.');
  assert.equal(example.canonical_semantic_state.propositions[0].reality_status,'example');
  const conditional=one('If I had left yesterday, I would have missed it.');
  assert.ok(conditional.canonical_semantic_state.propositions.every(p=>p.reality_status==='hypothetical'));
  const quoted=one('He said, "suppose I leave; I would delay." I decide quickly now.');
  assert.equal(quoted.operator_occurrences[0].scope_type,'QUOTED');
  assert.ok(quoted.canonical_semantic_state.propositions.some(p=>p.reality_status!=='hypothetical'));
});

test('Level 1: a prohibited mention does not suppress a later independent operator',()=>{
  const result=one('Đừng giả định động cơ. Giả sử tôi nghỉ việc, tôi sẽ trì hoãn.');
  assert.equal(result.operator_occurrences.length,2);
  assert.equal(result.operator_occurrences[0].operator_status,'PROHIBITED_OPERATOR');
  assert.equal(result.operator_occurrences[0].scope_type,'NONE');
  assert.equal(result.operator_occurrences[1].operator_status,'ACTIVE_OPERATOR');
  assert.equal(result.operator_occurrences[1].scope_type,'LOCAL');
});

test('Level 1: operator invariants are enforced',()=>{
  for(const input of [
    'Tôi không muốn hệ thống giả định động cơ.',
    'Đừng tưởng tượng nguyên nhân của tôi.',
    'Suppose I leave tomorrow.',
    'For example, I review the file once.'
  ]) assert.equal(one(input).canonical_shadow.invariant_violations.length,0);
});
