(function(global){
'use strict';
const parent=global.QCSemanticCoreV4;
if(!parent||parent.version!=='V8.3.125-SEMANTIC-ROUTING-REVIEW-QUALIFICATION-CANDIDATE')throw new Error('V8.3.126 requires frozen V8.3.125 failed RC');
const VERSION='V8.3.126-PUBLIC-ROUTE-CANONICALIZATION-CANDIDATE';
const metadata=Object.freeze({version:VERSION,parent:'V8.3.125 FAILED REVIEW CANDIDATE',target:'public route canonicalization + cross-surface taxonomy parity',production_authorized:false,step_111:'prohibited'});
const PUBLIC_ROUTES=Object.freeze(['input:empty','input:safety','input:prediction','input:decision-request','input:self-lived','input:hypothetical-or-example','input:third-party-only','input:external-only','input:invalid','input:clarification-required']);
const PRIORITY_ROUTES=new Set(['input:empty','input:safety','input:prediction','input:decision-request','input:invalid','input:clarification-required','input:external-only']);
const NONREAL=new Set(['hypothetical','conditional-hypothetical','counterfactual','example','hypothetical-or-example']);
const THIRD=new Set(['third-party','quoted-third-party','attributed-third-party']);
function canonicalPublicRoute(internalRoute,semantic){
  const route={...(internalRoute||{id:'input:clarification-required',action:'clarify',must_stop:false,must_redirect:false})};
  if(PRIORITY_ROUTES.has(route.id))return route;
  const assertion=semantic&&semantic.route_assertion||{};
  const propositions=semantic&&semantic.propositions||[];
  const realities=new Set([assertion.reality,...propositions.map(x=>x.reality_status)].filter(Boolean));
  const ownerships=new Set([assertion.ownership,...propositions.map(x=>x.ownership)].filter(Boolean));
  const nonreal=[...realities].some(x=>NONREAL.has(x));
  const realSelf=assertion.positive_self_lived_assertion||propositions.some(x=>x.reality_status==='real-self-lived'&&x.ownership==='self');
  if(nonreal&&!realSelf)return{...route,id:'input:hypothetical-or-example',action:'redirect',must_stop:false,must_redirect:true};
  if(THIRD.has(assertion.actor)||THIRD.has(assertion.ownership)||ownerships.has('third-party'))return{...route,id:'input:third-party-only',action:'clarify',must_stop:false,must_redirect:false};
  if(realSelf||assertion.reality==='real'&&assertion.ownership==='self')return{...route,id:'input:self-lived',action:'continue',must_stop:false,must_redirect:false};
  if(route.id==='input:hypothetical')return{...route,id:'input:hypothetical-or-example',action:'redirect',must_stop:false,must_redirect:true};
  if(['input:third-party','input:attributed-third-party','input:attributed-self-disputed','input:attributed-self-unconfirmed'].includes(route.id))return{...route,id:'input:third-party-only',action:'clarify',must_stop:false,must_redirect:false};
  return PUBLIC_ROUTES.includes(route.id)?route:{...route,id:'input:clarification-required',action:'clarify',must_stop:false,must_redirect:false};
}
function analyze(raw,domain='other',subtopic=null){
  const inherited=parent.analyze(raw,domain,subtopic),internal={id:inherited.input_route.id,reality_status:inherited.semantic_representation&&inherited.semantic_representation.route_assertion&&inherited.semantic_representation.route_assertion.reality},route=canonicalPublicRoute(inherited.input_route,inherited.semantic_representation),blocked=['input:hypothetical-or-example','input:third-party-only'].includes(route.id);
  const semantic={...inherited.semantic_representation,public_route_canonicalization:{internal,public_route_id:route.id,rule_source:'V8_3_126_PUBLIC_ROUTE_CANONICAL_MAPPING'}};
  return{...inherited,version:VERSION,metadata,input_route:route,semantic_representation:semantic,responses:blocked?[]:inherited.responses,families:blocked?[]:inherited.families,sequence:blocked?false:inherited.sequence,oscillation:blocked?false:inherited.oscillation,response_known:blocked?false:inherited.response_known,can_continue:route.action==='continue',must_stop:!!route.must_stop,must_redirect:!!route.must_redirect};
}
function inputRoute(raw){return analyze(raw).input_route;}
function evaluate(frame,evidence={}){const inherited=parent.evaluate(frame,evidence),clarify=['input:hypothetical-or-example','input:third-party-only'].includes(frame.input_route.id);return{...inherited,version:VERSION,...(clarify?{classification:'clarification_required',pattern_claim_allowed:false,must_stop:false,must_redirect:false}:{})};}
function contract(frame,evidence={}){const r=evaluate(frame,evidence);return{topic_id:frame.topic_id,input_route:frame.input_route.id,families:[...frame.families],sequence:frame.sequence,propositions:frame.semantic_representation.propositions,classification:r.classification,pattern_claim_allowed:r.pattern_claim_allowed,must_stop:!!r.must_stop,must_redirect:!!r.must_redirect};}
const invariants=Object.freeze([...(parent.invariants||[]),'PUBLIC_ROUTE_MUST_BE_CANONICAL','ANALYZE_AND_INPUT_ROUTE_TAXONOMY_PARITY','INTERNAL_REALITY_SUBTYPE_PRESERVED']);
global.QCSemanticCoreV4={...parent,version:VERSION,metadata,PUBLIC_ROUTES,canonicalPublicRoute,analyze,inputRoute,evaluate,contract,invariants,schema:Object.freeze({...parent.schema,semanticVersion:'public-route-canonicalization-v1',publicRouteEnum:[...PUBLIC_ROUTES],internalRealitySubtypePreserved:true})};
})(typeof globalThis!=='undefined'?globalThis:this);
