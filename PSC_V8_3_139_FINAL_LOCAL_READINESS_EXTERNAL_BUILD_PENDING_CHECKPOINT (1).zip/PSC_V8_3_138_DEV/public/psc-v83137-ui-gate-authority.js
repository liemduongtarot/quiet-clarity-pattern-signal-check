(function (global) {
  'use strict';

  const VERSION = 'V8.3.137-UI-GATE-AUTHORITY-RECONCILIATION';
  const metadata = Object.freeze({
    version: VERSION,
    runtime_authority: 'V8.3.135-SCOPED-OPERATOR (unchanged)',
    parent_evidence: 'V8.3.136 failed Browser E2E case V135-C008',
    classification: 'SINGLE CANONICAL UI GATE AUTHORITY',
    recovery_note: 'V8.3.136 byte-identical source was unavailable after workspace maintenance; this successor changes UI integration only',
    runtime_semantics_changed: false,
    parser_schema_changed: false,
    expected_contracts_changed: false,
    production_authorized: false,
    production_lock: 'prohibited',
    sealed_validation: 'not-authorized',
    step_111: 'prohibited'
  });

  function resolveSituationGate(core, raw, legacyGate = null) {
    if (!core || typeof core.inputRoute !== 'function') {
      throw new Error('V8.3.137 UI authority requires the frozen canonical runtime');
    }

    const route = core.inputRoute(raw);

    if (route.id === 'input:safety') {
      return { route, gate: 'safety', authority: 'canonical-route' };
    }
    if (route.action === 'continue') {
      return { route, gate: null, authority: 'canonical-route' };
    }

    let gate;
    if (route.id === 'input:hypothetical-or-example') gate = 'hypothetical';
    else if (route.id === 'input:decision-request') gate = 'choice';
    else if (route.id === 'input:prediction') gate = legacyGate === 'timing' ? 'timing' : 'prediction';
    else if (route.id === 'input:clarification-required' && ['empty', 'vague'].includes(legacyGate)) gate = legacyGate;
    else gate = 'other';

    return { route, gate, authority: 'canonical-route' };
  }

  global.PSCUIAuthorityV83137 = Object.freeze({
    version: VERSION,
    metadata,
    resolveSituationGate
  });

  if (global.document && global.document.documentElement) {
    global.document.documentElement.dataset.pscUiAuthority = 'V8.3.137:canonical-route-gate';
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
