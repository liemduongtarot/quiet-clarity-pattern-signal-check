(function (global) {
  'use strict';

  const parent = global.QCSemanticCoreV4;
  if (!parent || parent.version !== 'V8.3.121-R1-RECONSTRUCTED') throw new Error('V8.3.122 requires the reconstructed recovery baseline');

  const VERSION = 'V8.3.122-OPERATOR-AWARE-REVIEW-CANDIDATE';
  const fold = (value) => global.QCSemanticCoreV3.fold(value).replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim();
  const metadata = Object.freeze({
    version: VERSION,
    parent: 'V8.3.121-R1-RECONSTRUCTED RECOVERY BASELINE',
    target: 'operator-aware semantic normalization + predicate ontology upgrade',
    production_authorized: false,
    step_111: 'manual-only',
  });

  const OPERATOR_PRECEDENCE = Object.freeze([
    'reality-status', 'ownership', 'attribution-quotation', 'clause-segmentation', 'negation',
    'temporal', 'constraint', 'evidence-sufficiency', 'predicate-normalization', 'modifier-scope',
    'frequency-repetition', 'family-routing', 'sequence-construction', 'reinforcement-current-evidence', 'classification',
  ]);

  const ONTOLOGY = Object.freeze({
    fast: Object.freeze(['premature-decide', 'rush-to-close', 'act-before-needed-evidence', 'immediate-resolution-seeking']),
    slow: Object.freeze(['excessive-review', 'repeated-checking', 'seek-more-input', 'revisit-evidence', 'delay-after-sufficiency', 'over-deliberate']),
    freeze: Object.freeze(['unable-to-act', 'unable-to-decide', 'unable-to-respond', 'stuck-in-place', 'action-blocked']),
    ignore: Object.freeze(['avoid-engagement', 'leave-unopened', 'leave-unread', 'disengage', 'avoid-response', 'avoid-contact']),
    adaptive: Object.freeze(['proportionate-review', 'required-check', 'required-approval', 'gather-missing-evidence', 'bounded-review', 'reasonable-wait', 'evidence-threshold-not-met']),
  });

  const LEXEMES = Object.freeze({
    negation: /\b(?:not|never|wasn'?t|weren'?t|isn'?t|didn'?t|don'?t|doesn'?t|khong|chẳng|chua)\b/i,
    cessation: /\b(?:no longer|not anymore|used to|stopped?|khong con|truoc day|tung)\b/i,
    repetition: /\b(?:keep|kept|keeps|repeatedly|again and again|over and over|continually|cu|lap di lap lai|nhieu lan)\b/i,
    bounded: /\b(?:once|one time|briefly|for \d+ minutes?|mot lan|một lần|chut|gioi han)\b/i,
    sufficient: /\b(?:enough|sufficient|already clear|nothing changed|da du|du thong tin|ro roi)\b/i,
    newEvidence: /\b(?:new|changed|updated|additional)\s+(?:evidence|information|detail|fact)s?\b|\b(?:du kien|thong tin|chi tiet) moi\b/i,
    noNewEvidence: /\b(?:no|without)\s+(?:new|changed|updated|additional)\s+(?:evidence|information|detail|fact)s?\b|\b(?:nothing|none)\s+changed\b|\b(?:khong co|khong)\s+(?:du kien|thong tin|chi tiet) moi\b/i,
    external: /\b(?:file|system|device|network)\b.{0,35}\b(?:corrupt|broken|down|error|failed)\b|\b(?:surgery|driving|emergency|hospital|phau thuat|cap cuu)\b|\b(?:no authority|not authorised|not authorized|not permitted|khong co quyen|khong duoc quyen)\b/i,
  });

  const SURFACE_RULES = Object.freeze([
    ['leave-unengaged', /\b(?:leav\w*|left|put|set)\b.{0,40}\b(?:unopened|unread|aside|sitting there|alone)\b|\b(?:de|bo)\b.{0,35}\b(?:khong mo|chua xem|khong doc|do)\b/i],
    ['avoid-engagement', /\b(?:avoid\w*|disengag\w*|withdraw\w*|ne|tranh mat|khong dung toi|bo qua)\b/i],
    ['review', /\b(?:review\w*|check\w*|revisit\w*|overthink\w*|re-read|reread|xem lai|kiem tra|doi chieu|can nhac|nghi qua nhieu)\b/i],
    ['delay', /\b(?:delay\w*|procrastinat\w*|tri hoan|cham bat dau)\b/i],
    ['seek-input', /\b(?:ask\w*|seek\w*|consult\w*|hoi)\b.{0,30}\b(?:opinion|input|advice|view|y kien)\b/i],
    ['inability-decision', /\b(?:could not|couldn'?t|cannot|can'?t|unable to|khong the|chang biet)\b.{0,28}\b(?:decide|choose|settle|quyet|chon|lam sao)\b|\bkhong\s+(?:the\s+)?(?:quyet|chon)(?:\s+(?:duoc|noi))?\b/i],
    ['inability-action', /\b(?:could not|couldn'?t|cannot|can'?t|unable to|khong the|chang biet)\b.{0,28}\b(?:act|respond|move forward|do anything|hanh dong|phan ung|lam gi)\b|\bkhong\s+(?:hanh dong|phan ung|lam gi)(?:\s+duoc|\s+noi)?\b/i],
    ['stuck', /\b(?:froze|frozen|stuck|got stuck|stood still|bi ket|dung im)\b/i],
    ['fast-action', /\b(?:decid\w*|act\w*|respond\w*|close\w*|resolve\w*|chot|quyet|lam|phan hoi|xu ly)\b.{0,32}\b(?:immediately|straight away|too soon|quick\w*|hastily|ngay|voi|qua som|cho xong)\b|\b(?:made|make|reached?|took)\b.{0,18}\b(?:quick|immediate|hasty)\b.{0,12}\bdecision\b/i],
  ]);

  const TEMPORAL = Object.freeze([
    ['before', /\b(?:before|truoc)\b/i], ['after', /\b(?:after|afterwards|sau)\b/i],
    ['then', /\b(?:then|next|subsequently|roi|tiep theo)\b/i], ['later', /\b(?:later|eventually|cuoi cung)\b/i],
    ['return-to', /\b(?:revisit\w*|return\w* to|resume\w*|quay lai|xem lai|tro lai)\b/i],
    ['cessation', LEXEMES.cessation], ['still', /\b(?:still|van)\b/i], ['until', /\b(?:until|cho den khi)\b/i], ['while', /\b(?:while|trong khi)\b/i],
  ]);

  function normalizeSurface(raw) {
    const normalized = fold(raw)
      .replace(/\bko\b|\bk0\b|\bhok\b/g, 'khong')
      .replace(/\bcant\b/g, "can't")
      .replace(/\bcouldnt\b/g, "couldn't")
      .replace(/\bdidnt\b/g, "didn't")
      .replace(/\bwont\b/g, "won't");
    return { raw: String(raw || ''), folded: normalized, language: global.QCSemanticCoreV3.locale(raw) };
  }

  function parseAttribution(text) {
    const prefixed = text.match(/^(?:according to|in)\s+(.+?)(?:'s view|[:,])\s*(.+)$/i) ||
      text.match(/^(?:based on|as described by)\s+(.+?)(?:'s account)?[:,]\s*(.+)$/i) ||
      text.match(/^(?:theo(?: loi)?|dua theo)\s+(.+?)[,:]\s*(.+)$/i);
    const reported = text.match(/^(.+?)\s+(?:said|says|told me|reported|described|noi rang|bao rang)\s+(.+)$/i);
    const match = prefixed || reported;
    if (!match) return { type: 'direct-self-report', source: null, claim: text, selfConfirmed: true, disputed: false };
    const source = match[1].trim();
    const claim = match[2].trim();
    const disputed = /\b(?:but|however|nhung)\b.{0,70}\b(?:don'?t think|do not think|disagree|not true|khong nghi|khong dung)\b/i.test(text);
    const confirmed = /\b(?:and i agree|which i agree|toi dong y|dung vay)\b/i.test(text);
    const thirdPartyPossessive = /^(?!toi\b|minh\b)(?:[a-z]+\s+){1,4}(?:toi|minh)\s+(?:keep|kept|usually|always|often|cu|hay|thuong|kiem tra|ne|quyet)\b/i.test(claim);
    const selfSubject = !thirdPartyPossessive && (/^(?:i|toi|minh)\b/i.test(claim) || /\b(?:i|toi|minh)\s+(?:keep|kept|usually|always|often|cu|hay|thuong)\b/i.test(claim));
    return { type: selfSubject ? 'attributed-self' : 'attributed-third-party', source, claim, selfConfirmed: confirmed, disputed };
  }

  function segmentClauses(text) {
    const connector = /\s*(?:[,;]\s*)?\b(then|and then|after that|afterwards|later|eventually|next|subsequently|roi|sau do|sau đó|cuoi cung|tiep theo)\b\s*/gi;
    const phases = [];
    let start = 0;
    let relation = 'start';
    let match;
    while ((match = connector.exec(text)) !== null) {
      const clause = text.slice(start, match.index).trim();
      if (clause) phases.push({ text: clause, start_relation: relation });
      relation = fold(match[1]);
      start = connector.lastIndex;
    }
    const tail = text.slice(start).trim();
    if (tail) phases.push({ text: tail, start_relation: relation });
    return phases.length ? phases : [{ text, start_relation: 'start' }];
  }

  function lexicalMechanisms(text) {
    return SURFACE_RULES.filter(([, rx]) => rx.test(text)).map(([id]) => id);
  }

  function temporalOperators(text) {
    return TEMPORAL.filter(([, rx]) => rx.test(text)).map(([id]) => id);
  }

  function routePredicate(clause, context = {}) {
    const text = clause.text;
    const mechanisms = lexicalMechanisms(text);
    const negated = LEXEMES.negation.test(text);
    const negatedAvoidance = /\b(?:not|never|wasn'?t|weren'?t|isn'?t|didn'?t|don'?t|doesn'?t|khong|chẳng)\b.{0,18}\b(?:avoid\w*|disengag\w*|withdraw\w*|ne|tranh mat|bo qua)\b/i.test(text);
    const cessation = LEXEMES.cessation.test(text);
    const repeated = LEXEMES.repetition.test(text);
    const bounded = LEXEMES.bounded.test(text) && !repeated;
    const sufficient = LEXEMES.sufficient.test(text) || context.sufficient;
    const noNewEvidence = LEXEMES.noNewEvidence.test(text) || context.noNewEvidence;
    const newEvidence = !noNewEvidence && (LEXEMES.newEvidence.test(text) || context.newEvidence);
    const external = LEXEMES.external.test(text);
    const operators = temporalOperators(text);
    const predicates = [];
    const add = (predicate, family, confidence = 'direct') => predicates.push({ predicate, family, confidence });

    if (!external) {
      if (mechanisms.includes('inability-decision')) add('unable-to-decide', 'freeze');
      if (mechanisms.includes('inability-action')) add('unable-to-act', 'freeze');
      if (mechanisms.includes('stuck')) add('stuck-in-place', 'freeze');
    }
    if (!negatedAvoidance && !cessation) {
      if (mechanisms.includes('leave-unengaged')) add(/unread|chua xem|khong doc/.test(text) ? 'leave-unread' : 'leave-unopened', 'ignore');
      if (mechanisms.includes('avoid-engagement')) add('avoid-engagement', 'ignore');
    }
    if (!cessation && mechanisms.includes('seek-input')) add('seek-more-input', sufficient ? 'slow' : 'adaptive');
    if (!cessation && mechanisms.includes('delay')) add('delay-after-sufficiency', 'slow');
    if (!cessation && mechanisms.includes('review')) {
      if (/\b(?:overthink\w*|nghi qua nhieu)\b/i.test(text)) add('over-deliberate', 'slow');
      else if (newEvidence) add('proportionate-review', 'adaptive');
      else if (repeated && sufficient) add(operators.includes('return-to') ? 'revisit-evidence' : 'repeated-checking', 'slow');
      else if (repeated) add(operators.includes('return-to') ? 'revisit-evidence' : 'repeated-checking', 'slow');
      else if (sufficient && !newEvidence && !bounded) add('delay-after-sufficiency', 'slow');
      else if (bounded) add('bounded-review', 'adaptive');
      else add('proportionate-review', 'adaptive', 'tentative');
    }
    if (!cessation && mechanisms.includes('fast-action')) add(sufficient ? 'immediate-resolution-seeking' : 'act-before-needed-evidence', 'fast');

    return { mechanisms, operators, negated, cessation, repeated, bounded, sufficient, newEvidence, external, predicates };
  }

  function semanticNormalize(raw) {
    const surface = normalizeSurface(raw);
    const attribution = parseAttribution(surface.folded);
    const governed = attribution.claim;
    const segmented = segmentClauses(governed);
    const globalNoNewEvidence = LEXEMES.noNewEvidence.test(governed);
    const globalContext = { sufficient: LEXEMES.sufficient.test(governed), noNewEvidence: globalNoNewEvidence, newEvidence: !globalNoNewEvidence && LEXEMES.newEvidence.test(governed) };
    const phases = segmented.map((clause, index) => {
      const routed = routePredicate(clause, globalContext);
      return {
        phase_id: index + 1,
        text: clause.text,
        start_relation: clause.start_relation,
        end_relation: index < segmented.length - 1 ? segmented[index + 1].start_relation : 'end',
        subject: attribution.type === 'attributed-third-party' ? 'third-party' : 'self',
        source_of_claim: attribution.source,
        evidence_provenance: attribution.type,
        negation: routed.negated ? 'NOT' : routed.cessation ? 'NO_LONGER' : 'none',
        evidence_state: routed.newEvidence ? 'new-or-changed' : routed.sufficient ? 'sufficient' : 'unspecified',
        external_constraint: routed.external,
        temporal_operators: routed.operators,
        predicates: routed.predicates,
      };
    });
    const usable = attribution.disputed || attribution.type === 'attributed-third-party' ? [] : phases.flatMap((phase) => phase.predicates.map((item) => ({ ...item, phase_id: phase.phase_id })));
    const families = [];
    for (const item of usable) if (!families.includes(item.family)) families.push(item.family);
    return { version: VERSION, surface, attribution, phases, responses: usable, families, sequence: phases.length > 1 && usable.length > 1, operator_precedence: OPERATOR_PRECEDENCE };
  }

  function inputRoute(raw) {
    const inherited = parent.inputRoute(raw);
    if (inherited.must_redirect) return inherited;
    const semantic = semanticNormalize(raw);
    if (semantic.attribution.type === 'attributed-third-party') return { id: 'input:third-party-only', action: 'clarify', must_stop: true, must_redirect: false };
    if (semantic.attribution.type === 'attributed-self' && semantic.attribution.disputed) return { id: 'input:attributed-self-disputed', action: 'clarify', must_stop: true, must_redirect: false };
    if (semantic.attribution.type === 'attributed-self' && !semantic.attribution.selfConfirmed) return { id: 'input:attributed-self-unconfirmed', action: 'clarify', must_stop: true, must_redirect: false };
    return inherited;
  }

  function analyze(raw, domain = 'other', subtopic = null) {
    const inherited = parent.analyze(raw, domain, subtopic);
    const semantic = semanticNormalize(raw);
    const route = inputRoute(raw);
    const strong = semantic.responses.filter((item) => item.confidence !== 'tentative');
    const text = semantic.surface.folded;
    const semanticFamilies = semantic.families;
    const targetedCorrection = semantic.attribution.type !== 'direct-self-report' ||
      ((/\b(?:khong|chẳng|chang)\b/.test(text) || /\b(?:couldn'?t|cannot|can'?t|unable)\b/.test(text)) && semanticFamilies.includes('freeze') && !inherited.families.includes('freeze')) ||
      (semanticFamilies.includes('ignore') && !inherited.families.includes('ignore')) ||
      (/\b(?:not|never|didn'?t|don'?t|doesn'?t|khong|chẳng)\b.{0,18}\b(?:avoid\w*|disengag\w*|withdraw\w*|ne|tranh mat|bo qua)\b/i.test(text)) ||
      (semanticFamilies.includes('adaptive') && LEXEMES.newEvidence.test(text) && !LEXEMES.noNewEvidence.test(text)) ||
      (semanticFamilies.includes('adaptive') && LEXEMES.bounded.test(text)) ||
      (semanticFamilies.includes('slow') && LEXEMES.repetition.test(text)) ||
      (semantic.sequence && semanticFamilies.length > 1 && (semantic.phases.filter((phase) => phase.predicates.length > 0).length >= 3 || semanticFamilies.length > inherited.families.length));
    const useSemantic = (strong.length > 0 && targetedCorrection) || semantic.phases.some((phase) => phase.external_constraint);
    const responses = route.id === 'input:third-party-only' ? [] : useSemantic ? semantic.responses.map((item) => ({ id: `v83122:${item.predicate}`, family: item.family, predicate: item.predicate, phase_id: item.phase_id, dimension: item.family === 'slow' ? 'information' : 'engagement', position: item.family === 'adaptive' ? 'neutral' : 'A' })) : inherited.responses;
    const families = [];
    for (const response of responses) if (!families.includes(response.family)) families.push(response.family);
    return {
      ...inherited, version: VERSION, metadata, semantic_representation: semantic, responses, families,
      sequence: semantic.sequence || inherited.sequence, oscillation: semantic.sequence || inherited.oscillation,
      response_known: families.length > 0, input_route: route, can_continue: route.action === 'continue', must_stop: route.must_stop, must_redirect: route.must_redirect,
    };
  }

  function evaluate(frame, evidence = {}) {
    return { ...parent.evaluate(frame, evidence), version: VERSION };
  }

  function contract(frame, evidence = {}) {
    const result = evaluate(frame, evidence);
    return {
      topic_id: frame.topic_id, input_route: frame.input_route.id, families: [...frame.families], sequence: frame.sequence,
      attribution: frame.semantic_representation.attribution,
      phases: frame.semantic_representation.phases.map((phase) => ({ phase_id: phase.phase_id, start_relation: phase.start_relation, end_relation: phase.end_relation, subject: phase.subject, source_of_claim: phase.source_of_claim, negation: phase.negation, evidence_state: phase.evidence_state, external_constraint: phase.external_constraint, temporal_operators: phase.temporal_operators, predicates: phase.predicates.map((item) => item.predicate), families: phase.predicates.map((item) => item.family) })),
      classification: result.classification, pattern_claim_allowed: result.pattern_claim_allowed, must_stop: !!result.must_stop, must_redirect: !!result.must_redirect,
    };
  }

  global.QCSemanticCoreV4 = {
    ...parent, version: VERSION, metadata, ontology: ONTOLOGY, operatorPrecedence: OPERATOR_PRECEDENCE,
    normalizeSurface, parseAttribution, segmentClauses, semanticNormalize, inputRoute, analyze, evaluate, contract,
    schema: Object.freeze({ ...parent.schema, semanticVersion: 'operator-aware-v1', predicateOntologyFamilies: 5, operatorStages: 15 }),
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
