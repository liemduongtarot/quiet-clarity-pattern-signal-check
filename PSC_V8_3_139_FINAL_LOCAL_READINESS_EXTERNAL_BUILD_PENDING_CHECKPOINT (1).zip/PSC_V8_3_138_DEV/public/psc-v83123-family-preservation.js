(function (global) {
  'use strict';
  const parent = global.QCSemanticCoreV4;
  if (!parent || parent.version !== 'V8.3.122-OPERATOR-AWARE-REVIEW-CANDIDATE') throw new Error('V8.3.123 requires frozen V8.3.122 failed RC');
  const VERSION = 'V8.3.123-FAMILY-PRESERVATION-REVIEW-CANDIDATE';
  const fold = (value) => global.QCSemanticCoreV3.fold(value).replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim();
  const metadata = Object.freeze({ version: VERSION, parent: 'V8.3.122 FAILED REVIEW CANDIDATE', target: 'canonical predicate preservation + temporal phase preservation', production_authorized: false, step_111: 'manual-only' });
  const FAMILY = Object.freeze({
    'avoid-engagement':'ignore','leave-unopened':'ignore','leave-unread':'ignore','leave-pending':'ignore',
    'excessive-review':'slow','repeated-checking':'slow','seek-more-input':'slow','revisit-evidence':'slow','delay-after-sufficiency':'slow','over-deliberate':'slow',
    'premature-decide':'fast','rush-to-close':'fast','act-before-needed-evidence':'fast','immediate-resolution-seeking':'fast','shortcut-evaluation':'fast',
    'unable-to-act':'freeze','unable-to-decide':'freeze','unable-to-respond':'freeze','stuck-in-place':'freeze',
    'bounded-review':'adaptive','proportionate-review':'adaptive','required-check':'adaptive','gather-missing-evidence':'adaptive','reasonable-wait':'adaptive'
  });
  const RX = Object.freeze({
    external:/\b(?:file|system|device|network)\b.{0,45}\b(?:corrupt|broken|down|error|failed)\b|\b(?:he thong|tep|mang|thiet bi)\b.{0,45}\b(?:loi|hong|khong hoat dong)\b|\b(?:not authorised|not authorized|not permitted|no authority|khong co quyen|khong duoc quyen)\b/i,
    hypothetical:/\b(?:suppose|hypothetically|if someone|gia su|neu mot nguoi)\b/i,
    cessation:/\b(?:no longer|not anymore|stopped?\s+(?:doing|avoiding|checking|reviewing)|khong con|da dung)\b/i,
    negatedIgnore:/\b(?:not|never|didn'?t|don'?t|doesn'?t|khong|chẳng)\b.{0,22}\b(?:avoid\w*|disengag\w*|withdraw\w*|ne|tranh|bo qua)\b/i,
    bounded:/\b(?:once|one time|briefly|for \d+ minutes?|mot lan|dung mot lan|ngan gon)\b/i,
    newEvidence:/\b(?:new|changed|updated|additional|amended|revised)\s+(?:evidence|information|detail|fact)s?\b|\b(?:du kien|thong tin|chi tiet) moi\b/i,
    sufficient:/\b(?:enough|sufficient|already clear|everything was clear|nothing changed|da du|du thong tin|ro roi)\b/i,
    repeated:/\b(?:keep|kept|keeps|repeatedly|continually|again and again|over and over|cu|lap di lap lai|nhieu lan)\b/i
  });

  function confirmedAttribution(text) {
    const match = text.match(/^(.+?)\s+(?:said|says|noi)\s+((?:i|toi|minh)\b.+?)(?:,?\s+(?:and i agree|va toi dong y|va minh dong y))\.?$/i);
    return match ? { type:'attributed-self', source:match[1].trim(), claim:match[2].trim(), selfConfirmed:true, disputed:false } : null;
  }
  function proposition(predicate, phase, actor, state, source='v83123-grammar') {
    return { normalized_predicate:predicate, family_candidate:FAMILY[predicate]||null, polarity:'positive', reality_status:state.hypothetical?'hypothetical':'real', actor, target:phase.text, temporal_phase:phase.phase_id, frequency:state.repeated?'repeated':state.bounded?'bounded':'unspecified', evidence_status:state.newEvidence?'new-or-changed':state.sufficient?'sufficient':'unspecified', constraint_status:state.external?'external':'none', activation_status:'active', suppression_reason:null, rule_source:source };
  }
  function extract(phase, actor) {
    const text=fold(phase.text), state={ external:RX.external.test(text), hypothetical:RX.hypothetical.test(text), ceased:RX.cessation.test(text), repeated:RX.repeated.test(text), bounded:RX.bounded.test(text)&&!RX.repeated.test(text), newEvidence:RX.newEvidence.test(text), sufficient:RX.sufficient.test(text) };
    const rows=[], push=(p)=>rows.push(proposition(p,phase,actor,state));
    const maintained=/\b(?:keep|kept|leave|left|put|set)\b.{0,42}\b(?:unopened|unread|pending|aside)\b/i.test(text)||/\b(?:de|bo)\b.{0,42}\b(?:chua doc|chua mo|khong doc|khong mo|sang ben)\b/i.test(text);
    const avoid=/\b(?:avoid\w*|sidestep\w*|disengag\w*|withdraw\w*|not look at|ne|tranh|bo qua)\b/i.test(text);
    if(maintained) push(/unread|chua doc|khong doc/.test(text)?'leave-unread':/pending/.test(text)?'leave-pending':'leave-unopened');
    if(avoid) { const row=proposition('avoid-engagement',phase,actor,state); if(RX.negatedIgnore.test(text)) Object.assign(row,{polarity:'negative',activation_status:'suppressed',suppression_reason:'explicit-negation'}); rows.push(row); }
    const review=/\b(?:review\w*|check\w*|recheck\w*|revisit\w*|overthink\w*|re-read|reread|xem lai|kiem tra|doi chieu|nghi qua nhieu)\b|\bxem\b.{0,20}\b(?:chi tiet|du kien|thong tin)\b/i.test(text);
    const seek=/\b(?:consult\w*|tham khao)\b|\b(?:ask\w*|seek\w*|sought|hoi)\b.{0,30}\b(?:opinion|input|advice|view|y kien)\b/i.test(text);
    if(seek) push(state.sufficient?'seek-more-input':'gather-missing-evidence');
    const reasonableWait=/\b(?:wait\w*|cho)\b.{0,36}\b(?:approval|phe duyet)\b/i.test(text);
    if(reasonableWait) push('reasonable-wait');
    if(review) {
      if(/\b(?:overthink\w*|nghi qua nhieu)\b/i.test(text)) push('over-deliberate');
      else if(state.newEvidence) push('proportionate-review');
      else if(state.bounded) push('bounded-review');
      else if(state.repeated&&/\b(?:revisit\w*|xem lai)\b/i.test(text)) push('revisit-evidence');
      else if(state.repeated) push('repeated-checking');
      else if(state.sufficient) push('delay-after-sufficiency');
    }
    const fast=/\b(?:respond\w*|decid\w*|act\w*|resolve\w*|close\w*|chot|quyet|phan hoi|xu ly)\b.{0,36}\b(?:straight away|immediately|quick\w*|hastily|too soon|ngay|voi|qua som|cho xong)\b|\b(?:made|make|took|take)\b.{0,18}\b(?:quick|immediate|hasty)\b.{0,12}\bdecision\b/i.test(text);
    if(fast) push(/\b(?:before|truoc)\b/.test(text)?'act-before-needed-evidence':'rush-to-close');
    const inability=/\b(?:could not|couldn'?t|cannot|can'?t|unable to|khong the|khong .+ noi)\b/i.test(text);
    if(inability&&!state.external) push(/\b(?:decide|choose|quyet|chon)\b/i.test(text)?'unable-to-decide':/\b(?:respond|phan ung)\b/i.test(text)?'unable-to-respond':'unable-to-act');
    for(const row of rows) {
      if(state.external) Object.assign(row,{activation_status:'suppressed',suppression_reason:'external-constraint'});
      else if(state.hypothetical) Object.assign(row,{activation_status:'suppressed',suppression_reason:'hypothetical'});
      else if(state.ceased) Object.assign(row,{activation_status:'suppressed',suppression_reason:'current-cessation'});
      else if(actor==='third-party') Object.assign(row,{activation_status:'suppressed',suppression_reason:'third-party-ownership'});
    }
    return rows;
  }
  function semanticNormalize(raw) {
    const inherited=parent.semanticNormalize(raw), routed=parent.analyze(raw,'other'), attribution=confirmedAttribution(fold(raw))||inherited.attribution, actor=attribution.type==='attributed-third-party'?'third-party':'self';
    const refinedPhases=[];for(const phase of inherited.phases){const parts=phase.text.split(/\s*,?\s*\b(?:and finally|finally|and then|then|after that|later|eventually|cuoi cung|sau do|tiep theo|roi|ve sau)\b\s*/i).filter(Boolean);for(const text of parts)refinedPhases.push({...phase,text,phase_id:refinedPhases.length+1});}
    const phaseStructureRefined=refinedPhases.length!==inherited.phases.length;
    const phases=refinedPhases.map(phase=>{
      const phaseState={external:RX.external.test(phase.text),hypothetical:RX.hypothetical.test(phase.text),ceased:RX.cessation.test(phase.text),repeated:RX.repeated.test(phase.text),bounded:RX.bounded.test(phase.text),newEvidence:RX.newEvidence.test(phase.text),sufficient:RX.sufficient.test(phase.text)};
      const inheritedRows=(phaseStructureRefined?[]:routed.responses.filter(item=>item.predicate&&item.phase_id===phase.phase_id)).map(item=>{const row=proposition(item.predicate,phase,actor,phaseState,'v83122-routed-canonical-predicate');if(phaseState.external)Object.assign(row,{activation_status:'suppressed',suppression_reason:'external-constraint'});else if(phaseState.hypothetical)Object.assign(row,{activation_status:'suppressed',suppression_reason:'hypothetical'});else if(phaseState.ceased)Object.assign(row,{activation_status:'suppressed',suppression_reason:'current-cessation'});else if(actor==='third-party')Object.assign(row,{activation_status:'suppressed',suppression_reason:'third-party-ownership'});return row;});
      const propositions=[]; for(const item of [...inheritedRows,...extract(phase,actor)]) if(!propositions.some(row=>row.normalized_predicate===item.normalized_predicate)) propositions.push(item);
      return {...phase,subject:actor,source_of_claim:attribution.source,propositions};
    });
    const legacyPredicate={ignore:'avoid-engagement',slow:'excessive-review',fast:'premature-decide',freeze:'stuck-in-place',adaptive:'proportionate-review'};
    const routedFamilySet=new Set(routed.families);
    for(const [index,family] of routed.families.entries()) if(!phases.some(p=>p.propositions.some(x=>x.activation_status==='active'&&x.family_candidate===family))){const phase=phases[Math.min(index,phases.length-1)];if(phase){for(const row of phase.propositions)if(row.activation_status==='active'&&!routedFamilySet.has(row.family_candidate))Object.assign(row,{activation_status:'suppressed',suppression_reason:'parent-routed-family-precedence'});const state={external:false,hypothetical:false,ceased:false,repeated:false,bounded:false,newEvidence:false,sufficient:false};phase.propositions.push(proposition(legacyPredicate[family],phase,actor,state,'v83122-routed-family-preservation'));}}
    const propositions=phases.flatMap(x=>x.propositions), active=propositions.filter(x=>x.activation_status==='active'&&x.family_candidate).sort((a,b)=>a.temporal_phase-b.temporal_phase||(routed.families.indexOf(a.family_candidate)+1||999)-(routed.families.indexOf(b.family_candidate)+1||999)), responses=active.map(x=>({id:`v83123:${x.normalized_predicate}`,predicate:x.normalized_predicate,family:x.family_candidate,phase_id:x.temporal_phase,confidence:'direct'}));
    const families=[]; for(const row of responses) if(!families.includes(row.family)) families.push(row.family);
    const activePhases=phases.filter(p=>p.propositions.some(x=>x.activation_status==='active'));
    const violations=[]; for(const item of active) if(!responses.some(x=>x.predicate===item.normalized_predicate&&x.phase_id===item.temporal_phase)) violations.push({invariant:'CANONICAL_PREDICATE_PRESERVATION',phase_id:item.temporal_phase,predicate:item.normalized_predicate}); if(active.length&&!families.length) violations.push({invariant:'VALID_FAMILY_MUST_NOT_DROP_TO_NONE'});
    return {...inherited,version:VERSION,attribution,phases,propositions,responses,families,sequence:activePhases.length>1,trace:{stages:['raw-clause','clause-segmentation','proposition-extraction','semantic-normalization','predicate-ontology','modifier-scope','family-candidate-generation','operator-precedence','sequence','final-routing'],invariant_violations:violations}};
  }
  function analyze(raw,domain='other',subtopic=null) {
    const inherited=parent.analyze(raw,domain,subtopic), semantic=semanticNormalize(raw), blocked=inherited.input_route.id==='input:third-party-only'||semantic.attribution.type==='attributed-third-party';
    const preserved=blocked?[]:semantic.responses.map(x=>({...x,dimension:x.family==='slow'?'information':'engagement',position:x.family==='adaptive'?'neutral':'A'})), families=[]; for(const row of preserved) if(!families.includes(row.family)) families.push(row.family);
    const use=preserved.length>0||semantic.propositions.some(x=>x.suppression_reason);
    return {...inherited,version:VERSION,metadata,semantic_representation:semantic,responses:use?preserved:inherited.responses,families:use?families:inherited.families,sequence:use?semantic.sequence:inherited.sequence,oscillation:use?semantic.sequence:inherited.oscillation,response_known:use?families.length>0:inherited.response_known};
  }
  function evaluate(frame,evidence={}) { return {...parent.evaluate(frame,evidence),version:VERSION}; }
  function contract(frame,evidence={}) { const result=evaluate(frame,evidence); return {topic_id:frame.topic_id,input_route:frame.input_route.id,families:[...frame.families],sequence:frame.sequence,propositions:frame.semantic_representation.propositions,classification:result.classification,pattern_claim_allowed:result.pattern_claim_allowed,must_stop:!!result.must_stop,must_redirect:!!result.must_redirect}; }
  global.QCSemanticCoreV4={...parent,version:VERSION,metadata,familyByPredicate:FAMILY,semanticNormalize,analyze,evaluate,contract,invariants:Object.freeze(['CANONICAL_PREDICATE_PRESERVATION','VALID_FAMILY_MUST_NOT_DROP_TO_NONE','TEMPORAL_PHASE_PRESERVATION']),schema:Object.freeze({...parent.schema,semanticVersion:'family-preservation-v2',propositionIRFields:10,predicatePreservation:true,temporalPhasePreservation:true})};
})(typeof globalThis!=='undefined'?globalThis:this);
