(function (global) {
  'use strict';

  const base = global.QCSemanticCoreV3;
  if (!base) throw new Error('QCSemanticCoreV4 requires QCSemanticCoreV3');

  const VERSION = '4.0.0-review-candidate';
  const LANGUAGES = ['vi', 'vi-unaccented', 'vi-mixed-diacritics', 'en'];
  const FAMILIES = ['slow', 'fast', 'freeze', 'ignore', 'adaptive'];
  const QUESTIONS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const QUESTION_PURPOSE = {
    A: 'response', B: 'responsibility', C: 'attention', D: 'action',
    E: 'reinforcement', F: 'position', G: 'evidence', H: 'values',
  };

  const DIRECT_TOPICS = [
    ['work', 'Công việc / sự nghiệp', 'Work / career'],
    ['business', 'Business / công việc tự doanh', 'Business / self-employment'],
    ['money', 'Tiền bạc / tài chính', 'Money / finances'],
    ['romantic', 'Tình cảm / mối quan hệ yêu đương', 'Romantic relationship'],
    ['family', 'Gia đình', 'Family'],
    ['friends', 'Bạn bè / quan hệ xã hội', 'Friends / social relationships'],
    ['home', 'Nhà ở / môi trường sống', 'Home / living environment'],
    ['daily', 'Đời sống hằng ngày', 'Day-to-day life'],
    ['wellbeing', 'Sức lực / trạng thái hằng ngày', 'Energy / day-to-day wellbeing'],
    ['direction', 'Hướng đi cuộc sống', 'Life direction'],
    ['repeating', 'Một chuyện cứ lặp lại', 'A recurring situation'],
  ];

  const OTHER_TOPICS = [
    ['health', 'Sức khỏe thể chất hoặc sức khỏe tinh thần', 'Physical or mental health'],
    ['education', 'Học tập hoặc phát triển kỹ năng', 'Education or skill development'],
    ['immigration-legal', 'Visa, nhập cư, pháp lý hoặc thủ tục hành chính', 'Visa, immigration, legal or administrative matters'],
    ['loss-transition', 'Mất mát, kết thúc hoặc thay đổi lớn trong cuộc sống', 'Loss, ending or major life transition'],
    ['identity', 'Danh tính hoặc cách tôi nhìn nhận bản thân', 'Identity or how I see myself'],
    ['caregiving', 'Con cái, làm cha mẹ hoặc chăm sóc người khác', 'Parenting or caring for someone'],
    ['creative-habit', 'Sáng tạo, dự án cá nhân hoặc thói quen riêng', 'Creativity, a personal project or habit'],
    ['community-digital', 'Cộng đồng, danh tiếng hoặc tương tác trên mạng', 'Community, reputation or online interaction'],
    ['belief-values', 'Niềm tin, tâm linh, giá trị hoặc ý nghĩa sống', 'Belief, spirituality, values or meaning'],
    ['safety', 'An toàn cá nhân hoặc cảm giác bị đe dọa, kiểm soát hay quấy rối', 'Personal safety, threat, control or harassment'],
    ['cross-domain', 'Chuyện này liên quan đồng thời nhiều phần trong cuộc sống', 'This involves several parts of life at once'],
    ['uncategorised', 'Chuyện của tôi không nằm trong các nhóm trên', 'My situation does not fit the groups above'],
  ];

  const TOPIC_CONTEXT = {
    health: { vi: 'chuyện sức khỏe này', en: 'this health situation' },
    education: { vi: 'chuyện học tập hoặc phát triển kỹ năng này', en: 'this education or development situation' },
    'immigration-legal': { vi: 'chuyện visa, nhập cư, pháp lý hoặc thủ tục này', en: 'this immigration, legal or administrative situation' },
    'loss-transition': { vi: 'mất mát, kết thúc hoặc thay đổi này', en: 'this loss, ending or transition' },
    identity: { vi: 'chuyện danh tính hoặc cách nhìn bản thân này', en: 'this identity or self-perception situation' },
    caregiving: { vi: 'chuyện chăm sóc hoặc trách nhiệm với người khác này', en: 'this caregiving responsibility' },
    'creative-habit': { vi: 'dự án, sáng tạo hoặc thói quen này', en: 'this creative project or habit' },
    'community-digital': { vi: 'chuyện cộng đồng, danh tiếng hoặc tương tác online này', en: 'this community, reputation or online situation' },
    'belief-values': { vi: 'chuyện niềm tin, giá trị hoặc ý nghĩa này', en: 'this belief, values or meaning situation' },
    safety: { vi: 'chuyện an toàn cá nhân này', en: 'this personal-safety situation' },
    'cross-domain': { vi: 'tình huống liên quan nhiều phần cuộc sống này', en: 'this cross-domain situation' },
    uncategorised: { vi: 'tình huống này', en: 'this situation' },
  };

  const CRITICAL_MUTATIONS = Object.freeze([
    'emotion_becomes_response_family',
    'state_becomes_response_family',
    'third_party_behaviour_attributed_to_user',
    'hypothetical_example_treated_as_lived_event',
    'prediction_allowed_into_questionnaire',
    'safety_route_allowed_into_questionnaire',
    'external_constraint_alone_creates_pattern',
    'reinforcement_gate_removed',
    'current_evidence_gate_removed',
    'single_occurrence_creates_established_pattern',
    'inactive_pattern_marked_active',
    'adaptive_majority_creates_pattern',
    'slow_bank_exposes_fast_response',
    'family_correction_does_not_reset_downstream',
    'topic_change_alters_response_family',
    'language_surface_changes_semantic_contract',
    'other_route_dead_end',
    'unknown_response_forced_into_pattern',
    'non_applicable_answer_scored_as_maladaptive',
    'result_consequence_uses_wrong_topic',
  ]);

  const RE_INPUT = {
    safety: /(tu tu|tu lam hai|minh khong an toan|bi de doa|bi danh|bao luc|cuong ep|self.?harm|suicid|not safe|being threatened|violence|abuse)/,
    prediction: /(khi nao|bao gio|luc nao|co quay lai|co tro lai|se xay ra|will .* happen|when will|when (?:he|she|they|that person) will|come back|return to me|message me again)/,
    choice: /\b(toi|minh) (co )?nen\b|\bnen (chon|lam|di|o|tiep tuc|dung)\b|should i (?:choose|leave|stay|do|continue|stop)|whether i should/,
    hypothetical: /(gia su|vi du nhu|neu mot nguoi|tuong tuong|hypothetically|for example,? if|suppose someone)/,
    thirdParty: /(anh ay|co ay|nguoi do|nguoi yeu toi|sep toi|ban toi|my partner|my boss|my friend|\bthey\b|\bhe\b|\bshe\b).{0,80}(thuong|luon|hay|cu|always|usually|keeps?)/,
  };

  const SUPPLEMENTAL_RESPONSES = [
    { id: 'repeated-reading', family: 'slow', dimension: 'information', position: 'B', rx: /(doc di doc lai|read it repeatedly|read repeatedly)/ },
    { id: 'immediate-acceptance', family: 'fast', dimension: 'speed', position: 'B', rx: /(nhan loi ngay|commit immediately)/ },
    { id: 'leave-unread', family: 'ignore', dimension: 'engagement', position: 'A', rx: /(de (tin nhan|phan hoi).{0,20}chua doc|leave .{0,20}unread)/ },
    { id: 'sufficient-evidence-step', family: 'adaptive', dimension: 'information', position: 'A', rx: /(kiem tra phan can thiet|bang chung da du|check what is necessary|evidence is sufficient)/ },
    { id: 'overprepare-long', family: 'slow', dimension: 'information', position: 'B', rx: /(chuan bi qua lau|prepare for too long)/ },
    { id: 'hasty-decision', family: 'fast', dimension: 'speed', position: 'B', rx: /(chot voi|decide hastily)/ },
    { id: 'rapid-action', family: 'fast', dimension: 'speed', position: 'B', rx: /(hanh dong ngay|cam ket truoc|phan hoi ngay|act immediately|commit before|respond immediately)/ },
    { id: 'cannot-initiate', family: 'freeze', dimension: 'engagement', position: 'A', rx: /(khong bat dau duoc|khong khoi dong duoc|cannot begin|cannot start|unable to begin)/ },
    { id: 'long-checking', family: 'slow', dimension: 'information', position: 'B', rx: /(kiem tra rat lau|check for a long time|checking for a long time)/ },
    { id: 'eventual-rush', family: 'fast', dimension: 'speed', position: 'B', rx: /(cuoi cung quyet ngay|eventually decide immediately|then decide immediately)/ },
    { id: 'withdraw-no-reply', family: 'ignore', dimension: 'engagement', position: 'A', rx: /(ne va khong tra loi|avoid it and do not reply|avoid and do not reply)/ },
  ];

  function inputRoute(raw) {
    const value = base.fold(raw);
    if (!value.trim()) return { id: 'input:empty', action: 'clarify', must_stop: true, must_redirect: false };
    if (RE_INPUT.safety.test(value)) return { id: 'input:safety', action: 'redirect', must_stop: true, must_redirect: true };
    if (RE_INPUT.prediction.test(value)) return { id: 'input:prediction', action: 'redirect', must_stop: true, must_redirect: true };
    if (RE_INPUT.choice.test(value)) return { id: 'input:decision-request', action: 'redirect', must_stop: true, must_redirect: true };
    if (RE_INPUT.hypothetical.test(value)) return { id: 'input:hypothetical', action: 'clarify', must_stop: true, must_redirect: false };
    if (RE_INPUT.thirdParty.test(value) && !/(?:^|[,;.!?])\s*(toi|minh|i)\s+.{0,60}\b(phan ung|lam|khong lam|cam thay|thuong|respond|do|avoid|check|delay)\b/.test(value)) {
      return { id: 'input:third-party-only', action: 'clarify', must_stop: true, must_redirect: false };
    }
    return { id: 'input:self-lived', action: 'continue', must_stop: false, must_redirect: false };
  }

  function topicOptions(language = 'vi') {
    return DIRECT_TOPICS.map(([id, vi, en]) => ({ id: `topic:${id}`, topic_id: id, text: language === 'en' ? en : vi }))
      .concat([{ id: 'topic:other', topic_id: 'other', text: language === 'en' ? 'Other' : 'Khác' }]);
  }

  function otherTopicOptions(language = 'vi') {
    return OTHER_TOPICS.map(([id, vi, en]) => ({ id: `topic:other:${id}`, topic_id: id, text: language === 'en' ? en : vi }));
  }

  function analyze(raw, domain = 'other', subtopic = null) {
    const frame = base.analyze(raw, domain === 'other' && subtopic ? 'other' : domain);
    const route = inputRoute(raw);
    const topic = subtopic && TOPIC_CONTEXT[subtopic] ? TOPIC_CONTEXT[subtopic][frame.language] : frame.topic;
    const folded = base.fold(raw);
    const extra = SUPPLEMENTAL_RESPONSES.filter((row) => row.rx.test(folded)).map(({ rx, ...row }) => row);
    let responses = [...frame.responses];
    for (const row of extra) if (!responses.some((existing) => existing.id === row.id)) responses.push(row);
    if (responses.some((row) => row.id === 'cannot-initiate')) {
      responses = responses.filter((row) => row.id !== 'delay');
      responses.sort((left, right) => (left.family === 'freeze' ? -1 : 0) - (right.family === 'freeze' ? -1 : 0));
    }
    const families = [...new Set(responses.map((row) => row.family))];
    const sequence = families.length > 1 && /(roi|sau do|cuoi cung|then|after that|eventually)/.test(folded);
    return {
      ...frame,
      version: VERSION,
      raw_input: String(raw || ''),
      topic,
      topic_id: subtopic || domain,
      responses,
      families,
      sequence,
      oscillation: sequence && families.length > 1,
      response_known: responses.length > 0,
      needs_response_clarification: responses.length === 0 && (frame.emotion.length > 0 || frame.state.length > 0),
      input_route: route,
      can_continue: route.action === 'continue',
      must_stop: route.must_stop,
      must_redirect: route.must_redirect,
    };
  }

  function responseStructure(frame, evidence = {}) {
    const ordered = [];
    for (const row of frame.responses || []) if (!ordered.includes(row.family)) ordered.push(row.family);
    const primary = evidence.family || ordered[0] || 'unknown';
    let type = 'primary_only';
    if (evidence.correctedFamily === true) type = 'corrected_family';
    else if (!frame.response_known) type = 'unresolved_ambiguity';
    else if (frame.sequence && ordered.length > 1) type = 'temporal_sequence';
    else if (evidence.alternatingFamily === true) type = 'alternating_family';
    else if (ordered.length > 1) type = 'simultaneous_mixed_family';
    else if (evidence.secondaryFamily) type = 'primary_plus_secondary';
    return {
      type,
      primary_family: primary,
      secondary_families: ordered.filter((family) => family !== primary),
      ordered_families: ordered,
      ordered_response_ids: (frame.responses || []).map((row) => row.id),
    };
  }

  function enrichAnalysis(frame, result, evidence = {}) {
    if (result.must_redirect) return { ...result, analysis_level: 'redirected', analysis_continues: false, pattern_claim_allowed: false };
    const clear = ['established_pattern', 'weakened_pattern'].includes(result.classification);
    const insufficient = ['response_unknown', 'insufficient_evidence', 'clarification_required'].includes(result.classification);
    const language = frame.language === 'en' ? 'en' : 'vi';
    const structure = responseStructure(frame, evidence);
    const issuePresent = !!((frame.raw_input || '').trim() || frame.external_constraint || frame.capacity_limited);
    const analysisLevel = clear ? 'clear_current_pattern_signal' : insufficient ? 'insufficient_or_ambiguous_evidence' : 'meaningful_issue_without_pattern';
    const fallbackConsequence = language === 'en'
      ? 'The present situation may continue to consume attention, time or options; this consequence belongs to the situation, not to an unproven pattern.'
      : 'Tình huống hiện tại có thể tiếp tục chiếm sự chú ý, thời gian hoặc lựa chọn; hệ quả này thuộc về tình huống, không được quy cho một pattern chưa được chứng minh.';
    const issueSummary = clear
      ? (language === 'en' ? 'Current evidence supports an active repeating response mechanism.' : 'Bằng chứng hiện tại hỗ trợ một cơ chế phản ứng lặp đang hoạt động.')
      : insufficient
        ? (language === 'en' ? 'There is a material situation, but the response mechanism remains unresolved or ambiguous.' : 'Có một tình huống đáng chú ý, nhưng cơ chế phản ứng vẫn chưa được xác định hoặc còn mơ hồ.')
        : (language === 'en' ? 'A meaningful issue or response is present, but evidence does not support calling it an active repeating pattern.' : 'Có một vấn đề hoặc response đáng chú ý, nhưng bằng chứng chưa đủ để gọi đây là một pattern lặp đang hoạt động.');
    return {
      ...result,
      analysis_level: analysisLevel,
      analysis_continues: issuePresent,
      issue_present: issuePresent,
      issue_summary: issueSummary,
      response_structure: structure,
      pattern_claim_allowed: clear,
      consequence_basis: clear ? 'pattern_mechanism' : insufficient ? 'situation_only' : 'current_response_or_situation',
      consequence: result.consequence || (issuePresent ? fallbackConsequence : ''),
    };
  }

  function clarificationRecoveryOptions(frame) {
    const vi = frame.language === 'vi';
    const rows = vi ? [
      ['slow', 'Tôi chậm lại, kiểm tra, cân nhắc hoặc chuẩn bị thêm trước khi hành động.'],
      ['fast', 'Tôi muốn quyết định, hành động, giải quyết hoặc cam kết thật nhanh.'],
      ['freeze', 'Tôi muốn xử lý nhưng bị đứng lại, không chọn được bước tiếp theo hoặc không bắt đầu được.'],
      ['ignore', 'Tôi né, phớt lờ, trì hoãn đối diện hoặc chuyển sự chú ý sang chuyện khác.'],
      ['mixed', 'Tôi chuyển qua lại giữa nhiều phản ứng, chẳng hạn kiểm tra lâu rồi chốt vội hoặc đứng lại rồi né.'],
      ['adaptive', 'Tôi vẫn xử lý theo mức cần thiết và điều chỉnh khi có dữ kiện mới.'],
      ['unknown', 'Tôi nhận ra cảm xúc hoặc trạng thái nhưng chưa biết nó dẫn đến phản ứng nào.'],
      ['free-text', 'Cách tôi phản ứng vẫn khác với các lựa chọn trên.'],
    ] : [
      ['slow', 'I slow down, check, consider or prepare further before acting.'],
      ['fast', 'I want to decide, act, resolve or commit very quickly.'],
      ['freeze', 'I want to deal with it but become stuck, cannot choose the next step or cannot begin.'],
      ['ignore', 'I avoid, dismiss, postpone engaging or move my attention elsewhere.'],
      ['mixed', 'I move between responses, such as checking for a long time and then deciding too quickly.'],
      ['adaptive', 'I deal with what is needed and adjust when new evidence appears.'],
      ['unknown', 'I notice a feeling or state but do not yet know how it affects my response.'],
      ['free-text', 'My response is still different from these options.'],
    ];
    return rows.map(([id, text]) => ({ id: `clarification:recovery:${id}`, semantic_id: `clarification:${id}`, text }));
  }

  const RECOVERY = {
    A: {
      slow: ['mental-review', 'rehearsal-revision', 'over-structuring', 'readiness-waiting', 'safe-task-substitution', 'multiple-reassurance', 'start-stop-recheck', 'reduced-pace', 'family-correction', 'free-text'],
      fast: ['rapid-communication', 'premature-spending', 'early-commitment', 'scope-expansion', 'pressure-others', 'control-through-action', 'overactivation', 'impulsive-switch', 'family-correction', 'free-text'],
      freeze: ['initiation-loss', 'priority-loss', 'decision-paralysis', 'readiness-waiting', 'outsourced-decision', 'shutdown', 'cognitive-loop', 'partial-start-stop', 'family-correction', 'free-text'],
      ignore: ['minimise', 'withdraw', 'busy-distraction', 'unread-unanswered', 'emotional-detachment', 'wait-it-out', 'topic-switch', 'indirect-avoidance', 'family-correction', 'free-text'],
      adaptive: ['deliberate-pause', 'sufficient-checking', 'evidence-update', 'resource-protection', 'proportionate-step', 'planned-return', 'flexible-boundary', 'context-adjustment', 'no-maladaptive-response', 'free-text'],
    },
    B: ['over-own', 'under-own', 'outsourced-responsibility', 'control-others-part', 'blurred-boundary', 'role-contextual', 'external-responsibility', 'proportionate-responsibility', 'non-applicable', 'free-text'],
    C: ['threat-focus', 'favourable-outcome-focus', 'others-evaluation', 'self-error-focus', 'past-focus', 'body-emotion-focus', 'detail-tunnel', 'feeling-removal-focus', 'whole-context', 'free-text'],
    D: ['start-timing', 'stop-timing', 'choice', 'communication', 'resource-commitment', 'interpersonal-response', 'scope-change', 'priority-order', 'no-action-change', 'free-text'],
    E: ['short-term-relief', 'certainty', 'control', 'reassurance-reward', 'avoid-hard-contact', 'avoid-failure-rejection', 'progress-feeling', 'pressure-urgency', 'unreinforced-contextual', 'free-text'],
    F: ['fixer', 'carer', 'peacekeeper', 'performer', 'controller', 'observer', 'follower', 'standard-defender', 'flexible-position', 'free-text'],
    G: ['feared-possibility-as-fact', 'rigid-rule', 'first-interpretation', 'confirmation-bias', 'distrust-clear-evidence', 'repeat-check-conclusion', 'emotion-driven-update', 'unchecked-thought', 'evidence-updating', 'free-text'],
    H: ['time-misalignment', 'money-misalignment', 'energy-overallocation', 'single-goal-dominance', 'need-sacrifice', 'outdated-priority', 'external-standard', 'values-unclear', 'aligned-resourcing', 'free-text'],
  };

  const RECOVERY_TEXT_VI = {
    'family-correction': 'Tôi nhận ra phản ứng của mình không thật sự thuộc nhóm đã xác định.',
    'free-text': 'Cách phản ứng của tôi vẫn khác với các lựa chọn trên.',
    'non-applicable': 'Câu hỏi này không áp dụng trong tình huống của tôi.',
    'unreinforced-contextual': 'Phản ứng chỉ xảy ra do điều kiện nhất thời và không có điều củng cố rõ.',
    'no-action-change': 'Phản ứng không thực sự làm thay đổi quyết định hoặc hành động của tôi.',
    'no-maladaptive-response': 'Tôi không nhận ra một phản ứng thiếu thích nghi rõ trong tình huống này.',
    'values-unclear': 'Tôi chưa rõ điều gì thật sự quan trọng với mình trong chuyện này.',
  };

  function humanise(id, language) {
    if (language === 'vi' && RECOVERY_TEXT_VI[id]) return RECOVERY_TEXT_VI[id];
    const words = id.split('-').join(' ');
    if (language === 'en') return words.charAt(0).toUpperCase() + words.slice(1) + '.';
    return `Phản ứng này liên quan đến ${words}.`;
  }

  function questionRecoveryOptions(frame, question, clarification = '') {
    const family = base.selectedFamily(frame, clarification);
    const ids = question === 'A' ? (RECOVERY.A[family] || RECOVERY.A.slow) : RECOVERY[question];
    return ids.map((id, index) => ({
      id: `recovery:${question}:${family}:${id}`,
      semantic_id: `${QUESTION_PURPOSE[question]}:recovery:${id}`,
      position: index === 8 ? (id === 'non-applicable' ? 'non-applicable' : 'neutral') : id === 'free-text' ? 'unknown' : 'contextual',
      family_correction: id === 'family-correction',
      free_text: id === 'free-text',
      text: humanise(id, frame.language),
    }));
  }

  function currentEvidenceOptions(language = 'vi') {
    const vi = language === 'vi';
    return {
      repetition: [0, 1, 2, 3, -1].map((value) => ({ id: `current:repetition:${value}`, value, unknown: value === -1, text: value === -1 ? (vi ? 'Tôi chưa có đủ tình huống gần đây để đánh giá.' : 'I do not have enough recent situations to assess this.') : String(value) })),
      enactment: [0, 1, 2, 3, -1].map((value) => ({ id: `current:enactment:${value}`, value, unknown: value === -1, text: value === -1 ? (vi ? 'Tôi chưa có đủ tình huống gần đây để đánh giá.' : 'I do not have enough recent situations to assess this.') : String(value) })),
      interruptibility: [0, 1, 2, 3, -1].map((value) => ({ id: `current:interruptibility:${value}`, value, unknown: value === -1, text: value === -1 ? (vi ? 'Tôi chưa có đủ tình huống gần đây để đánh giá.' : 'I do not have enough recent situations to assess this.') : String(value) })),
      trend: [0, 1, 2, 3, -1].map((value) => ({ id: `current:trend:${value}`, value, unknown: value === -1, text: value === -1 ? (vi ? 'Tôi chưa có đủ tình huống trước đây để so sánh.' : 'I do not have enough previous situations to compare this.') : String(value) })),
    };
  }

  function evaluate(frame, evidence = {}) {
    if (frame.must_redirect) return enrichAnalysis(frame, { version: VERSION, classification: 'redirected_out_of_scope', family: 'unknown', must_stop: true, must_redirect: true, label: '', consequence: '' }, evidence);
    if (frame.must_stop) return enrichAnalysis(frame, { version: VERSION, classification: 'clarification_required', family: 'unknown', must_stop: true, must_redirect: false, label: '', consequence: '' }, evidence);
    if (!frame.response_known && evidence.explicitResponseClarification !== true) return enrichAnalysis(frame, { version: VERSION, classification: 'response_unknown', family: 'unknown', must_stop: true, must_redirect: false, label: '', consequence: '' }, evidence);
    const result = base.evaluate(frame, evidence);
    if (evidence.singleOccurrence === true && result.classification === 'established_pattern') result.classification = 'situational_reaction';
    if (evidence.inactiveNow === true && !['adaptive', 'external_or_capacity_constraint'].includes(result.classification)) result.classification = 'residual_or_old';
    if (evidence.responseUnknown === true) result.classification = 'response_unknown';
    if (evidence.reinforcementUnknown === true) result.classification = 'situational_or_unreinforced';
    if (evidence.currentEvidenceUnknown === true) result.classification = 'current_status_insufficient';
    return enrichAnalysis(frame, { ...result, version: VERSION, must_stop: ['response_unknown', 'situational_or_unreinforced', 'current_status_insufficient'].includes(result.classification), must_redirect: false }, evidence);
  }

  function contract(frame, evidence = {}) {
    const result = evaluate(frame, evidence);
    return {
      topic_id: frame.topic_id,
      input_route: frame.input_route.id,
      families: [...frame.families],
      sequence: frame.sequence,
      external_constraint: frame.external_constraint,
      capacity_limited: frame.capacity_limited,
      classification: result.classification,
      analysis_level: result.analysis_level,
      response_structure: result.response_structure,
      consequence_basis: result.consequence_basis,
      pattern_claim_allowed: result.pattern_claim_allowed,
      must_stop: !!result.must_stop,
      must_redirect: !!result.must_redirect,
    };
  }

  global.QCSemanticCoreV4 = {
    version: VERSION,
    languages: LANGUAGES,
    families: FAMILIES,
    questions: QUESTIONS,
    questionPurpose: QUESTION_PURPOSE,
    topicOptions,
    otherTopicOptions,
    inputRoute,
    analyze,
    clarificationOptions: base.clarificationOptions,
    clarificationRecoveryOptions,
    selectedFamily: base.selectedFamily,
    title: base.title,
    options: base.options,
    questionRecoveryOptions,
    currentEvidenceOptions,
    evaluate,
    contract,
    parity: base.parity,
    criticalMutations: CRITICAL_MUTATIONS,
    schema: Object.freeze({ topicRoutes: 23, clarificationEndpoints: 12, questionEndpoints: 19, currentEndpoints: 5 }),
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
