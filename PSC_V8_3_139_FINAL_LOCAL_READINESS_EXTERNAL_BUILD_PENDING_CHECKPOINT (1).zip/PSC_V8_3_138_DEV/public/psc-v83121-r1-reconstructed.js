(function (global) {
  'use strict';

  const base = global.QCSemanticCoreV4;
  if (!base) throw new Error('V8.3.121-R1-RECONSTRUCTED requires QCSemanticCoreV4');

  const VERSION = 'V8.3.121-R1-RECONSTRUCTED';
  const METADATA = Object.freeze({
    version: VERSION,
    parent: 'V8.3.117 surviving source authority a08c0729d82e533c6604834380d27ea2793f9d43',
    target_reference: 'V8.3.121 failed Review Candidate',
    provenance: 'reconstructed',
    original_source_available: false,
  });

  const fold = (value) => base.analyze ? global.QCSemanticCoreV3.fold(value) : String(value || '').toLowerCase();
  const phaseRx = /\b(?:then|after(?:wards| that)?|later|eventually|next|subsequently|and then|roi|sau do|sau đó|cuoi cung|cuối cùng|tiep theo|tiếp theo|rồi mới)\b/gi;
  const selfRx = /\b(?:i|i'm|i've|i'd|me|myself|toi|tôi|minh|mình|tui)\b/i;
  const attributionRx = /^(?:according to|as .+? (?:said|described)|based on .+? account|in .+? view|theo(?: loi| lời)?)(?:\s+|[:,])/i;
  const saidRx = /^(?<source>.+?)\s+(?:said(?: that)?|says(?: that)?|told me(?: that)?|noi rang|nói rằng|bao rang|bảo rằng)\s+(?<claim>.+)$/i;
  const thirdPartySubjectRx = /^\s*(?:my|the|a|an)\s+(?!own\b)(?<role>[a-z][a-z-]*(?:\s+[a-z][a-z-]*){0,3})\s+(?:keeps?|usually|always|often|repeatedly|said|says|checks?|avoids?|delays?|rushes?|freezes?)\b/i;
  const externalRx = /\b(?:because|while|due to|vi|vì|do)\b.{0,80}\b(?:surgery|operating|driving|technical|file (?:was|is) corrupt|system (?:was|is) down|khong co quyen|không có quyền|thieu quyen|thiếu quyền|file bi loi|file bị lỗi|dang phau thuat|đang phẫu thuật|emergency)\b/i;
  const sufficientRx = /\b(?:enough|sufficient|already clear|nothing changed|da du|đã đủ|du thong tin|đủ thông tin|ro roi|rõ rồi)\b/i;
  const newEvidenceRx = /\b(?:new information|new evidence|additional fact|du kien moi|dữ kiện mới|thong tin moi|thông tin mới)\b/i;
  const boundedRx = /\b(?:once|one time|briefly|for ten minutes|mot lan|một lần|chut|chút|gioi han|giới hạn)\b/i;
  const repeatedRx = /\b(?:keep|kept|keeps|repeatedly|again and again|over and over|cu|cứ|lap lai|lặp lại|nhieu lan|nhiều lần)\b/i;
  const noLongerRx = /\b(?:no longer|not anymore|used to .+ but now|khong con|không còn|truoc day .+ nhung gio|trước đây .+ nhưng giờ)\b/i;
  const negAvoidRx = /\b(?:wasn't|was not|isn't|is not|not|khong|không|chẳng)\s+(?:really\s+)?(?:avoiding|avoid|ne|né|ne tranh|né tránh)\b/i;

  const PREDICATES = Object.freeze({
    ignore: [
      ['leave-unopened', /\b(?:leave|left|kept leaving|put)\b.{0,35}\b(?:unopened|unread|sitting there|aside)\b|\b(?:de|để|bo|bỏ)\b.{0,35}\b(?:khong mo|không mở|chua xem|chưa xem|khong doc|không đọc)\b/i],
      ['avoid-engagement', /\b(?:avoid(?:ed|ing)?|disengag(?:e|ed|ing)|leave it alone|didn'?t engage|do not engage|ne|né|ne tranh|né tránh|tranh mat|tránh mặt|khong dung toi|không đụng tới|bo qua|bỏ qua|khong phan hoi|không phản hồi)\b/i],
      ['avoid-response', /\b(?:avoid(?:ed|ing)? (?:replying|responding)|didn'?t (?:reply|respond)|khong tra loi|không trả lời|ne tra loi|né trả lời)\b/i],
    ],
    slow: [
      ['revisit-evidence', /\b(?:revisit(?:ed|ing)?|return(?:ed|ing)? to|review(?:ed|ing)? again|xem lai|xem lại|quay lai xem|quay lại xem)\b.{0,45}\b(?:evidence|information|details?|bang chung|bằng chứng|thong tin|thông tin|du kien|dữ kiện)\b/i],
      ['repeated-checking', /\b(?:keep|kept|keeps|repeatedly|again and again|cu|cứ)\b.{0,35}\b(?:check|review|ask|kiem tra|kiểm tra|xem lai|xem lại|hoi|hỏi)\b/i],
      ['seek-more-input', /\b(?:ask(?:ed|ing)? (?:for )?(?:more|another|additional)|seek(?:ing)? more|hoi them|hỏi thêm)\b.{0,30}\b(?:opinion|input|advice|y kien|ý kiến)\b/i],
      ['delay-after-sufficiency', /\b(?:delay(?:ed|ing)?|put off|tri hoan|trì hoãn)\b/i],
      ['excessive-review', /\b(?:overthink|over-review|review too (?:long|much)|check too (?:long|much)|can nhac qua lau|cân nhắc quá lâu|kiem tra qua lau|kiểm tra quá lâu)\b/i],
      ['excessive-review', /\b(?:kiem tra|kiểm tra|xem xet|xem xét|check|review)\b.{0,18}\b(?:rat lau|rất lâu|qua lau|quá lâu|for a long time)\b/i],
    ],
    freeze: [
      ['unable-to-decide', /\b(?:couldn'?t|could not|cannot|can'?t|unable to|felt unable to|khong the|không thể|khong|không|chẳng)\b.{0,20}\b(?:decide|choose|quyet|quyết|chon|chọn)\b|\b(?:khong quyet noi|không quyết nổi|khong chon duoc|không chọn được)\b/i],
      ['unable-to-act', /\b(?:couldn'?t|could not|cannot|can'?t|unable to|felt unable to|khong the|không thể|khong|không|chẳng)\b.{0,20}\b(?:act|move forward|do anything|hanh dong|hành động|lam gi|làm gì|phan ung|phản ứng)\b|\b(?:khong hanh dong noi|không hành động nổi|khong phan ung noi|không phản ứng nổi)\b/i],
      ['stuck-in-place', /\b(?:froze|freeze|got stuck|stuck|stood still|bi ket|bị kẹt|dung im|đứng im|chang biet lam gi|chẳng biết làm gì|khong biet phai lam sao|không biết phải làm sao)\b/i],
    ],
    fast: [
      ['premature-decide', /\b(?:decid(?:e|ed|ing)|chot|chốt|quyet|quyết)\b.{0,30}\b(?:immediately|straight away|too soon|before .+ (?:clear|enough)|ngay|vội|qua som|quá sớm)\b/i],
      ['premature-decide', /\b(?:made|make|reached?|took)\b.{0,18}\b(?:quick|immediate|hasty)\b.{0,12}\bdecision\b/i],
      ['rush-to-close', /\b(?:rush(?:ed|ing)? to (?:close|finish|resolve|decide)|chot cho xong|chốt cho xong|xu ly cho xong|xử lý cho xong)\b/i],
      ['immediate-resolution-seeking', /\b(?:act(?:ed|ing)? immediately|respond(?:ed|ing)? immediately|lam ngay|làm ngay|phan hoi ngay|phản hồi ngay)\b/i],
    ],
    adaptive: [
      ['required-check', /\b(?:checked? what (?:was|is) necessary|required check|kiem tra phan can thiet|kiểm tra phần cần thiết)\b/i],
      ['proportionate-step', /\b(?:take|took|make|made|lam|làm)\b.{0,28}\b(?:proportionate|appropriate|needed|phu hop|phù hợp|can thiet|cần thiết)\b.{0,15}\b(?:step|buoc|bước)\b|\b(?:buoc|bước)\b.{0,15}\b(?:phu hop|phù hợp|can thiet|cần thiết)\b/i],
      ['bounded-review', /\b(?:review(?:ed|ing)?|check(?:ed|ing)?|xem lai|xem lại|kiem tra|kiểm tra)\b/i],
      ['gather-missing-evidence', /\b(?:gather(?:ed|ing)? missing|because .+ unclear|thu thap .+ con thieu|thu thập .+ còn thiếu|vi .+ chua ro|vì .+ chưa rõ)\b/i],
      ['evidence-update', /\b(?:adjust(?:ed|ing)?|update(?:d|ing)?|changed? course|dieu chinh|điều chỉnh|cap nhat|cập nhật)\b.{0,35}\b(?:new|evidence|information|du kien|dữ kiện|thong tin|thông tin)\b/i],
    ],
  });

  function splitPhases(raw) {
    const parts = fold(raw).split(phaseRx).map((text) => text.trim()).filter(Boolean);
    return parts.length ? parts : [String(raw || '').trim()];
  }

  function ownership(raw) {
    const text = String(raw || '').trim();
    const said = text.match(saidRx);
    if (said) {
      const claim = said.groups.claim;
      const claimSelf = selfRx.test(claim);
      const disputed = /\b(?:but|nhung|nhưng)\b.{0,60}\b(?:don'?t think|do not think|not true|khong nghi|không nghĩ|khong dung|không đúng)\b/i.test(text);
      return { type: claimSelf ? 'attributed_self' : 'attributed_third_party', source: said.groups.source.trim(), claim, self_confirmed: claimSelf && !disputed && /\b(?:agree|dong y|đồng ý|dung|đúng)\b/i.test(text), disputed };
    }
    if (attributionRx.test(text)) {
      const claim = text.includes(',') ? text.slice(text.indexOf(',') + 1).trim() : text;
      const foldedClaim = fold(claim);
      const thirdPossessive = /^(?:dong nghiep|ban|nguoi nha|khach|sep|giam doc|quan ly)\s+(?:toi|minh)\b/.test(foldedClaim);
      const self = selfRx.test(claim) && !thirdPossessive;
      return { type: self ? 'attributed_self' : 'attributed_third_party', source: text.split(/[:,]/)[0], claim, self_confirmed: false, disputed: false };
    }
    const third = text.match(thirdPartySubjectRx);
    if (third && !/^\s*(?:i|toi|tôi|minh|mình)\b/i.test(text)) return { type: 'third_party', source: null, claim: text, self_confirmed: false, disputed: false };
    return { type: 'direct_self', source: null, claim: text, self_confirmed: true, disputed: false };
  }

  function phaseSemantics(text, index) {
    const owner = ownership(text);
    const external = externalRx.test(text);
    const ceased = noLongerRx.test(text);
    const negatedAvoidance = negAvoidRx.test(text);
    const sufficient = sufficientRx.test(text);
    const newEvidence = newEvidenceRx.test(text);
    const bounded = boundedRx.test(text) && !repeatedRx.test(text);
    const matches = [];

    for (const [family, rows] of Object.entries(PREDICATES)) {
      for (const [predicate, rx] of rows) {
        if (!rx.test(text)) continue;
        if (family === 'ignore' && negatedAvoidance) continue;
        if (family === 'freeze' && external) continue;
        if (family === 'slow' && bounded && !sufficient) continue;
        if (family === 'slow' && predicate === 'delay-after-sufficiency' && !sufficient && !repeatedRx.test(text)) continue;
        if (family === 'slow' && newEvidence && !repeatedRx.test(text)) continue;
        if (family === 'adaptive' && predicate === 'bounded-review' && (!bounded || sufficient || repeatedRx.test(text))) continue;
        matches.push({ family, predicate, id: `reconstructed:${predicate}`, dimension: family === 'slow' ? 'information' : 'engagement', position: family === 'adaptive' ? 'neutral' : 'A' });
      }
    }

    if (newEvidence && /\b(?:revisit(?:ed|ing)?|review(?:ed|ing)? again|xem lai|xem lại|quay lai|quay lại)\b/i.test(text) && !repeatedRx.test(text)) {
      matches.push({ family: 'adaptive', predicate: 'evidence-responsive-revisit', id: 'reconstructed:evidence-responsive-revisit', dimension: 'information', position: 'neutral' });
    }

    if (ceased) matches.splice(0, matches.length);
    if (external && matches.every((row) => row.family !== 'adaptive')) matches.splice(0, matches.length);

    return {
      phase_id: index + 1,
      text,
      owner,
      subject: owner.type.includes('third_party') || owner.type === 'third_party' ? 'third_party' : 'self',
      source_of_claim: owner.source,
      negation: negatedAvoidance ? 'NOT(avoid)' : ceased ? 'NO_LONGER' : 'none',
      temporal_status: ceased ? 'ceased' : 'current_or_unspecified',
      evidence_state: newEvidence ? 'new_evidence' : sufficient ? 'sufficient' : 'unspecified',
      external_constraint: external,
      predicates: matches,
    };
  }

  function semanticParse(raw) {
    const phases = splitPhases(raw).map(phaseSemantics);
    for (let index = 0; index < phases.length - 1; index += 1) {
      const phase = phases[index];
      const next = phases[index + 1];
      if (!phase.predicates.length && next.evidence_state === 'new_evidence' && /\b(?:revisit\w*|review\w* again|xem lai|quay lai)\b/i.test(phase.text)) {
        phase.predicates.push({ family: 'adaptive', predicate: 'evidence-responsive-revisit', id: 'reconstructed:evidence-responsive-revisit', dimension: 'information', position: 'neutral' });
      }
    }
    const selfPhases = phases.filter((phase) => phase.subject === 'self' && !phase.owner.disputed);
    const responses = selfPhases.flatMap((phase) => phase.predicates.map((row) => ({ ...row, phase_id: phase.phase_id })));
    const families = [];
    for (const row of responses) if (!families.includes(row.family)) families.push(row.family);
    return {
      version: VERSION,
      representation: 'proposition-clause-v1-reconstructed',
      phases,
      responses,
      families,
      sequence: phases.length > 1 && responses.length > 1,
      ownership: ownership(raw),
    };
  }

  function inputRoute(raw) {
    const original = base.inputRoute(raw);
    if (original.must_redirect) return original;
    const parsed = semanticParse(raw);
    if (parsed.ownership.type === 'third_party' || parsed.ownership.type === 'attributed_third_party') {
      return { id: 'input:third-party-only', action: 'clarify', must_stop: true, must_redirect: false };
    }
    if (parsed.ownership.type === 'attributed_self' && !parsed.ownership.self_confirmed) {
      return { id: parsed.ownership.disputed ? 'input:attributed-self-disputed' : 'input:attributed-self-unconfirmed', action: 'clarify', must_stop: true, must_redirect: false };
    }
    return original;
  }

  function analyze(raw, domain = 'other', subtopic = null) {
    const original = base.analyze(raw, domain, subtopic);
    const parsed = semanticParse(raw);
    const route = inputRoute(raw);
    const reconstructed = parsed.responses;
    const thirdPartyOnly = route.id === 'input:third-party-only';
    const foldedRaw = fold(raw);
    const semanticExclusive = parsed.phases.some((phase) => phase.negation !== 'none' || phase.temporal_status === 'ceased') ||
      parsed.responses.some((row) => row.family === 'adaptive') ||
      (/\b(?:nguon luc|resource|capacity)\b/.test(foldedRaw) && parsed.families.includes('fast')) ||
      (parsed.families.includes('ignore') && parsed.families.includes('fast') && /\b(?:tri hoan them|delay(?:ed|ing)? further)\b/.test(foldedRaw));
    const responses = [];
    if (!thirdPartyOnly) {
      for (const row of semanticExclusive ? reconstructed : [...original.responses, ...reconstructed]) {
        if (!responses.some((existing) => existing.id === row.id || (existing.family === row.family && existing.phase_id === row.phase_id))) responses.push(row);
      }
    }
    const families = [];
    for (const row of responses) if (!families.includes(row.family)) families.push(row.family);
    const activeFamilies = parsed.phases.some((phase) => phase.temporal_status === 'ceased') && !reconstructed.length ? [] : families;
    return {
      ...original,
      version: VERSION,
      provenance: METADATA,
      semantic_representation: parsed,
      responses,
      families: activeFamilies,
      sequence: parsed.sequence || original.sequence,
      oscillation: parsed.sequence || original.oscillation,
      response_known: activeFamilies.length > 0,
      input_route: route,
      can_continue: route.action === 'continue',
      must_stop: route.must_stop,
      must_redirect: route.must_redirect,
      historical_or_ceased: parsed.phases.some((phase) => phase.temporal_status === 'ceased'),
    };
  }

  function evaluate(frame, evidence = {}) {
    const result = base.evaluate(frame, evidence);
    if (frame.historical_or_ceased && !frame.response_known) {
      return { ...result, version: VERSION, classification: 'residual_or_old', pattern_claim_allowed: false, analysis_level: 'meaningful_issue_without_pattern' };
    }
    return { ...result, version: VERSION };
  }

  function contract(frame, evidence = {}) {
    const result = evaluate(frame, evidence);
    return {
      topic_id: frame.topic_id,
      input_route: frame.input_route.id,
      families: [...frame.families],
      sequence: frame.sequence,
      phases: frame.semantic_representation.phases.map((phase) => ({
        phase_id: phase.phase_id,
        subject: phase.subject,
        source_of_claim: phase.source_of_claim,
        negation: phase.negation,
        temporal_status: phase.temporal_status,
        evidence_state: phase.evidence_state,
        predicates: phase.predicates.map((row) => row.predicate),
        families: phase.predicates.map((row) => row.family),
      })),
      classification: result.classification,
      pattern_claim_allowed: result.pattern_claim_allowed,
      must_stop: !!result.must_stop,
      must_redirect: !!result.must_redirect,
    };
  }

  global.QCSemanticCoreV4 = {
    ...base,
    version: VERSION,
    metadata: METADATA,
    semanticParse,
    inputRoute,
    analyze,
    evaluate,
    contract,
    schema: Object.freeze({ ...base.schema, representation: 'proposition-clause-v1-reconstructed', provenance: 'reconstructed' }),
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
