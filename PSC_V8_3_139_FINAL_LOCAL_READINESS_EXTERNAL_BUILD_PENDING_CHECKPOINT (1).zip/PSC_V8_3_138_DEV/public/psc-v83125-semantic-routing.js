(function(global){
'use strict';
const parent=global.QCSemanticCoreV4;
if(!parent||parent.version!=='V8.3.124-OPERATOR-GOVERNANCE-REVIEW-CANDIDATE')throw new Error('V8.3.125 requires frozen V8.3.124 failed RC');
const VERSION='V8.3.125-SEMANTIC-ROUTING-REVIEW-QUALIFICATION-CANDIDATE';
const fold=v=>global.QCSemanticCoreV3.fold(v).replace(/[’‘]/g,"'").replace(/\s+/g,' ').trim();
const metadata=Object.freeze({version:VERSION,parent:'V8.3.124 FAILED REVIEW CANDIDATE',target:'semantic routing + compositional review qualification',production_authorized:false,step_111:'prohibited'});
const RX=Object.freeze({
  self:/(?:\b(?:i|i'm|i am|my|me|toi|minh|tao)\b|(?:^|\s)(?:tôi|mình)(?:\s|$))/i,
  third:/\b(?:my (?:colleague|friend|manager|boss|partner)|they|he|she|someone|mot nguoi|dong nghiep|ban toi|sep toi|nguoi yeu toi)\b/i,
  nonreal:/\b(?:suppose|hypothetically|imagine|for example|as an example|gia su|neu mot nguoi)\b|\bvi du(?: nhu|\s*[:,])/i,
  avoid:/\b(?:avoid\w*|sidestep\w*|disengag\w*|withdraw\w*|ne|tranh|bo qua|rut lui)\b/i,
  negator:/\b(?:not|never|didn'?t|don'?t|doesn'?t|cannot|can'?t|khong|chang|chua)\b/i,
  reviewHead:/\b(?:review\w*|check\w*|recheck\w*|revisit\w*|re-read|reread|xem(?: lai| lại)?|kiem tra|kiểm tra|doi chieu|đối chiếu|viec xem|việc xem)\b/i,
  reviewObject:/\b(?:draft|assumption|evidence|information|detail|fact|document|proposal|plan|ban nhap|bản nháp|gia dinh|giả định|du kien|dữ kiện|thong tin|thông tin|chi tiet|chi tiết|tai lieu|tài liệu|de xuat|đề xuất|ke hoach|kế hoạch)\b/i,
  repeated:/\b(?:keep|kept|keeps|repeatedly|continually|again and again|over and over|multiple times|many times|lap di lap lai|lặp đi lặp lại|nhieu lan|nhiều lần|cu|cứ)\b/i,
  sufficient:/\b(?:enough|sufficient|already clear|everything was clear|nothing changed|settled|da du|đã đủ|du thong tin|đủ thông tin|moi thu da ro(?: roi)?|mọi thứ đã rõ(?: rồi)?|da ro(?: roi)?|đã rõ(?: rồi)?|khong co gi thay doi|không có gì thay đổi)\b/i,
  missing:/\b(?:missing|incomplete|unclear|not enough|needed more|con thieu|chua du|chua ro|thieu thong tin)\b/i,
  changed:/\b(?:new|changed|updated|additional|amended|revised|moi|mới|thay doi|thay đổi|cap nhat|cập nhật)\b/i,
  single:/\b(?:once|one time|one|a single|mot lan|một lần|dung mot lan|đúng một lần|mot|một)\b/i,
  duration:/\b(?:for\s+(?:\d+|ten|five|fifteen)\s+minutes?|trong\s+(?:\d+|muoi|mười|nam|năm|muoi lam|mười lăm)\s+(?:phut|phút))\b/i,
  bounded:/\b(?:briefly|quick review|bounded|ngan gon)\b/i,
  required:/\b(?:required|necessary|needed|can thiet|bat buoc)\b/i,
  completion:/\b(?:then stopped|stopped after|stop(?:ped)? when|decide when|only once|xong thi dung|dung sau|dung khi|dừng khi|chot khi|chốt khi)\b/i
  ,sequence:/\b(?:and then|then|after that|later|finally|sau do|sau đó|tiep theo|tiếp theo|roi|rồi)\b/i
  ,fast:/\b(?:decid\w*|act\w*|respond\w*|commit\w*|quyet|quyết|phan hoi|phản hồi|hanh dong|hành động|nhan loi|nhận lời|chot|chốt)\b.{0,28}\b(?:immediately|straight away|quickly|hastily|ngay|ngay lập tức|voi|vội)\b/i
  ,freeze:/\b(?:become stuck|got stuck|stood still|could not (?:act|decide|move|choose)|cannot (?:act|decide|move|choose)|dung lai|đứng lại|mac ket|mắc kẹt|khong chon duoc|không chọn được|khong the (?:lam|quyet|di|chon)|không thể (?:làm|quyết|đi|chọn))\b/i
  ,slowExtended:/\b(?:check\w*|review\w*|kiem tra|kiểm tra|xem)\b.{0,24}\b(?:for a long time|too long|rat lau|rất lâu)\b/i
  ,slowPreparation:/\b(?:prepare\w*|chuan bi|chuẩn bị)\b.{0,24}\b(?:for too long|too long|qua lau|quá lâu)\b/i
  ,delay:/\b(?:delay\w*|procrastinat\w*|tri hoan|trì hoãn|cham bat dau|chậm bắt đầu)\b/i
  ,consult:/\b(?:ask\w*.{0,24}(?:people|opinion|input|reassurance)|consult\w*|hoi them|hỏi thêm|tham khao|tham khảo)\b/i
  ,prepareMore:/\b(?:prepare further|prepare more|chuan bi them|chuẩn bị thêm)\b/i
  ,adaptiveComposite:/\b(?:adjust\w*|adapt\w*|ready to update|dieu chinh|điều chỉnh|san sang cap nhat|sẵn sàng cập nhật)\b.{0,36}\b(?:new|changed|updated|moi|mới|thay doi|thay đổi|cap nhat|cập nhật)?\b|\b(?:new|changed|updated|moi|mới|thay doi|thay đổi|cap nhat|cập nhật)\b.{0,36}\b(?:adjust\w*|adapt\w*|ready to update|dieu chinh|điều chỉnh|san sang cap nhat|sẵn sàng cập nhật)\b/i
  ,ignoreAction:/\b(?:move to something else|switch to something else|keep busy|do not open|don't open|leave\w*.{0,12}(?:unopened|unread)|chuyen sang viec khac|chuyển sang việc khác|giu minh ban|giữ mình bận|khong mo|không mở)\b/i
  ,externalConstraint:/\b(?:waiting for approval|lack authority|do not have authority|cho phe duyet|chờ phê duyệt|chua co quyen|chưa có quyền)\b/i
});
const has=(rx,t)=>rx.test(t);
function routeFacts(raw){const t=fold(raw),nonreal=has(RX.nonreal,t),selfMarker=has(RX.self,t),roleThird=/\b(?:my (?:colleague|friend|manager|boss|partner)|dong nghiep|đồng nghiệp|ban toi|bạn tôi|sep toi|sếp tôi|nguoi yeu toi|người yêu tôi)\b/i.test(t),third=roleThird||(has(RX.third,t)&&!selfMarker),self=selfMarker&&!roleThird;return{actor:third?'third-party':self?'self':'unspecified',ownership:third?'third-party':self?'self':'unspecified',reality:nonreal?'hypothetical-or-example':'real',positive_self_lived_assertion:self&&!nonreal&&!third};}
function reviewFacts(raw){const t=fold(String(raw).split(/[.!?;]/)[0]),head=has(RX.reviewHead,t),object=has(RX.reviewObject,t),nominalized=/\b(?:viec|việc|the act of)\s+(?:xem|kiem tra|kiểm tra|reviewing|checking)\b/i.test(t);if(!(head&&(object||nominalized)))return{recognized:false};const repeated=has(RX.repeated,t),sufficient=has(RX.sufficient,t),missing=has(RX.missing,t),changed=has(RX.changed,t),single=has(RX.single,t),duration=has(RX.duration,t),bounded=single||duration||has(RX.bounded,t)||has(RX.completion,t);return{recognized:true,predicate:nominalized?'nominalized-review':'review-evidence',object_class:'reviewable-evidence',repeated,sufficient,missing,changed,single,duration,bounded,required:has(RX.required,t)};}
function qualifyReview(f){if(!f.recognized)return null;if(f.sufficient&&f.repeated)return{family:'slow',reason:'REPEATED_REVIEW_AFTER_SUFFICIENT_EVIDENCE'};if((f.changed||f.missing)&&f.bounded&&!f.repeated)return{family:'adaptive',reason:'BOUNDED_PROPORTIONAL_REVIEW_OF_CHANGED_OR_MISSING_EVIDENCE'};if(f.repeated)return{family:'slow',reason:'REPEATED_REVIEW'};return null;}
function sequenceFamilies(raw){const t=fold(raw);if(!has(RX.sequence,t))return[];const out=[];if(has(RX.slowExtended,t)||has(RX.slowPreparation,t))out.push('slow');if(has(RX.fast,t))out.push('fast');if(has(RX.freeze,t))out.push('freeze');if(has(RX.avoid,t)&&!has(RX.negator,t))out.push('ignore');return out;}
function primaryFamily(raw){const t=fold(raw);if(has(RX.adaptiveComposite,t)&&has(RX.sufficient,t))return'adaptive';if((has(RX.slowExtended,t)||has(RX.slowPreparation,t)||has(RX.reviewHead,t)&&has(RX.delay,t)||has(RX.consult,t)&&has(RX.prepareMore,t)))return'slow';if(has(RX.freeze,t)||has(RX.externalConstraint,t))return'freeze';if(has(RX.ignoreAction,t)||has(RX.avoid,t)&&!has(RX.negator,t))return'ignore';if(has(RX.fast,t))return'fast';return null;}
function semanticNormalize(raw){const inherited=parent.semanticNormalize(raw),route=routeFacts(raw),review=reviewFacts(raw),qualification=qualifyReview(review),t=fold(raw),negatedAvoid=has(RX.avoid,t)&&has(RX.negator,t),propositions=[...(inherited.propositions||[])];if(review.recognized)propositions.push({proposition_id:'v125.review.1',text:String(raw),predicate:review.predicate,candidate_family:qualification&&qualification.family,family_candidate:qualification&&qualification.family,polarity:'positive',reality_status:route.reality==='real'?'real-self-lived':'hypothetical',ownership:route.ownership,evidence_sufficiency:review.sufficient?'sufficient':review.missing?'missing':'unspecified',new_evidence:review.changed,repetition:review.repeated,bounded:review.bounded,cardinality:review.single?'single':'unspecified',duration_bounded:review.duration,adaptive_qualification:qualification&&qualification.reason,suppression_reason:route.reality!=='real'?'NON_REAL_PROPOSITION_CANNOT_BECOME_ACTIVE_SELF_FAMILY':route.ownership==='third-party'?'NON_SELF_PROPOSITION_NOT_ACTIVE':null,eligible_family:route.reality==='real'&&route.ownership!=='third-party'&&qualification?qualification.family:null,activation_status:route.reality==='real'&&route.ownership!=='third-party'&&qualification?'active':'suppressed',rule_source:'V8_3_125_COMPOSITIONAL_REVIEW_QUALIFICATION'});return{...inherited,version:VERSION,route_assertion:route,review_qualification:review.recognized?{...review,qualification}:null,propositions,trace:{...(inherited.trace||{}),v83125:{route,review,qualification,negatedAvoid}}};}
function analyze(raw,domain='other',subtopic=null){
  const inherited=parent.analyze(raw,domain,subtopic),semantic=semanticNormalize(raw),routeFactsV=semantic.route_assertion,review=semantic.review_qualification,qualification=review&&review.qualification,t=fold(raw),negatedAvoid=has(RX.avoid,t)&&has(RX.negator,t),authoritativeReview=!!qualification,responses=(inherited.responses||[]).map(x=>({...x}));
  let kept=responses;
  if(authoritativeReview)kept=kept.filter(x=>!['slow','adaptive'].includes(x.family));
  if(negatedAvoid)kept=kept.filter(x=>x.family!=='ignore');
  if(qualification&&routeFactsV.reality==='real'&&routeFactsV.ownership!=='third-party')kept.push({id:`v83125:${qualification.family}:${review.predicate}`,predicate:review.predicate,family:qualification.family,phase_id:1,confidence:'direct',dimension:qualification.family==='slow'?'information':'adaptation',position:qualification.family==='adaptive'?'neutral':'A',qualification_reason:qualification.reason});
  const seqFamilies=sequenceFamilies(raw);
  for(const [i,family] of seqFamilies.entries())if(!kept.some(x=>x.family===family))kept.push({id:`v83125:sequence:${family}`,predicate:`sequence-${family}`,family,phase_id:i+1,confidence:'direct',dimension:family==='slow'?'information':'engagement',position:'A'});
  const primary=qualification?qualification.family:primaryFamily(raw);
  if(primary&&routeFactsV.reality==='real'&&routeFactsV.ownership!=='third-party'){
    const existing=kept.find(x=>x.family===primary);
    kept=kept.filter(x=>x.family!==primary);
    kept.unshift(existing||{id:`v83125:primary:${primary}`,predicate:`primary-${primary}`,family:primary,phase_id:1,confidence:'direct',dimension:primary==='slow'?'information':'engagement',position:'A'});
  }
  const families=[];for(const x of kept)if(!families.includes(x.family))families.push(x.family);
  let route={...inherited.input_route};
  if(negatedAvoid&&routeFactsV.positive_self_lived_assertion)route={...route,id:'input:self-lived',action:'continue',must_stop:false,must_redirect:false};else if(routeFactsV.ownership==='third-party'&&routeFactsV.reality==='real')route={...route,id:'input:third-party-only',action:'clarify',must_stop:false,must_redirect:false};
  const blocked=route.id==='input:hypothetical-or-example'||route.id==='input:third-party-only',finalResponses=blocked?[]:kept,finalFamilies=blocked?[]:families,sequence=blocked?false:(seqFamilies.length>1||inherited.sequence);
  return{...inherited,version:VERSION,metadata,input_route:route,semantic_representation:semantic,responses:finalResponses,families:finalFamilies,sequence,oscillation:sequence,response_known:finalFamilies.length>0,can_continue:route.action==='continue',must_stop:!!route.must_stop,must_redirect:!!route.must_redirect};
}
function evaluate(frame,evidence={}){const inherited=parent.evaluate(frame,evidence),clarify=['input:hypothetical-or-example','input:third-party-only'].includes(frame.input_route.id);return clarify?{...inherited,version:VERSION,classification:'clarification_required',pattern_claim_allowed:false,must_stop:false,must_redirect:false}:{...inherited,version:VERSION};}
function contract(frame,evidence={}){const r=evaluate(frame,evidence);return{topic_id:frame.topic_id,input_route:frame.input_route.id,families:[...frame.families],sequence:frame.sequence,propositions:frame.semantic_representation.propositions,classification:r.classification,pattern_claim_allowed:r.pattern_claim_allowed,must_stop:!!r.must_stop,must_redirect:!!r.must_redirect};}
const invariants=Object.freeze([...(parent.invariants||[]),'ROUTE_ASSERTION_INDEPENDENT_OF_FAMILY_ELIGIBILITY','NOMINALIZED_AND_VERBAL_REVIEW_PARITY','REVIEW_MODIFIERS_BIND_BEFORE_QUALIFICATION','SUFFICIENT_REPEATED_REVIEW_IS_SLOW','BOUNDED_CHANGED_EVIDENCE_REVIEW_IS_ADAPTIVE','AUTHORITATIVE_REVIEW_PREVENTS_PARENT_FAMILY_LEAK']);
global.QCSemanticCoreV4={...parent,version:VERSION,metadata,semanticNormalize,analyze,evaluate,contract,invariants,schema:Object.freeze({...parent.schema,semanticVersion:'semantic-routing-review-qualification-v1',routeAssertion:true,compositionalReview:true})};
})(typeof globalThis!=='undefined'?globalThis:this);
