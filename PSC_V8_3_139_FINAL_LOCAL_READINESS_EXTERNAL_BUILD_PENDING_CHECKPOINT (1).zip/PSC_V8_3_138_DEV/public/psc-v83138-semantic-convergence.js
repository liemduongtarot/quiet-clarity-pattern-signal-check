(function(global){
'use strict';
const parent=global.QCSemanticCoreV8;
if(!parent)throw new Error('V8.3.138 requires V8.3.135 canonical runtime');
const VERSION='V8.3.138-SEALED-A-FAILURE-CONVERGENCE';
const metadata=Object.freeze({version:VERSION,parent:'V8.3.137 FAILED REVIEW CANDIDATE',classification:'LEVEL-1 SEMANTIC CONVERGENCE REPAIR',source_failures:'V8.3.137 immutable Batch A first-run 12 failures',consumers:'FROZEN_FROM_V8.3.133',production_authorized:false,production_lock:'prohibited',sealed_validation:'not-authorized',step_111:'prohibited'});
const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().replace(/\s+/g,' ').trim();
const ACTOR=(prev,type,ownership,surface)=>({...prev,actor_id:type==='self'?'a:self':type==='third-party'?'a:third-party':'a:unknown',surface:surface||prev?.surface||'',actor_type:type,person:type==='self'?'first':type==='unknown'?'unknown':'third',ownership,behavior_ownership:ownership});
const isBehavior=p=>['review','seek-input','preparation','avoid-engagement','unable-to-act','premature-close','proportionate-act'].includes(p.predicate);
function repairState(raw){
 const state=parent.buildCanonicalState(raw), doc=fold(raw), ps=state.propositions;
 // 1. Meta-disclosure of missing response evidence is not itself a lived behavioral proposition.
 for(const p of ps){const t=fold(p.source_span?.text);if(p.polarity==='negative'&&p.predicate==='unknown'&&/(chua noi ro|chua mo ta|chua noi minh|not said clearly|haven't described|have not described).{0,50}(phan ung|react|response)/.test(t)){p.actor=ACTOR(p.actor,'unknown','unknown','');p.roles={...p.roles,subject_actor_id:'a:unknown',agent_actor_id:'a:unknown',behavior_ownership:'unknown'};p.relation_derived_facts?.push('META_DISCLOSURE_NOT_BEHAVIOR_EVIDENCE');}}
 // 2. Cessation/current-inactive statements scope backward to the referenced earlier behavior.
 const cessationIndex=ps.findIndex(p=>/(da dung han|da dung (?:han )?(?:viec|lam|kiem tra|xem)|khong con xay ra|khong con lam|stopped completely|stopped (?:doing|checking|reviewing)|no longer happens|no longer do)/.test(fold(p.source_span?.text)));
 if(cessationIndex>=0){for(let i=0;i<cessationIndex;i++){const p=ps[i];if(p.actor?.actor_type==='self'&&isBehavior(p)){p.cessation_status='ceased';p.current_status='inactive';p.relation_derived_facts?.push('LATER_CESSATION_SCOPED_TO_PRIOR_BEHAVIOR');}}}
 // 3. Changed evidence + single bounded review is adaptive; changed evidence supplies the review boundary.
 for(const p of ps){if(p.predicate==='review'&&p.evidence_change==='changed'&&p.repetition!=='repeated'){p.boundedness='bounded';p.relation_derived_facts?.push('CHANGED_EVIDENCE_BOUNDS_REVIEW');}}
 // 4. External system/service failure blocks action externally, not as internal freeze.
 const externalFailure=ps.find(p=>/(cong|portal|system|service|he thong).{0,45}(bi loi|loi|down|offline|unavailable|error|hong)/.test(fold(p.source_span?.text))||/(bi loi|down|offline|unavailable|error).{0,45}(cong|portal|system|service|he thong)/.test(fold(p.source_span?.text)));
 if(externalFailure){externalFailure.constraint_status='external';externalFailure.constraint_type='external-system-failure';externalFailure.external_prevention=true;externalFailure.actor=ACTOR(externalFailure.actor,'third-party','third-party','external system');for(const p of ps){if(p.predicate==='unable-to-act'&&p.actor?.actor_type==='self'){p.constraint_status='external';p.constraint_type='external-prevention';p.constraint_source=externalFailure.source_span?.text;p.external_prevention=true;p.internal_freeze_state=false;p.relation_derived_facts?.push('EXTERNAL_SYSTEM_FAILURE_PROPAGATED');}}}
 // 5. Direct freeze surfaces missed by earlier predicate inventory.
 for(const p of ps){const t=fold(p.source_span?.text);if(/(dung hinh|khong lam gi duoc|khong the lam gi|froze|could not do anything|couldn't do anything)/.test(t)){p.predicate=p.predicate_class='unable-to-act';p.polarity='positive';p.relation_derived_facts?.push('DIRECT_FREEZE_SURFACE_RESOLVED');}}
 // 6. Avoidance can be expressed as leaving an item unopened, purposefully doing another task, or explicit né.
 for(const p of ps){const t=fold(p.source_span?.text);if(/(de .{0,50}(chua mo|chua doc).{0,35}(ngay hom sau|mai)|khoi phai (mo|doc|xem)|de khoi (mo|doc|xem)|\bne\b|\btranh\b|leave .{0,40} unopened|so (?:i|we) (?:do not|don't) have to open)/.test(t)){p.predicate=p.predicate_class='avoid-engagement';p.polarity='positive';p.relation_derived_facts?.push('PURPOSE_OR_DELAYED_OPEN_AVOIDANCE_RESOLVED');}}
 // 7. Third-party reported attribution: possessor "của tôi" does not make the reported group's behavior self-owned.
 for(const p of ps){const t=fold(p.source_span?.text);if(/^(theo|according to) .{0,35}(quan ly|manager|sep|boss).{0,35}(nhom cua ho|their team|team cua ho)/.test(t)){p.actor=ACTOR(p.actor,'third-party','third-party','reported third party');p.roles={...p.roles,subject_actor_id:'a:third-party',agent_actor_id:'a:third-party',reported_actor_id:'a:third-party',behavior_ownership:'third-party'};p.quotation_status='reported';p.relation_derived_facts?.push('REPORTED_THIRD_PARTY_HEAD_OUTRANKS_POSSESSIVE_SELF');}}
 // 8. Explicit multi-phase close is a fast phase when it is the terminal action in a declared sequence.
 const hasSequence=/(ban dau|sau do|roi cuoi cung|cuoi cung|initially|then|eventually|finally)/.test(doc);
 if(hasSequence){for(const p of ps){const t=fold(p.source_span?.text);if(/(chot quyet dinh|quyet dinh ngay|decide|commit)/.test(t)&&/(cuoi cung|finally|eventually)/.test(t)){p.predicate=p.predicate_class='premature-close';p.relation_derived_facts?.push('EXPLICIT_TERMINAL_CLOSE_PHASE_RESOLVED');}}}
 return state;
}
function deriveCanonical(state){
 const derived=parent.deriveCanonical(state);
 // Unknown-only ownership is clarification-required, not third-party-only.
 if(derived.route?.id==='input:third-party-only'&&state.propositions.length&&state.propositions.every(p=>p.actor?.actor_type==='unknown'))derived.route={id:'input:clarification-required',derived_from:['propositions.actor'],rule:'unknown-only-ownership-clarification-v1'};
 // Mixed actual + local hypothetical: a real self-lived proposition keeps the public route self-lived.
 if(derived.route?.id==='input:hypothetical-or-example'&&state.propositions.some(p=>p.reality_status==='actual'&&p.actor?.actor_type==='self'&&p.polarity==='positive'&&p.predicate!=='unknown'))derived.route={id:'input:self-lived',derived_from:['propositions.reality_status','propositions.actor'],rule:'mixed-actual-local-hypothetical-self-lived-v1'};
 // One bounded check after already-sufficient evidence is ordinary/proportionate, not an adaptive family signal by itself.
 const suppressIds=new Set(state.propositions.filter(p=>p.predicate==='review'&&p.evidence_sufficiency==='sufficient'&&p.evidence_change!=='changed'&&p.repetition!=='repeated'&&p.boundedness==='bounded').map(p=>p.proposition_id));
 if(suppressIds.size){for(const d of state.family_decisions||[])if(suppressIds.has(d.proposition_id)&&d.candidate==='adaptive'){d.eligible=false;d.rule='SUFFICIENT_SINGLE_BOUNDED_REVIEW_NO_PATTERN_FAMILY';}derived.families=derived.families.filter(f=>state.family_decisions.some(d=>d.eligible&&d.candidate===f));}
 return derived;
}
function routeFrame(route){const redirect=['input:safety','input:prediction','input:decision-request','input:hypothetical-or-example'].includes(route.id),clarify=['input:third-party-only','input:clarification-required'].includes(route.id);return{...route,action:redirect?'redirect':clarify?'clarify':'continue',must_stop:['input:safety','input:prediction','input:decision-request'].includes(route.id),must_redirect:redirect};}
function analyze(raw,domain='other',subtopic=null){const diagnostic=parent.analyze(raw,domain,subtopic),state=repairState(raw),derived=deriveCanonical(state),route=routeFrame(derived.route);return{...diagnostic,version:VERSION,metadata,input_route:route,families:[...derived.families],sequence:derived.sequence.sequence,oscillation:derived.sequence.sequence,response_known:derived.families.length>0,can_continue:route.action==='continue',must_stop:!!route.must_stop,must_redirect:!!route.must_redirect,canonical_semantic_state:state,canonical_shadow:{derived,legacy:{families:[...(diagnostic.families||[])],route:diagnostic.input_route?.id,sequence:!!diagnostic.sequence},difference_classification:'V8_3_138_LEVEL1_CONVERGENCE',invariant_violations:[...(diagnostic.canonical_shadow?.invariant_violations||[])]}};}
const core={...parent,version:VERSION,metadata,buildCanonicalState:repairState,deriveCanonical,analyze,inputRoute:raw=>analyze(raw).input_route,schema:Object.freeze({...parent.schema,canonicalSemanticState:'css-proposal-v5-sealed-failure-convergence'})};
global.QCSemanticCoreV9=core;global.PSC_V83138=core;if(global.document&&global.document.documentElement)global.document.documentElement.dataset.pscSemanticAuthority='V8.3.138:sealed-failure-convergence';
})(typeof globalThis!=='undefined'?globalThis:this);
