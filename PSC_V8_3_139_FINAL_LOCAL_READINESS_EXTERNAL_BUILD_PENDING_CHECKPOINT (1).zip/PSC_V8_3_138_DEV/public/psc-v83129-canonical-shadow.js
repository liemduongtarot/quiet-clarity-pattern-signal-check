(function (global) {
  'use strict';
  const legacy = typeof QCSemanticCoreV4 !== 'undefined' ? QCSemanticCoreV4 : global.QCSemanticCoreV4;
  if (!legacy) throw new Error('V8.3.129 requires frozen V8.3.128 parent runtime');

  const VERSION = 'V8.3.129-CANONICAL-SEMANTIC-STATE-SHADOW';
  const metadata = Object.freeze({
    version: VERSION,
    parent: 'V8.3.128 FAILED REVIEW CANDIDATE',
    classification: 'CANONICAL SEMANTIC STATE IMPLEMENTATION + SHADOW-MODE AUTHORITY MIGRATION',
    shadow_mode: false,
    authority_mode: 'canonical-state',
    legacy_role: 'diagnostic-shadow-only',
    production_authorized: false,
    production_lock: 'prohibited',
    step_111: 'prohibited'
  });
  const semanticV3 = typeof QCSemanticCoreV3 !== 'undefined' ? QCSemanticCoreV3 : global.QCSemanticCoreV3;
  const fold = value => semanticV3.fold(String(value || '')).replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim();
  const FACT_OWNER = Object.freeze({
    clause:'clause-graph-builder', proposition:'proposition-builder', actor:'actor-resolver', ownership:'ownership-resolver',
    predicate:'predicate-normalizer', object:'object-classifier', polarity:'operator-resolver', negation_scope:'operator-resolver',
    cessation_status:'operator-resolver', reality_status:'frame-resolver', attribution:'attribution-resolver', constraint_status:'constraint-resolver',
    frequency:'quantifier-resolver', repetition:'quantifier-resolver', evidence_sufficiency:'evidence-reducer', evidence_change:'evidence-reducer',
    boundedness:'quantifier-resolver', question_intent:'intent-resolver', speech_act:'intent-resolver', temporal_relation:'relation-builder',
    family_eligibility:'family-consumer', public_route:'route-consumer'
  });
  const RX = Object.freeze({
    self:/\b(?:i|me|my|myself|toi|tôi|minh|mình|tui)\b/i,
    group:/\b(?:we|our|ours|us|chung toi|chúng tôi|chung minh|chúng mình)\b/i,
    generic:/\b(?:someone|somebody|one|a person|mot nguoi|một người|nguoi ta|người ta)\b/i,
    roleSubject:/^\s*(?:(my|our|the|a|an)\s+)?([a-z][a-z-]*(?:\s+[a-z][a-z-]*){0,3})\s+(?:did|does|has|had|is|was|will|might|may|could|cannot|can\s+not|keeps?|stopped?|abandoned|checked|reopened|asked|avoided|reviewed|compared|verified|inspected|reversed|issued|withdrew|decided|postponed|continues?|archived|switched|became)\b/i,
    hypothetical:/\b(?:suppose|supposing|imagine|imagining|hypothetically|thought experiment|thought-experiment|what if|gia su|giả sử|neu thu|nếu thử)\b/i,
    fictional:/\b(?:fictional|imaginary|invented|made-up|nonexistent|unreal|pretend|hư cấu|tưởng tượng)\b/i,
    example:/\b(?:for example|as an example|invented example|chẳng hạn)\b|^(?:ví dụ|vi du)\b|[,;:]\s*(?:ví dụ|vi du)\b/i,
    conditional:/\b(?:if|provided that|unless|neu|nếu)\b/i,
    counterfactual:/\b(?:if only|would have|had i|gia nhu|giá như)\b/i,
    quote:/["“”]|\b(?:said|says|reported|according to|theo lời|noi rang|nói rằng|báo rằng)\b/i,
    negation:/\b(?:not|never|no longer|didn'?t|doesn'?t|don'?t|wasn'?t|isn'?t|khong|không|chang|chẳng|chua|chưa)\b/i,
    cessation:/\b(?:stopped?|ceased|no longer|not anymore|abandoned|gave up|quit|khong con|không còn|dung lai|dừng lại|bo han|bỏ hẳn)\b/i,
    repeated:/\b(?:keep|keeps|kept|continue|continues|continued|repeatedly|again|three times|every|continually|constantly|over and over|for hours|very long|cu|cứ|them|thêm|lap lai|lặp lại|nhieu lan|nhiều lần|liên tục|doc di doc lai|đọc đi đọc lại|rat lau|rất lâu)\b/i,
    single:/\b(?:once|one|single|briefly|necessary|required|fifteen-minute|twelve minutes|until|mot lan|một lần|chỉ một|can thiet|cần thiết|phu hop|phù hợp|trong .+ phut|phút)\b/i,
    sufficient:/\b(?:enough|sufficient|complete|settled|resolved|documented|fully explained|nothing .+ changed|unchanged|identical|da du|đã đủ|ro roi|rõ rồi|hoan tat|hoàn tất)\b/i,
    insufficient:/\b(?:not enough|insufficient|incomplete|unclear|not clear|missing|before .+ (?:complete|clear|known)|chua du|chưa đủ|thieu|thiếu|chua ro|chưa rõ|khong ro|không rõ|truoc khi .+ ro|trước khi .+ rõ)\b/i,
    changed:/\b(?:new|fresh|revised|corrected|amended|changed|shifted|updated|modified|refreshed|additional|mới|sua|sửa|thay doi|thay đổi|du kien moi|thong tin moi|chi tiet moi)\b/i,
    unchanged:/\b(?:unchanged|identical|same|nothing .+ changed|khong doi|không đổi|y nhu cu|y như cũ)\b/i,
    external:/\b(?:deadline|requirement|client|system down|permission|approval|experiment ended|window closed|because .+ unavailable|han chot|hạn chót|yeu cau|yêu cầu)\b/i,
    question:/\?\s*$|^(?:who|what|when|where|why|how|which|will|would|should|shall|can|could|is|are|do|does|ai|gi|gì|khi nao|khi nào|bao gio|bao giờ|tai sao|tại sao|nen|nên|co nen|có nên)\b/i,
    prediction:/\b(?:likely|will|would|forecast|predict|when|next quarter|khi nao|khi nào|bao gio|bao giờ|se|sẽ)\b/i,
    decisionQuestion:/\b(?:should|shall|would .+ better|which .+ adopt|which .+ choose|co nen|có nên|nen|nên|nen chon|nên chọn)\b/i,
    behavioralQuestion:/\b(?:why do i|why am i|why do we|tai sao toi|tại sao tôi|vi sao minh|vì sao mình)\b/i,
    infoQuestion:/\b(?:what|who|where|how|which|gi|gì|ai|o dau|ở đâu|nhu the nao|như thế nào)\b/i
  });
  const OBJECT_CLASSES = Object.freeze([
    ['communication',/\b(?:message|request|email|notice|warning|response|reply|conversation|complaint|explanation|transcript|citation|answer|tin nhan|tin nhắn|yeu cau|yêu cầu|email|phan hoi|phản hồi|tra loi|trả lời|cuoc noi chuyen|cuộc nói chuyện|noi dung|nội dung)\b/i],
    ['evidence',/\b(?:evidence|fact|data|measurement|baseline|assumption|premise|reading|calibration|exception|record|timestamp|calculation|total|inventory|file|conclusion|detail|information|condition|du kien|dữ kiện|thong tin|thông tin|bang chung|bằng chứng|ket luan|kết luận|dieu kien|điều kiện|chi tiet|chi tiết)\b/i],
    ['document',/\b(?:draft|document|clause|agreement|proposal|map|plan|report|ban nhap|bản nháp|tai lieu|tài liệu|hop dong|hợp đồng)\b/i],
    ['decision-option',/\b(?:choice|decision|option|alternative|proposal|door|plan|offer|lua chon|lựa chọn|quyet dinh|quyết định|phuong an|phương án)\b/i],
    ['advice-source',/\b(?:opinion|advice|view|input|confirmation|reassurance|person|y kien|ý kiến|loi khuyen|lời khuyên|xac nhan|xác nhận)\b/i],
    ['requirement',/\b(?:requirement|approval|permission|deadline|rule|yeu cau|yêu cầu|phe duyet|phê duyệt|quyen|quyền|han chot|hạn chót)\b/i],
    ['task',/\b(?:task|action|work|appointment|instrument|film|movie|viec|việc|nhiem vu|nhiệm vụ|phim)\b/i],
    ['resource',/\b(?:money|resource|time|budget|tien|tiền|nguon luc|nguồn lực|thoi gian|thời gian)\b/i],
    ['person',/\b(?:person|colleague|supervisor|client|friend|partner|nguoi|người|dong nghiep|đồng nghiệp|sep|sếp)\b/i]
  ]);
  const PREDICATES = Object.freeze([
    ['avoid-engagement',/\b(?:avoid|sidestep|withdraw|leave|left|archive|archived|ignore|unopened|unread|ne|né|tranh|bo qua|bỏ qua|de .+ chua doc|để .+ chưa đọc)\b/i,['communication','task','person']],
    ['review',/\b(?:review\w*|check\w*|recheck\w*|revisit\w*|reread\w*|re-read\w*|read\w*|examin\w*|inspect\w*|reopen\w*|compar\w*|verif\w*|doi chieu|đối chiếu|kiem tra|kiểm tra|xem lai|xem lại|xem|doc|đọc)\b/i,['evidence','document','communication','resource']],
    ['seek-input',/\b(?:ask\w*|seek\w*|sought|consult\w*|confirm\w*|reassurance|hoi|hỏi|tham khao|tham khảo|xac nhan|xác nhận)\b/i,['advice-source','evidence','person']],
    ['preparation',/\b(?:rehears\w*|prepar\w*|practic\w*|draft\w*|tap truoc|tập trước|chuan bi|chuẩn bị)\b/i,['communication','document','task']],
    ['unable-to-act',/\b(?:cannot|can not|couldn'?t|could not|unable|stuck|freeze|khong the|không thể|khong .+ noi|không .+ nổi|chang biet phai lam sao|chẳng biết phải làm sao|mac ket|mắc kẹt)\b/i,['decision-option','task','evidence','unknown']],
    ['premature-close',/\b(?:rush\w*|decid\w*|made|make|accept\w*|sign\w*|adopt\w*|choos\w*|respond\w*|close\w*|nhan loi|nhận lời|chot|chốt|quyet|quyết|chap nhan|chấp nhận)\b/i,['decision-option','document','communication','task','evidence','resource','unknown']],
    ['proportionate-act',/\b(?:appropriate step|proportionate step|necessary step|lam buoc phu hop|làm bước phù hợp|lam phan can thiet|làm phần cần thiết)\b/i,['task','evidence','unknown']],
    ['wait',/\b(?:wait|waiting|postpone|delay|defer|cho|chờ|tri hoan|trì hoãn)\b/i,['requirement','communication','task']],
    ['cessation',/\b(?:stop|stopped|abandon|abandoned|quit|cease|dung|dừng|bo|bỏ)\b/i,['unknown','task','document']]
  ]);

  function span(raw, text, from) { const start=Math.max(0,raw.indexOf(text,from||0)); return {start,end:start+text.length,text:raw.slice(start,start+text.length)}; }
  function fact(value, producer, sourceSpan, rule, deps, previousValue) { return {value,provenance:{producer,source_span:sourceSpan,normalization_rule:rule,input_dependencies:deps,status:value==='unknown'?'unknown':'deterministic',previous_value:previousValue===undefined?null:previousValue}}; }
  function classifyObject(text) { const normalized=fold(text);for(const [name,rx] of OBJECT_CLASSES) if(rx.test(normalized)) return name; return 'unknown'; }
  function segment(raw) {
    const connector=/\s*(;|\b(?:then|and then|before|after|while|because|although|but|yet|and|if|roi|rồi|sau do|sau đó|truoc khi|trước khi|sau khi|trong khi|boi vi|bởi vì|vi|vì|mac du|mặc dù|nhung|nhưng|va|và|neu|nếu)\b)\s+/gi;
    const parts=[], relations=[]; let cursor=0, match, pending=null;
    const leading=raw.match(/^\s*(After|Before|Although|While|Because|If|Sau khi|Trước khi|Mặc dù|Trong khi|Bởi vì|Nếu)\s+([^,]+),\s*(.+)$/i);
    if(leading){const first=leading[2].trim(),second=leading[3].trim(),firstOffset=raw.indexOf(first),secondOffset=raw.indexOf(second,firstOffset+first.length);parts.push({text:first,offset:firstOffset,incoming:null},{text:second,offset:secondOffset,incoming:leading[1]});cursor=raw.length;}
    while(!leading&&(match=connector.exec(raw))){const text=raw.slice(cursor,match.index).trim();if(text)parts.push({text,offset:raw.indexOf(text,cursor),incoming:pending});pending=match[1];cursor=connector.lastIndex;}
    const tail=raw.slice(cursor).trim();if(tail)parts.push({text:tail,offset:raw.indexOf(tail,cursor),incoming:pending});
    if(!parts.length&&raw.trim())parts.push({text:raw.trim(),offset:raw.indexOf(raw.trim()),incoming:null});
    if(parts.length===1&&/[;]/.test(parts[0].text)){const base=parts[0],split=base.text.split(/\s*;\s*/).filter(Boolean);parts.length=0;let seek=base.offset;for(let i=0;i<split.length;i++){const text=split[i].trim(),offset=raw.indexOf(text,seek);parts.push({text,offset,incoming:i?'but':null});seek=offset+text.length;}}
    const relationType=x=>({';':'CONTRAST',then:'THEN','and then':'THEN',before:'BEFORE',after:'AFTER',while:'WHILE',because:'BECAUSE',although:'CONTRAST',but:'CONTRAST',yet:'CONTRAST',and:'AND',if:'CONDITION',roi:'THEN','rồi':'THEN','sau do':'THEN','sau đó':'THEN','truoc khi':'BEFORE','trước khi':'BEFORE','sau khi':'AFTER','trong khi':'WHILE','boi vi':'BECAUSE','bởi vì':'BECAUSE',vi:'BECAUSE','vì':'BECAUSE','mac du':'CONTRAST','mặc dù':'CONTRAST',nhung:'CONTRAST','nhưng':'CONTRAST',va:'AND','và':'AND',neu:'CONDITION','nếu':'CONDITION'}[fold(x)]||'AND');
    for(let i=1;i<parts.length;i++)relations.push({relation_id:`r${i}`,type:relationType(parts[i].incoming),from_proposition_id:`p${i}`,to_proposition_id:`p${i+1}`,source_span:{start:parts[i].offset-String(parts[i].incoming||'').length-2,end:parts[i].offset,text:String(parts[i].incoming||'')}});
    return {parts,relations};
  }
  function resolveActor(text, reality) {
    const t=fold(text); let type='unknown', person='unknown', ownership='unknown', surface='';
    const attributed=t.match(/^(?:according to|theo loi|theo lời)\s+[^,]+,\s*(.+)$/i)||t.match(/^.+?\s+(?:said|says|reported|noi rang|nói rằng)\s+(.+)$/i);const governed=attributed?attributed[1]:t;
    const thirdPossessive=governed.match(/^(?:my|our)?\s*(?:colleague|coworker|teammate|manager|supervisor|director|adviser|accountant|editor|dong nghiep|đồng nghiệp|ban dong nghiep|bạn đồng nghiệp)(?:\s+(?:toi|minh|tôi|mình))?\b/i);
    if(thirdPossessive){surface=thirdPossessive[0];type=attributed?'reported-actor':'third-party';person='third';ownership='third-party';return{actor_id:'a:'+fold(surface).replace(/\s+/g,'-'),surface,actor_type:type,person,ownership};}
    const subject=governed.match(RX.roleSubject);
    if(subject&&subject[1]&&/^(?:my|our|the|a|an)$/i.test(subject[1])){surface=subject[2];type=RX.generic.test(surface)?'generic':'third-party';person=type==='generic'?'generic':'third';ownership=type==='generic'?'none':'third-party';}
    else if(RX.group.test(governed)){type='collective-self';person='first';ownership='shared';surface=(governed.match(RX.group)||['we'])[0];}
    else if(RX.self.test(governed)){type='self';person='first';ownership='self';surface=(governed.match(RX.self)||['i'])[0];}
    else if(subject){surface=subject[2];type=RX.generic.test(surface)?'generic':'third-party';person=type==='generic'?'generic':'third';ownership=type==='generic'?'none':'third-party';}
    else if(RX.generic.test(governed)){surface=(governed.match(RX.generic)||['someone'])[0];type='generic';person='generic';ownership='none';}
    if(reality!=='actual'&&type==='generic')type='hypothetical-actor';
    return {actor_id:'a:'+fold(surface||'unknown').replace(/\s+/g,'-'),surface,actor_type:type,person,ownership};
  }
  function resolveReality(text, documentText) {
    const local=fold(text),doc=fold(documentText);
    if(RX.counterfactual.test(local)||RX.counterfactual.test(doc))return'counterfactual';
    if(RX.example.test(local)||RX.example.test(doc))return'example';
    if(RX.fictional.test(local)||RX.fictional.test(doc))return'fictional';
    if(RX.hypothetical.test(local)||RX.hypothetical.test(doc))return'hypothetical';
    if(RX.conditional.test(local))return'conditional';
    if(RX.quote.test(local))return'quoted-report';
    return'actual';
  }
  function resolvePredicate(text, objectClass) {
    const normalized=fold(text),candidates=[];for(const [id,rx,objects] of PREDICATES)if(rx.test(normalized)){let compatible=objects.includes(objectClass)||objects.includes('unknown')||objectClass==='unknown';if(id==='premature-close'&&!/\b(?:rush\w*|hasty|hastily|quick\w*|immediate\w*|straight away|right away|before|ngay|voi|qua som|truoc khi)\b/i.test(normalized))compatible=false;candidates.push({id,compatible});}
    const best=candidates.find(x=>x.compatible)||null;return{candidates,canonical:best?best.id:'unknown'};
  }
  function resolveIntent(raw, propositions) {
    const t=fold(raw),speech=RX.question.test(raw)?'question':'statement';let intent='none';
    if(speech==='question'){if(RX.behavioralQuestion.test(t))intent='behavioral-question';else if(RX.decisionQuestion.test(t))intent='decision-request';else if(RX.prediction.test(t))intent='prediction-request';else if(RX.infoQuestion.test(t))intent='information-request';else intent='clarification-required';}
    if(speech==='statement'&&propositions.some(p=>['self','collective-self'].includes(p.actor.actor_type)))intent='behavioral-self-report';
    return{speech_act:speech,question_intent:intent,target_proposition_ids:propositions.map(p=>p.proposition_id)};
  }
  function buildCanonicalState(raw) {
    raw=String(raw||'');const normalized=fold(raw),documentSpan={start:0,end:raw.length,text:raw};const graph=segment(raw);const trace=[];
    const clauses=graph.parts.map((part,i)=>({clause_id:`c${i+1}`,source_span:{start:part.offset,end:part.offset+part.text.length,text:part.text},text:part.text,proposition_ids:[`p${i+1}`],operator_ids:[]}));
    const propositions=graph.parts.map((part,i)=>{const semanticText=fold(part.text),s={start:part.offset,end:part.offset+part.text.length,text:part.text},reality=resolveReality(part.text,raw),actor=resolveActor(part.text,reality),objectClass=classifyObject(part.text),pred=resolvePredicate(part.text,objectClass),unreadState=/\b(?:unread|unopened|chua doc|chua mo)\b/i.test(semanticText),explicitNegatedAvoid=/\b(?:not|never|didn'?t|doesn'?t|don'?t|wasn'?t|khong|chang)\b.{0,24}\b(?:avoid\w*|sidestep\w*|withdraw\w*|ne|tranh)\b/i.test(semanticText),negative=pred.canonical!=='unable-to-act'&&(explicitNegatedAvoid||(RX.negation.test(semanticText)&&!(pred.canonical==='avoid-engagement'&&unreadState))),ceased=RX.cessation.test(semanticText),repeated=RX.repeated.test(semanticText),bounded=RX.single.test(semanticText)&&!repeated,sufficient=RX.sufficient.test(semanticText),insufficient=RX.insufficient.test(semanticText),changed=RX.changed.test(semanticText),unchanged=RX.unchanged.test(semanticText);
      const p={proposition_id:`p${i+1}`,clause_id:`c${i+1}`,source_span:s,actor,target:null,predicate:pred.canonical,predicate_candidates:pred.candidates,predicate_class:pred.canonical,object:part.text,object_semantic_class:objectClass,polarity:negative?'negative':'positive',negation_scope:negative?[`p${i+1}`]:[],cessation_status:ceased?'ceased':'active',reality_status:reality,hypothetical_status:['hypothetical','conditional','counterfactual'].includes(reality)?'in-scope':'out-of-scope',example_status:reality==='example'?'example':'not-example',quotation_status:RX.quote.test(part.text)?'reported':'direct',attribution:{type:RX.quote.test(part.text)?'reported':'none',source_actor_id:null,stance:'unknown'},constraint_status:RX.external.test(part.text)?'external':'none',frequency:{kind:repeated?'repeated':bounded?'single':'unknown',count:/\bthree times\b/i.test(part.text)?3:null},repetition:repeated?'repeated':'not-repeated',evidence_sufficiency:insufficient?'insufficient':sufficient?'sufficient':'unknown',evidence_change:changed?'changed':unchanged?'unchanged':'unknown',boundedness:bounded?'bounded':repeated?'unbounded':'unknown',temporal_position:i+1,sequence_relation:graph.relations.filter(r=>r.from_proposition_id===`p${i+1}`||r.to_proposition_id===`p${i+1}`).map(r=>r.relation_id),question_intent:'none',speech_act:'statement',family_candidate:[],family_eligibility:'undetermined',suppression_reason:[],public_route_contribution:'unknown',operator_ids:[]};
      const fields=['actor','ownership','predicate','object','polarity','negation_scope','cessation_status','reality_status','constraint_status','frequency','repetition','evidence_sufficiency','evidence_change','boundedness'];for(const field of fields)trace.push({fact_path:`propositions.${i}.${field}`,producer:FACT_OWNER[field]||FACT_OWNER.actor,source_span:s,normalization_rule:`canonical-${field}-v1`,input_dependencies:['clause','operators','lexical-candidates'],status:p[field]==='unknown'?'unknown':'deterministic',previous_value:null,new_value:field==='ownership'?actor.ownership:p[field]});return p;});
    for(let i=1;i<propositions.length;i++)if(propositions[i].actor.actor_type==='unknown'&&['THEN','BEFORE','AFTER','WHILE','BECAUSE','CONTRAST','AND'].includes(graph.relations[i-1]&&graph.relations[i-1].type)){const previous=propositions[i].actor;propositions[i].actor={...propositions[i-1].actor};trace.push({fact_path:`propositions.${i}.actor`,producer:'actor-resolver',source_span:propositions[i].source_span,normalization_rule:'coordinated-subject-inheritance-v1',input_dependencies:[propositions[i-1].proposition_id,graph.relations[i-1].relation_id],status:'deterministic',previous_value:previous,new_value:propositions[i].actor});}
    for(let pass=0;pass<propositions.length;pass++)for(const relation of graph.relations){const left=propositions.find(p=>p.proposition_id===relation.from_proposition_id),right=propositions.find(p=>p.proposition_id===relation.to_proposition_id);if(!left||!right)continue;for(const behavioral of [left,right].filter(p=>p.predicate!=='unknown')){const context=behavioral===left?right:left;for(const key of ['evidence_sufficiency','evidence_change'])if(behavioral[key]==='unknown'&&context[key]!=='unknown'){const previous=behavioral[key];behavioral[key]=context[key];trace.push({fact_path:`propositions.${behavioral.temporal_position-1}.${key}`,producer:'evidence-reducer',source_span:context.source_span,normalization_rule:`relation-scoped-${key}-propagation-v1`,input_dependencies:[relation.relation_id,context.proposition_id],status:'deterministic',previous_value:previous,new_value:behavioral[key]});}}}
    const intent=resolveIntent(raw,propositions);for(const p of propositions){p.question_intent=intent.question_intent;p.speech_act=intent.speech_act;}
    trace.push({fact_path:'intent',producer:'intent-resolver',source_span:documentSpan,normalization_rule:'speech-act-plus-proposition-intent-v1',input_dependencies:['clause-graph','propositions'],status:'deterministic',previous_value:null,new_value:intent});
    return{schema_version:'css-proposal-v1',document_id:`d:${hash(normalized)}`,source:{raw,normalized,language:semanticV3.locale(raw)},clauses,propositions,relations:graph.relations,intent,family_decisions:[],public_route:{id:'input:clarification-required',derived_from:[],rule:'unresolved-before-consumers'},trace,authority_writes:Object.fromEntries(Object.entries(FACT_OWNER).map(([k,v])=>[k,[v]]))};
  }
  function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(16);}
  function consumerView(state){return{schema_version:state.schema_version,document_id:state.document_id,propositions:state.propositions,relations:state.relations,intent:state.intent};}
  function familyConsumer(stateView){const decisions=[];for(const p of stateView.propositions){let candidate=null;if(p.polarity==='positive'&&p.cessation_status!=='ceased'){if(p.predicate==='avoid-engagement')candidate='ignore';else if(p.predicate==='unable-to-act')candidate='freeze';else if(p.predicate==='premature-close')candidate='fast';else if(p.predicate==='proportionate-act'&&p.evidence_sufficiency==='sufficient')candidate='adaptive';else if(['review','seek-input','preparation'].includes(p.predicate)){if(p.repetition==='repeated'&&p.evidence_change!=='changed')candidate='slow';else if(p.boundedness==='bounded'&&(p.evidence_change==='changed'||['sufficient','insufficient'].includes(p.evidence_sufficiency)))candidate='adaptive';}}
      const reasons=[];if(p.reality_status!=='actual')reasons.push('NON_REAL');if(!['self','collective-self'].includes(p.actor.actor_type))reasons.push('NON_SELF');if(p.polarity==='negative')reasons.push('NEGATED');if(p.cessation_status==='ceased')reasons.push('CEASED');const eligible=!!candidate&&!reasons.length;decisions.push({proposition_id:p.proposition_id,candidate,eligible,suppression_reasons:reasons,rule:'canonical-family-state-v1'});p.family_candidate=candidate?[candidate]:[];p.family_eligibility=eligible?'eligible':'ineligible';p.suppression_reason=reasons;}
    return decisions;
  }
  function sequenceConsumer(stateView,decisions){const active=new Set(decisions.filter(d=>d.eligible).map(d=>d.proposition_id));const edges=stateView.relations.filter(r=>active.has(r.from_proposition_id)&&active.has(r.to_proposition_id));return{sequence:edges.length>0,relations:edges,ordered_proposition_ids:[...active].sort((a,b)=>Number(a.slice(1))-Number(b.slice(1)))};}
  function routeConsumer(stateView){const intent=stateView.intent.question_intent;if(intent==='prediction-request')return{id:'input:prediction',derived_from:['intent'],rule:'canonical-intent-route-v1'};if(intent==='decision-request')return{id:'input:decision-request',derived_from:['intent'],rule:'canonical-intent-route-v1'};if(stateView.propositions.some(p=>['hypothetical','example','fictional','counterfactual','conditional'].includes(p.reality_status)))return{id:'input:hypothetical-or-example',derived_from:['propositions.reality_status'],rule:'canonical-reality-route-v1'};if(stateView.propositions.length&&stateView.propositions.every(p=>!['self','collective-self'].includes(p.actor.actor_type)))return{id:'input:third-party-only',derived_from:['propositions.actor'],rule:'canonical-actor-route-v1'};if(stateView.propositions.some(p=>['self','collective-self'].includes(p.actor.actor_type)))return{id:'input:self-lived',derived_from:['propositions.actor','intent'],rule:'canonical-self-route-v1'};return{id:'input:clarification-required',derived_from:['propositions.actor','intent'],rule:'canonical-unknown-route-v1'};}
  function deriveCanonical(state){const view=consumerView(state),decisions=familyConsumer(view),sequence=sequenceConsumer(view,decisions),route=routeConsumer(view),families=[];for(const d of decisions)if(d.eligible&&d.candidate&&!families.includes(d.candidate))families.push(d.candidate);state.family_decisions=decisions;state.public_route=route;return{families,route,sequence};}
  function assertInvariants(state,derived){const violations=[];for(const [fact,producers] of Object.entries(state.authority_writes))if(new Set(producers).size!==1)violations.push({invariant:'ONE_AUTHORITY_PER_SEMANTIC_FACT',fact});for(const d of state.family_decisions)if(d.eligible&&!state.propositions.some(p=>p.proposition_id===d.proposition_id))violations.push({invariant:'FAMILY_DERIVES_FROM_CANONICAL_STATE',proposition_id:d.proposition_id});for(const r of state.relations)if(!state.propositions.some(p=>p.proposition_id===r.from_proposition_id)||!state.propositions.some(p=>p.proposition_id===r.to_proposition_id))violations.push({invariant:'TEMPORAL_RELATIONS_PRESERVED',relation_id:r.relation_id});if(!derived.route.derived_from.length)violations.push({invariant:'ROUTE_DERIVES_FROM_CANONICAL_STATE'});return violations;}
  function classifyDifference(legacyFrame,derived){const sameFamilies=JSON.stringify(legacyFrame.families||[])===JSON.stringify(derived.families),sameRoute=legacyFrame.input_route&&legacyFrame.input_route.id===derived.route.id,sameSequence=!!legacyFrame.sequence===!!derived.sequence.sequence;return sameFamilies&&sameRoute&&sameSequence?'BOTH_CORRECT_EQUIVALENT':(sameFamilies&&sameRoute?'REPRESENTATION_DIFFERENCE_OUTPUT_SAME':'INSUFFICIENT_EXPECTED_AUTHORITY');}
  function routeFrame(route){const redirect=['input:prediction','input:decision-request','input:hypothetical-or-example'].includes(route.id),clarify=['input:third-party-only','input:clarification-required'].includes(route.id);return{...route,action:redirect?'redirect':clarify?'clarify':'continue',must_stop:['input:prediction','input:decision-request'].includes(route.id),must_redirect:redirect};}
  function analyze(raw,domain='other',subtopic=null){const legacyFrame=legacy.analyze(raw,domain,subtopic),canonical=buildCanonicalState(raw),derived=deriveCanonical(canonical),violations=assertInvariants(canonical,derived),route=routeFrame(violations.length?{id:'input:clarification-required',derived_from:['invariant_violations'],rule:'canonical-fail-closed-v1'}:derived.route),responses=canonical.family_decisions.filter(d=>d.eligible&&d.candidate).map(d=>({id:`v83129:${d.proposition_id}:${d.candidate}`,predicate:canonical.propositions.find(p=>p.proposition_id===d.proposition_id).predicate,family:d.candidate,phase_id:canonical.propositions.find(p=>p.proposition_id===d.proposition_id).temporal_position,confidence:'canonical',dimension:d.candidate==='slow'?'information':'engagement',position:d.candidate==='adaptive'?'neutral':'A',qualification_reason:d.rule}));return{...legacyFrame,version:VERSION,metadata,input_route:route,responses,families:[...derived.families],sequence:derived.sequence.sequence,oscillation:derived.sequence.sequence,response_known:derived.families.length>0,can_continue:route.action==='continue',must_stop:!!route.must_stop,must_redirect:!!route.must_redirect,canonical_semantic_state:canonical,canonical_shadow:{derived,legacy:{families:[...(legacyFrame.families||[])],route:legacyFrame.input_route&&legacyFrame.input_route.id,sequence:!!legacyFrame.sequence},difference_classification:classifyDifference(legacyFrame,derived),invariant_violations:violations},semantic_representation:{...(legacyFrame.semantic_representation||{}),canonical_state:canonical,canonical_authority:true,legacy_diagnostic_only:true}};}
  function inputRoute(raw){return analyze(raw).input_route;}
  function canonicalAnalyze(raw){const state=buildCanonicalState(raw),derived=deriveCanonical(state),violations=assertInvariants(state,derived);return{state,derived,violations};}
  const invariants=Object.freeze(['ONE_AUTHORITY_PER_SEMANTIC_FACT','DOWNSTREAM_DOES_NOT_REPARSE_RAW_MEANING','ACTOR_IDENTITY_STABLE','OWNERSHIP_STABLE','REALITY_STATUS_STABLE','NEGATION_SCOPE_STABLE','PREDICATE_IDENTITY_STABLE','OBJECT_CLASS_STABLE','EVIDENCE_STATE_STABLE','INTENT_STABLE','TEMPORAL_RELATIONS_PRESERVED','FAMILY_DERIVES_FROM_CANONICAL_STATE','ROUTE_DERIVES_FROM_CANONICAL_STATE']);
  global.QCSemanticCoreV4={...legacy,version:VERSION,metadata,FACT_OWNER,buildCanonicalState,deriveCanonical,canonicalAnalyze,analyze,inputRoute,invariants,schema:Object.freeze({...legacy.schema,canonicalSemanticState:'css-proposal-v1',shadowMode:false,canonicalAuthority:true})};
  global.PSC_V83129=global.QCSemanticCoreV4;
  if(global.document&&global.document.documentElement)global.document.documentElement.dataset.pscSemanticAuthority='V8.3.129:canonical-state';
})(typeof globalThis!=='undefined'?globalThis:this);
