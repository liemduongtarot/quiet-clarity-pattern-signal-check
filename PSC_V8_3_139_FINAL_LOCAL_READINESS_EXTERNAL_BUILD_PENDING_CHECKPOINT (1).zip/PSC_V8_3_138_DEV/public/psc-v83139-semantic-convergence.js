(function(global){
'use strict';
const parent=global.QCSemanticCoreV9;
if(!parent)throw new Error('V8.3.139 requires V8.3.138 semantic authority');
const VERSION='V8.3.139-SEALED-A-FAILURE-CONVERGENCE';
const metadata=Object.freeze({version:VERSION,parent:'V8.3.138 FAILED REVIEW CANDIDATE',classification:'LEVEL-1 SEMANTIC CONVERGENCE REPAIR',source_failures:'V8.3.138 immutable Batch A first-run 11 failures',production_authorized:false,production_lock:'prohibited',sealed_validation:'not-authorized',step_111:'prohibited'});
const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').replace(/[’‘]/g,"'").toLowerCase().replace(/\s+/g,' ').trim();
const ACTOR=(prev,type,ownership,surface)=>({...prev,actor_id:type==='self'?'a:self':type==='third-party'?'a:third-party':'a:unknown',surface:surface||prev?.surface||'',actor_type:type,person:type==='self'?'first':type==='unknown'?'unknown':'third',ownership,behavior_ownership:ownership});
const isBehavior=p=>['review','seek-input','preparation','avoid-engagement','unable-to-act','premature-close','proportionate-act'].includes(p.predicate);
function bindActor(p,type,ownership,surface,extraRoles={}){p.actor=ACTOR(p.actor,type,ownership,surface);p.roles={...p.roles,subject_actor_id:p.actor.actor_id,agent_actor_id:p.actor.actor_id,behavior_ownership:ownership,...extraRoles};}
function repairState(raw){
 const state=parent.buildCanonicalState(raw),doc=fold(raw),ps=state.propositions;
 // A. Explicit third-party behavioral head outranks self possessive references and explicit self negation.
 for(const p of ps){const t=fold(p.source_span?.text);if(/(?:\bchinh ban ay\b|\bban ay\b|\bhe\b|\bshe\b|\bthey\b).{0,45}(?:\bkiem tra\b|\bcheck\b|\breview\b|\btri hoan\b|\bdelay\b|\bavoid\b)/.test(t)&&/(?:\bkhong phai toi\b|\bnot me\b|\baccording to\b|\btheo\b.{0,50}\bke\b)/.test(t)){bindActor(p,'third-party','third-party','explicit third-party',{reported_actor_id:'a:third-party'});p.quotation_status=/\baccording to\b|\btheo\b.{0,50}\bke\b/.test(t)?'reported':p.quotation_status;p.relation_derived_facts?.push('EXPLICIT_THIRD_PARTY_BEHAVIOR_HEAD');}}
 // B. Reported friend/third-party attribution in Vietnamese.
 for(const p of ps){const t=fold(p.source_span?.text);if(/^(?:theo ban toi ke|theo .{0,50}\bke\b).{0,80}(?:\bban ay\b|\banh ay\b|\bco ay\b|\bho\b).{0,60}(?:\btri hoan\b|\bkiem tra\b|\bne\b|\btranh\b|\bdelay\b|\bcheck\b|\bavoid\b)/.test(t)){bindActor(p,'third-party','third-party','reported third-party',{reported_actor_id:'a:third-party'});p.quotation_status='reported';p.relation_derived_facts?.push('REPORTED_THIRD_PARTY_BEHAVIOR_BOUND');}}
 // C. Self-owned affected request/process remains self-lived even when an external provider blocks it.
 for(const p of ps){const t=fold(p.source_span?.text);if(/^(my|our)\s+(refund )?(request|application|submission|form|case)\b/.test(t)&&/(could not|couldn't|was blocked|was delayed|could not move)/.test(t)){bindActor(p,'self','self','self-owned affected process',{object_owner_actor_id:'a:self',affected_action_owner:'self'});p.predicate=p.predicate_class='unable-to-act';p.relation_derived_facts?.push('SELF_OWNED_AFFECTED_PROCESS_BOUND');}}
 // D. External provider/gateway/system unavailability propagates external constraint to self inability and suppresses freeze.
 const blocker=ps.find(p=>/(?:\bpayment provider\b|\bpayment gateway\b|\bprovider\b|\bgateway\b|\bportal\b|\bsystem\b|\bservice\b|\bhe thong\b|\bcong\b).{0,45}(?:\boffline\b|\bunavailable\b|\bdown\b|\bbi loi\b|\bloi\b|\berror\b|\bhong\b)/.test(fold(p.source_span?.text))||/(?:\boffline\b|\bunavailable\b|\bdown\b|\bbi loi\b|\bloi\b|\berror\b|\bhong\b).{0,45}(?:\bpayment provider\b|\bpayment gateway\b|\bprovider\b|\bgateway\b|\bportal\b|\bsystem\b|\bservice\b|\bhe thong\b|\bcong\b)/.test(fold(p.source_span?.text)));
 if(blocker){bindActor(blocker,'third-party','third-party','external blocker');blocker.constraint_status='external';blocker.constraint_type='external-system-failure';blocker.external_prevention=true;for(const p of ps){if(p.predicate==='unable-to-act'&&p.actor?.actor_type==='self'){p.constraint_status='external';p.constraint_type='external-prevention';p.constraint_source=blocker.source_span?.text;p.external_prevention=true;p.internal_freeze_state=false;p.relation_derived_facts?.push('EXTERNAL_PROVIDER_FAILURE_PROPAGATED');}}}
 // E. Historical/no-longer-current statements scope to prior self behavior.
 const inactiveIndex=ps.findIndex(p=>/(no longer current|no longer happens|no longer do|khong con hien tai|khong con xay ra|khong con lam)/.test(fold(p.source_span?.text)));
 if(inactiveIndex>=0){for(let i=0;i<inactiveIndex;i++){const p=ps[i];if(p.actor?.actor_type==='self'&&isBehavior(p)){p.cessation_status='ceased';p.current_status='inactive';p.relation_derived_facts?.push('LATER_CURRENT_INACTIVE_SCOPED_TO_PRIOR_BEHAVIOR');}}}
 // F. Explicit negation must not be overwritten by lexical avoidance detection.
 for(const p of ps){const t=fold(p.source_span?.text);if(p.predicate==='avoid-engagement'&&/(khong\s+(?:he\s+)?(?:ne|tranh)|not\s+(?:avoid|avoiding)|do not avoid|don't avoid)/.test(t)){p.polarity='negative';p.relation_derived_facts?.push('EXPLICIT_AVOIDANCE_NEGATION_PRESERVED');}}
 // G. Purposive delay of opening/reading is avoid-engagement.
 for(const p of ps){const t=fold(p.source_span?.text);if(/(de|nham|so as to|in order to).{0,45}(tri hoan|delay|put off).{0,45}(mo|doc|open|read)|(?:tri hoan|delay|put off).{0,45}(viec )?(mo|doc|open|read)/.test(t)){p.predicate=p.predicate_class='avoid-engagement';p.polarity='positive';p.relation_derived_facts?.push('PURPOSIVE_DELAY_AVOIDANCE_RESOLVED');}}
 // H. Changed evidence followed by renewed review is bounded adaptive review even when "again" marks recurrence.
 for(const p of ps){const t=fold(p.source_span?.text);if(p.predicate==='review'&&p.evidence_change==='changed'&&/(new information|new info|thong tin moi|du lieu moi|changed|thay doi)/.test(doc)){p.boundedness='bounded';p.relation_derived_facts?.push('CHANGED_EVIDENCE_BOUNDS_RENEWED_REVIEW');}}
 // I. Repeated return/revisit/check with explicitly unchanged evidence normalizes to review/slow.
 for(const p of ps){const t=fold(p.source_span?.text);if(p.actor?.actor_type==='self'&&p.repetition==='repeated'&&p.evidence_change==='unchanged'&&p.predicate==='unknown'&&/(returned to|went back|revisit|revisited|returned|quay lai|xem lai|kiem tra lai)/.test(t)){p.predicate=p.predicate_class='review';p.relation_derived_facts?.push('UNCHANGED_REPEATED_RETURN_NORMALIZED_TO_REVIEW');}}
 // J. Explicit rushed terminal response in a declared sequence is a fast/premature-close phase.
 const hasSequence=/(ban dau|sau do|roi cuoi cung|cuoi cung|initially|then|eventually|finally)/.test(doc);
 if(hasSequence){for(const p of ps){const t=fold(p.source_span?.text);if(/(tra loi|reply|respond).{0,24}(qua voi|voi vang|too quickly|too fast|rushed)|(?:qua voi|voi vang|too quickly|too fast|rushed).{0,24}(tra loi|reply|respond)/.test(t)){p.predicate=p.predicate_class='premature-close';p.polarity='positive';p.relation_derived_facts?.push('RUSHED_TERMINAL_RESPONSE_RESOLVED');}}}
 // K. Explicit disclosure that the user's behavior/response has not been described is meta-evidence, not self behavior.
 for(const p of ps){const t=fold(p.source_span?.text);if(p.predicate==='unknown'&&p.polarity==='negative'&&/(phan toi da lam gi|phan ung cua toi|toi da lam gi|my response|what i did).{0,60}(chua duoc mo ta|chua mo ta|not described|has not been described|was not described)/.test(t)){bindActor(p,'unknown','unknown','');p.roles={...p.roles,subject_actor_id:'a:unknown',agent_actor_id:'a:unknown',behavior_ownership:'unknown'};p.relation_derived_facts?.push('MISSING_SELF_RESPONSE_META_DISCLOSURE');}}
 return state;
}
function deriveCanonical(state){
 const derived=parent.deriveCanonical(state);
 // Meta-disclosure + no positive self behavioral proposition requires clarification.
 const hasPositiveSelfBehavior=state.propositions.some(p=>p.actor?.actor_type==='self'&&p.polarity==='positive'&&isBehavior(p));
 const hasMissingResponseMeta=state.propositions.some(p=>p.relation_derived_facts?.includes('MISSING_SELF_RESPONSE_META_DISCLOSURE'));
 const hasExplicitThirdBehavior=state.propositions.some(p=>p.actor?.actor_type==='third-party'&&p.polarity==='positive'&&isBehavior(p)&&(p.relation_derived_facts?.includes('EXPLICIT_THIRD_PARTY_BEHAVIOR_HEAD')||p.relation_derived_facts?.includes('REPORTED_THIRD_PARTY_BEHAVIOR_BOUND')));
 if(hasMissingResponseMeta&&!hasPositiveSelfBehavior)derived.route={id:'input:clarification-required',derived_from:['propositions.behavior_ownership','meta-disclosure'],rule:'missing-self-response-evidence-clarification-v1'};
 else if(hasExplicitThirdBehavior&&!hasPositiveSelfBehavior)derived.route={id:'input:third-party-only',derived_from:['propositions.behavior_ownership','reported-attribution'],rule:'explicit-third-party-behavior-only-v1'};
 return derived;
}
function routeFrame(route){const redirect=['input:safety','input:prediction','input:decision-request','input:hypothetical-or-example'].includes(route.id),clarify=['input:third-party-only','input:clarification-required'].includes(route.id);return{...route,action:redirect?'redirect':clarify?'clarify':'continue',must_stop:['input:safety','input:prediction','input:decision-request'].includes(route.id),must_redirect:redirect};}
function analyze(raw,domain='other',subtopic=null){const diagnostic=parent.analyze(raw,domain,subtopic),state=repairState(raw),derived=deriveCanonical(state),route=routeFrame(derived.route);return{...diagnostic,version:VERSION,metadata,input_route:route,families:[...derived.families],sequence:derived.sequence.sequence,oscillation:derived.sequence.sequence,response_known:derived.families.length>0,can_continue:route.action==='continue',must_stop:!!route.must_stop,must_redirect:!!route.must_redirect,canonical_semantic_state:state,canonical_shadow:{derived,legacy:{families:[...(diagnostic.families||[])],route:diagnostic.input_route?.id,sequence:!!diagnostic.sequence},difference_classification:'V8_3_139_LEVEL1_CONVERGENCE',invariant_violations:[...(diagnostic.canonical_shadow?.invariant_violations||[])]}};}
const core={...parent,version:VERSION,metadata,buildCanonicalState:repairState,deriveCanonical,analyze,inputRoute:raw=>analyze(raw).input_route,schema:Object.freeze({...parent.schema,canonicalSemanticState:'css-proposal-v6-sealed-failure-convergence'})};
global.QCSemanticCoreV10=core;global.PSC_V83139=core;if(global.document&&global.document.documentElement)global.document.documentElement.dataset.pscSemanticAuthority='V8.3.139:sealed-failure-convergence';
})(typeof globalThis!=='undefined'?globalThis:this);
